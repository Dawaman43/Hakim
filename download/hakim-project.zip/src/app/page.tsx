'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Hospital, Clock, Users, Phone, CaretRight, CheckCircle,
  ArrowLeft, ArrowRight, ArrowClockwise, Gear, SignOut, User,
  MapPin, Heart, Shield, Bell, CellTower, Ticket,
  FirstAid, Ambulance, Stethoscope,
  HandHeart, ChatCircle, MagnifyingGlass, List,
  GridFour, Timer, Sparkle, Warning,
  Check, X, ArrowCounterClockwise,
  PaperPlaneTilt, EnvelopeSimple,
  Buildings, NavigationArrow, Crosshair, Brain, Info,
  Sun, Moon, Globe,
  House, IdentificationCard, Calendar, ChartBar, Eye, EyeSlash,
  Plus, Minus, Trash, PencilSimple, Upload, Image as ImageIcon,
} from '@phosphor-icons/react';
import { useAuthStore } from '@/stores/auth-store';
import { formatWaitTime, formatPhoneDisplay, getSeverityColor, getSeverityLabel, getStatusColor, getStatusLabel } from '@/lib/queue-utils';
import { MOCK_HOSPITALS } from '@/lib/mock-hospitals';
import type { Hospital, Department, Appointment, QueueStatusResponse, TriageResult } from '@/types';

// View types
type ViewType = 
  | 'landing' 
  | 'hospitals' 
  | 'departments' 
  | 'booking' 
  | 'token' 
  | 'emergency' 
  | 'features'
  | 'about'
  | 'contact'
  | 'auth'
  | 'map'
  | 'nearest-hospitals'
  | 'admin-login' 
  | 'admin-dashboard' 
  | 'admin-queue' 
  | 'admin-analytics'
  | 'profile'
  | 'faq'
  | 'privacy'
  | 'terms'
  | 'hospital-register'
  | 'hospital-dashboard';

// Dashboard section types
type DashboardSection = 
  | 'overview' 
  | 'profile' 
  | 'location' 
  | 'queues' 
  | 'departments' 
  | 'staff' 
  | 'analytics' 
  | 'settings';

// Hospital registration form data
interface HospitalRegistrationData {
  hospitalName: string;
  hospitalType: 'GOVERNMENT' | 'PRIVATE' | 'NGO' | '';
  region: string;
  city: string;
  address: string;
  phone: string;
  email: string;
  adminName: string;
  adminPhone: string;
  adminPassword: string;
  confirmPassword: string;
  operatingHours: string;
  services: string[];
  agreeToTerms: boolean;
}

// API helper
const api = {
  async get(url: string, token?: string) {
    const headers: HeadersInit = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(url, { headers });
    return res.json();
  },
  async post(url: string, data: unknown, token?: string) {
    const headers: HeadersInit = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
    });
    return res.json();
  },
};

// Animation variants
const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 }
};

const slideIn = {
  initial: { opacity: 0, x: 20 },
  animate: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -20 }
};

const staggerContainer = {
  animate: { transition: { staggerChildren: 0.1 } }
};

// Main Component
export default function HakimApp() {
  const { user, token, isAuthenticated, login, logout } = useAuthStore();
  const [view, setView] = useState<ViewType>('landing');
  const [loading, setLoading] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Dark mode state
  const [darkMode, setDarkMode] = useState(false);
  
  // Toggle dark mode
  const toggleDarkMode = useCallback(() => {
    setDarkMode(prev => !prev);
  }, []);
  
  // Language state
  const [language, setLanguage] = useState<'en' | 'am'>('en');
  
  // Toggle language
  const toggleLanguage = useCallback(() => {
    setLanguage(prev => prev === 'en' ? 'am' : 'en');
  }, []);
  
  // Translations
  const t = {
    en: {
      // Navigation
      home: 'Home',
      features: 'Features',
      about: 'About',
      contact: 'Contact',
      signIn: 'Sign In',
      bookQueue: 'Book Queue',
      dashboard: 'Dashboard',
      signOut: 'Sign Out',
      profile: 'Profile',
      // Hero
      skipWait: 'Skip the Wait,',
      getCareFaster: 'Get Care Faster',
      heroDesc: 'Hakim transforms Ethiopian hospital queues with digital token booking, real-time updates, and SMS notifications.',
      noMoreWaiting: 'No more waiting rooms.',
      bookYourToken: 'Book Your Token',
      findNearestHospital: 'Find Nearest Hospital',
      locating: 'Locating...',
      hospitals: 'Hospitals',
      departments: 'Departments',
      regions: 'Regions',
      madeForEthiopia: 'Made for Ethiopia',
      // Common
      backToHome: 'Back to Home',
      backToHospitals: 'Back to Hospitals',
      backToDepartments: 'Back to Departments',
      backToDashboard: 'Back to Dashboard',
      selectHospital: 'Select Hospital',
      chooseDepartment: 'Choose a hospital to book your queue token',
      selectDepartment: 'Select Department',
      chooseDepartmentToken: 'Choose a department to book your queue token',
      searchHospitals: 'Search hospitals...',
      allRegions: 'All Regions',
      mapView: 'Map View',
      waiting: 'waiting',
      inQueue: 'In Queue',
      estWait: 'Est. Wait',
      currentQueueStatus: 'Current Queue Status',
      completeBooking: 'Complete Your Booking',
      phoneNumber: 'Phone Number',
      yourName: 'Your Name',
      nameOptional: 'Your name (optional)',
      notesOptional: 'Notes (optional)',
      notesPlaceholder: 'Any notes for the medical staff...',
      getMyToken: 'Get My Token',
      // Token page
      yourTokenNumber: 'Your Token Number',
      status: 'Status',
      queuePosition: 'Queue Position',
      estimatedWait: 'Estimated Wait',
      currentlyServing: 'Currently Serving',
      smsNotificationsActive: 'SMS Notifications Active',
      smsDesc: "You'll receive an SMS when you're next in line and when it's your turn.",
      // Hero Section Demo Card
      hospitalLabel: 'Hospital',
      departmentLabel: 'Department',
      generalMedicine: 'General Medicine',
      minutesShort: '~25 minutes',
      ahead: 'ahead',
      smsAlert: 'SMS Alert',
      confirmed: 'Confirmed!',
      realTimeLabel: 'Real-time',
      // FAQ Page
      faqTitle: 'Frequently Asked Questions',
      faqSubtitle: 'Find answers to common questions about Hakim',
      faqQ1: 'How do I book a queue token?',
      faqA1: 'Simply select a hospital, choose your department, enter your phone number, and receive your token instantly. No account required for basic booking.',
      faqQ2: 'Do I need a smartphone to use Hakim?',
      faqA2: 'No! While our app works great on smartphones, you can also receive SMS notifications on any basic feature phone. The booking process itself can be done from any device with internet access.',
      faqQ3: 'How will I know when it\'s my turn?',
      faqA3: 'You\'ll receive SMS alerts when you\'re 10 patients away, 5 patients away, and when it\'s your turn. You can also check your position in real-time through our app.',
      faqQ4: 'Is there a fee for using Hakim?',
      faqA4: 'Hakim is completely free for patients. There are no booking fees, subscription costs, or hidden charges.',
      faqQ5: 'What if I need to cancel my appointment?',
      faqA5: 'You can cancel your token through the app or by calling the hospital directly. Your spot will be given to the next patient in line.',
      faqQ6: 'Can I book for someone else?',
      faqA6: 'Yes! You can book tokens for family members or friends. Just provide their phone number during booking to ensure they receive the SMS notifications.',
      faqQ7: 'What hospitals are supported?',
      faqA7: 'Hakim currently supports over 290 hospitals across 13 regions of Ethiopia, with more being added regularly.',
      faqQ8: 'How accurate are the wait time estimates?',
      faqA8: 'Wait times are estimated based on average service times and current queue length. While we strive for accuracy, actual wait times may vary based on case complexity.',
      // Privacy Policy Page
      privacyTitle: 'Privacy Policy',
      privacySubtitle: 'Your privacy is important to us',
      privacyIntro: 'At Hakim, we are committed to protecting your privacy and ensuring the security of your personal health information. This policy explains how we collect, use, and safeguard your data.',
      privacyCollectTitle: 'Information We Collect',
      privacyCollect1: 'Phone number: Used for booking confirmation and queue status notifications',
      privacyCollect2: 'Name (optional): Used to personalize your experience',
      privacyCollect3: 'Health department selection: Used to route you to the appropriate medical service',
      privacyCollect4: 'Queue status and appointment history: Used to provide you with real-time updates',
      privacyUseTitle: 'How We Use Your Information',
      privacyUse1: 'To book and manage your hospital queue appointments',
      privacyUse2: 'To send you SMS notifications about your queue status',
      privacyUse3: 'To improve our services and user experience',
      privacyUse4: 'To generate anonymous statistics for healthcare planning',
      privacySecurityTitle: 'Data Security',
      privacySecurity: 'We implement industry-standard security measures including encryption, secure servers, and access controls. Your health data is protected in accordance with Ethiopian data protection laws and international best practices.',
      privacyShareTitle: 'Information Sharing',
      privacyShare: 'We only share your information with the hospital where you book your appointment. We never sell your data to third parties for marketing purposes.',
      privacyContact: 'If you have questions about this privacy policy, please contact us at privacy@hakim.et',
      // Terms of Service Page
      termsTitle: 'Terms of Service',
      termsSubtitle: 'Please read these terms carefully before using Hakim',
      termsIntro: 'By using Hakim, you agree to these terms of service. Hakim is a queue management platform designed to help patients manage their hospital visits more efficiently.',
      termsServiceTitle: 'Service Description',
      termsService: 'Hakim provides digital queue management services for participating hospitals in Ethiopia. Our service includes booking queue tokens, receiving status updates, and accessing queue information.',
      termsUserTitle: 'User Responsibilities',
      termsUser1: 'Provide accurate information when booking appointments',
      termsUser2: 'Arrive at the hospital in a timely manner when notified',
      termsUser3: 'Cancel appointments you cannot attend to free up slots for others',
      termsUser4: 'Treat hospital staff and other patients with respect',
      termsDisclaimerTitle: 'Medical Disclaimer',
      termsDisclaimer: 'Hakim is a queue management tool and does not provide medical advice, diagnosis, or treatment. For medical emergencies, always call 911 or visit the nearest emergency room immediately.',
      termsLimitationTitle: 'Limitation of Liability',
      termsLimitation: 'Hakim is not responsible for delays in medical care, changes in hospital schedules, or any medical outcomes. Wait times are estimates and may vary based on actual patient needs.',
      termsChangesTitle: 'Changes to Terms',
      termsChanges: 'We may update these terms from time to time. Continued use of Hakim after changes constitutes acceptance of the new terms.',
      termsContact: 'For questions about these terms, please contact us at legal@hakim.et',
      // Footer
      footerDesc: 'Transforming Ethiopian healthcare with smart queue management. Skip the wait, get care faster.',
      quickLinks: 'Quick Links',
      support: 'Support',
      emergencyContact: 'Emergency Contact',
      nationalEmergency: 'National Emergency',
      emergencyDesc: 'For life-threatening emergencies, please call 911 or go to the nearest emergency room immediately.',
      hipaaCompliant: 'HIPAA Compliant & Data Protected',
      madeWith: 'Made with',
      forEthiopia: 'for Ethiopia',
      // Regional Ambulance
      localAmbulance: 'Local Ambulance',
      ambulanceForRegion: 'Ambulance for your region',
      primaryAmbulance: 'Primary Emergency',
      secondaryAmbulance: 'Secondary',
      redCrossAmbulance: 'Red Cross Ambulance',
      callAmbulance: 'Call Ambulance',
      // Auth
      verifyOTP: 'Verify OTP',
      weSentCode: 'We sent a code to',
      signInPhone: 'Sign in with your phone number',
      enterOTP: 'Enter OTP Code',
      verifySignIn: 'Verify & Sign In',
      changePhone: 'Change phone number',
      continue: 'Continue',
      byContinuing: 'By continuing, you agree to our',
      termsOfService: 'Terms of Service',
      privacyPolicy: 'Privacy Policy',
      // Auth Page additional
      signIn: 'Sign In',
      phoneNumberLabel: 'Phone Number',
      nameOptionalLabel: 'Name (optional)',
      yourNamePlaceholder: 'Your name',
      enterOTPLabel: 'Enter OTP Code',
      verifySignInBtn: 'Verify & Sign In',
      // Emergency
      emergencyAssist: 'Emergency Assist',
      triageGuidance: 'Get triage guidance for your symptoms',
      importantDisclaimer: 'IMPORTANT DISCLAIMER',
      disclaimerDesc: 'This system does NOT replace emergency services. If this is a life-threatening emergency, call 911 immediately or proceed to the nearest emergency room.',
      describeSymptoms: 'Describe Your Symptoms',
      symptomPlaceholder: "Please describe your symptoms in detail. For example: 'I have severe chest pain and difficulty breathing for the past 30 minutes'",
      beSpecific: 'Be as specific as possible for better triage assessment.',
      contactInfo: 'Your Contact Information',
      nearestHospital: 'Nearest Hospital (Optional)',
      selectHospitalOptional: 'Select hospital (optional)',
      getTriageAssessment: 'Get Triage Assessment',
      severityLevel: 'Severity Level',
      confidence: 'Confidence',
      recommendation: 'Recommendation',
      identifiedKeywords: 'Identified keywords:',
      callEmergency: 'Call Emergency Services (911)',
      reportAnotherSymptom: 'Report Another Symptom',
      // Find nearest
      nearestHospitals: 'Nearest Hospitals',
      hospitalsByDistance: 'Hospitals sorted by distance from your location',
      locationDetected: 'Location detected',
      closestToYou: 'Closest to You',
      allNearbyHospitals: 'All Nearby Hospitals',
      viewAllOnMap: 'View All on Map',
      noHospitalsFound: 'No Hospitals Found',
      noHospitalsDesc: 'Unable to find hospitals near your location. Please try searching manually.',
      browseAllHospitals: 'Browse All Hospitals',
      away: 'away',
      // Location modal
      findNearestHospital: 'Find Nearest Hospital',
      useMyLocation: 'Use My Current Location',
      gettingLocation: 'Getting Location...',
      orSelectRegion: 'or select your region',
      selectRegion: 'Select Region',
      showHospitalsIn: 'Show Hospitals in',
      cancel: 'Cancel',
      // CTA
      readyToSkip: 'Ready to Skip the Wait?',
      ctaDesc: 'Join thousands of Ethiopians who have already transformed their healthcare experience.',
      startBooking: 'Start Booking',
      learnMore: 'Learn More',
      // Features Section
      featuresTitle: 'Everything You Need for Better Healthcare',
      featuresSubtitle: 'Designed specifically for Ethiopian hospitals, Hakim brings modern queue management to your fingertips.',
      digitalToken: 'Digital Token System',
      digitalTokenDesc: 'Get your queue token instantly without standing in line. Simply book from your phone.',
      realTimeUpdates: 'Real-Time Updates',
      realTimeUpdatesDesc: 'Track your position in queue live. Know exactly when it\'s your turn.',
      smsNotifications: 'SMS Notifications',
      smsNotificationsDesc: 'Receive SMS alerts when you\'re next in line. Works on any phone.',
      emergencyAssistFeature: 'Emergency Assist',
      emergencyAssistDesc: 'Quick triage assessment for emergencies. Get guidance when you need it most.',
      multipleHospitals: 'Multiple Hospitals',
      multipleHospitalsDesc: 'Access to hospitals across Ethiopia. Find the nearest one to you.',
      securePrivate: 'Secure & Private',
      securePrivateDesc: 'Your health data is protected. OTP-based secure authentication.',
      // How It Works
      howItWorks: 'How It Works',
      howItWorksSubtitle: 'Book your hospital visit in four simple steps',
      step1Title: 'Select Hospital',
      step1Desc: 'Choose from hospitals near you',
      step2Title: 'Pick Department',
      step2Desc: 'Select your medical department',
      step3Title: 'Get Token',
      step3Desc: 'Receive your queue number instantly',
      step4Title: 'Wait Comfortably',
      step4Desc: 'Get notified when it\'s your turn',
      // Additional
      bookYourTokenNow: 'Book Your Token Now',
      faq: 'FAQ',
      hospitalAdminPortal: 'Hospital Admin Portal',
      contactUs: 'Contact Us',
      // Features Page
      featuresPageTitle: 'Powerful Features for',
      featuresPageTitleHighlight: 'Ethiopian Healthcare',
      featuresPageDesc: 'Designed with the unique challenges of Ethiopian hospitals in mind, Hakim provides practical solutions that work even in low-infrastructure settings.',
      queueManagement: 'Queue Management',
      digitalTokenTitle: 'Digital Token System',
      digitalTokenPageDesc: 'Replace physical waiting lines with digital tokens. Patients can book their place in queue from anywhere, receive their token number instantly, and only come to the hospital when their turn is approaching.',
      instantToken: 'Instant token generation',
      estimatedWaitCalc: 'Estimated wait time calculation',
      realTimePosition: 'Real-time position tracking',
      multipleDepts: 'Multiple departments support',
      tokenNumber: 'Token Number',
      position: 'Position',
      estWaitShort: 'Est. Wait',
      fifthInLine: '5th in line',
      tokenConfirmed: 'Token Confirmed',
      tokenConfirmedMsg: 'Your token #042 at Tikur Anbessa is confirmed. Est. wait: 25 min.',
      tenPatientsAhead: '10 Patients Ahead',
      tenPatientsAheadMsg: 'Token #042 - 10 patients ahead. Please be ready.',
      itsYourTurn: "It's Your Turn!",
      itsYourTurnMsg: "Token #042 - It's your turn! Please proceed to the counter.",
      smsSystem: 'SMS System',
      smsNotificationsTitle: 'SMS Notifications',
      smsNotificationsPageDesc: 'Works on any mobile phone - no smartphone required. Patients receive automated SMS alerts at key moments: when they book, when they\'re 10 patients away, 5 patients away, and when it\'s their turn.',
      worksOnBasicPhones: 'Works on basic phones',
      noAppRequired: 'No app installation required',
      automatedReminders: 'Automated reminders',
      emergencyAlerts: 'Emergency alerts',
      emergencySupport: 'Emergency Support',
      emergencyTriageTitle: 'Emergency Triage Assist',
      emergencyTriageDesc: 'Patients can describe their symptoms and receive immediate triage guidance. Our system helps identify potentially serious conditions and directs patients to appropriate care.',
      critical: 'CRITICAL',
      criticalDesc: 'Immediate attention',
      high: 'HIGH',
      highDesc: 'Urgent care needed',
      medium: 'MEDIUM',
      mediumDesc: 'Prompt attention',
      low: 'LOW',
      lowDesc: 'Standard queue',
      emergencyWarning: 'This system does not replace professional medical advice or emergency services. For life-threatening emergencies, always call 911.',
      describeSymptoms: 'Describe Your Symptoms',
      describeSymptomsExample: '"I have severe chest pain and difficulty breathing for the past 30 minutes"',
      highSeverity: 'HIGH SEVERITY',
      highSeverityMsg: 'Seek immediate medical attention. Call 911 or proceed to the nearest emergency room.',
      // About Page
      aboutTitle: 'About',
      aboutSubtitle: 'Building better healthcare experiences for Ethiopia, one queue at a time.',
      ourMission: 'Our Mission',
      missionPara1: "Ethiopia's healthcare system serves over 120 million people, yet many hospitals struggle with overcrowded waiting rooms and inefficient patient flow. Patients often wait hours for a brief consultation, losing valuable time that could be spent on work, family, or rest.",
      missionPara2: 'Hakim was created to address this challenge head-on. By digitizing the queue management process, we help hospitals serve patients more efficiently while giving people the freedom to wait comfortably from anywhere.',
      missionBelief: 'We believe every Ethiopian deserves access to efficient, dignified healthcare.',
      populationServed: 'Population Served',
      avgWaitReduced: 'Avg. Wait Reduced',
      builtForEthiopia: 'Built for Ethiopia',
      builtForEthiopiaDesc: 'Designed with the unique challenges of Ethiopian healthcare infrastructure in mind.',
      smsFirstDesign: 'SMS-First Design',
      smsFirstDesignDesc: 'Works on basic feature phones. No smartphone or internet required for patients to receive notifications.',
      lowBandwidth: 'Low Bandwidth',
      lowBandwidthDesc: 'Optimized for areas with limited internet connectivity. Fast loading even on 2G networks.',
      regionalCoverage: 'Regional Coverage',
      regionalCoverageDesc: 'Supporting hospitals across multiple Ethiopian regions, with plans to expand nationwide.',
      offlineSupport: 'Offline Support',
      offlineSupportDesc: 'PWA-enabled for offline access. View your token even without an active connection.',
      availability247: '24/7 Availability',
      availability247Desc: 'Book appointments anytime, day or night. No need to arrive early to secure your spot.',
      ethiopianMade: 'Ethiopian Made',
      ethiopianMadeDesc: 'Built by Ethiopians, for Ethiopians. Understanding local context and needs.',
      // Contact Page
      contactTitle: 'Contact Us',
      contactSubtitle: "Have questions or need help? We're here to support you.",
      sendMessage: 'Send us a message',
      nameLabel: 'Name',
      namePlaceholder: 'Your name',
      phoneLabel: 'Phone',
      emailLabel: 'Email',
      emailPlaceholder: 'your@email.com',
      subjectLabel: 'Subject',
      generalInquiry: 'General Inquiry',
      technicalSupport: 'Technical Support',
      hospitalPartnership: 'Hospital Partnership',
      feedback: 'Feedback',
      messageLabel: 'Message',
      messagePlaceholder: 'How can we help you?',
      sendButton: 'Send Message',
      getInTouch: 'Get in touch',
      location: 'Location',
      locationValue: 'Addis Ababa, Ethiopia',
      emailAddress: 'Email',
      emailValue: 'support@hakim.et',
      medicalEmergency: 'Medical Emergency?',
      emergencyDesc: "If you're experiencing a medical emergency, please call emergency services immediately.",
      call911: 'Call 911',
      // Hospital Registration
      registerHospital: 'Register Your Hospital',
      registerHospitalDesc: 'Join Hakim to manage your hospital queues efficiently',
      hospitalInfo: 'Hospital Information',
      adminInfo: 'Administrator Information',
      hospitalName: 'Hospital Name',
      hospitalType: 'Hospital Type',
      government: 'Government',
      privateHospital: 'Private',
      ngoHospital: 'NGO/Faith-based',
      city: 'City/Town',
      emailAddress: 'Email Address',
      operatingHoursLabel: 'Operating Hours',
      selectOperatingHours: 'Select operating hours',
      hours247: '24/7 (All Day)',
      hoursBusiness: 'Business Hours (8AM - 6PM)',
      hoursExtended: 'Extended Hours (6AM - 10PM)',
      hoursCustom: 'Custom Hours',
      servicesOffered: 'Services Offered',
      emergencyServices: 'Emergency Services',
      outpatientServices: 'Outpatient Services',
      inpatientServices: 'Inpatient Services',
      laboratoryServices: 'Laboratory Services',
      radiologyServices: 'Radiology/Imaging',
      pharmacyServices: 'Pharmacy',
      maternalHealth: 'Maternal Health',
      pediatricCare: 'Pediatric Care',
      surgicalServices: 'Surgical Services',
      adminName: 'Administrator Name',
      adminPhone: 'Administrator Phone',
      createPassword: 'Create Password',
      confirmPassword: 'Confirm Password',
      passwordRequirements: 'Password must be at least 8 characters',
      agreeToTerms: 'I agree to the Terms of Service and Privacy Policy',
      registerBtn: 'Register Hospital',
      alreadyHaveAccount: 'Already have an account?',
      signInInstead: 'Sign In Instead',
      registerAsHospital: 'Register as Hospital',
      step: 'Step',
      of: 'of',
      continueBtn: 'Continue',
      backBtn: 'Back',
      registrationSuccess: 'Registration Successful!',
      registrationSuccessDesc: 'Your hospital has been registered. You can now sign in to manage your hospital.',
      // Hospital Dashboard
      dashboardTitle: 'Hospital Dashboard',
      overview: 'Overview',
      profile: 'Hospital Profile',
      location: 'Location & Map',
      queues: 'Queue Management',
      departments: 'Departments',
      staff: 'Staff',
      analytics: 'Analytics',
      settings: 'Settings',
      todayPatients: 'Patients Today',
      currentlyWaiting: 'Currently Waiting',
      servedToday: 'Served Today',
      averageWaitTime: 'Avg Wait Time',
      queueStatus: 'Queue Status',
      departmentName: 'Department',
      currentToken: 'Current Token',
      waitingCount: 'Waiting',
      servedCount: 'Served',
      status: 'Status',
      normal: 'Normal',
      busy: 'Busy',
      callNext: 'Call Next',
      markServed: 'Mark Served',
      noShow: 'No Show',
      transfer: 'Transfer',
      viewQueue: 'View Queue',
      manageQueues: 'Manage Queues',
      quickActions: 'Quick Actions',
      addEmergency: 'Add Emergency',
      broadcastAlert: 'Broadcast Alert',
      viewReports: 'View Reports',
      editProfile: 'Edit Profile',
      saveChanges: 'Save Changes',
      hospitalLocation: 'Hospital Location',
      setLocationOnMap: 'Set your hospital location on the map',
      useCurrentLocation: 'Use Current Location',
      clickMapToSet: 'Click on the map to set your hospital location',
      latitude: 'Latitude',
      longitude: 'Longitude',
      serviceRadius: 'Service Radius (km)',
      addDepartment: 'Add Department',
      departmentCreated: 'Department Created',
      departmentNameLabel: 'Department Name',
      departmentDesc: 'Description',
      dailyCapacity: 'Daily Capacity',
      avgServiceTime: 'Avg. Service Time (min)',
      noDepartments: 'No departments added yet',
      addFirstDepartment: 'Add your first department to start managing queues',
      editDepartment: 'Edit',
      deleteDepartment: 'Delete',
      welcomeBack: 'Welcome back',
      manageYourHospital: 'Manage your hospital operations efficiently',
      recentActivity: 'Recent Activity',
      noRecentActivity: 'No recent activity',
      patientsInQueue: 'patients in queue',
      estimatedWait: 'estimated wait',
      servingToken: 'Serving Token',
      calledPatients: 'Called Patients',
      pendingPatients: 'Pending Patients',
      completedPatients: 'Completed Patients',
    },
    am: {
      // Navigation
      home: 'መነሻ',
      features: 'ባህሪያት',
      about: 'ስለ እኛ',
      contact: 'አግኙን',
      signIn: 'ግባ',
      bookQueue: 'ቦታ ያምሩ',
      dashboard: 'ዳሽቦርድ',
      signOut: 'ውጣ',
      profile: 'መገለጫ',
      // Hero
      skipWait: 'መጠባበቂያን ዝለል፣',
      getCareFaster: 'ፈጣር እርዳታ አግኝ',
      heroDesc: 'ሃኪም የኢትዮጵያን ሆስፒታል የመጠባበቂያ ሰርጸት በዲጂታል ቦታ ማስያ፣ የእውነታ ጊዜ አዘምንና የኤስኤምኤስ ማሳወቂያ ይቀይራል።',
      noMoreWaiting: 'የመጠባበቂያ ክፍል የለም።',
      bookYourToken: 'ቦታዎን ያምሩ',
      findNearestHospital: 'ቅርብ ሆስፒታል ያግኙ',
      locating: 'በመፈለግ ላይ...',
      hospitals: 'ሆስፒታሎች',
      departments: 'ክፍሎች',
      regions: 'ክልሎች',
      madeForEthiopia: 'ለኢትዮጵያ የተሰራ',
      // Common
      backToHome: 'ወደ መነሻ ተመለስ',
      backToHospitals: 'ወደ ሆስፒታሎች ተመለስ',
      backToDepartments: 'ወደ ክፍሎች ተመለስ',
      backToDashboard: 'ወደ ዳሽቦርድ ተመለስ',
      selectHospital: 'ሆስፒታል ምረጥ',
      chooseDepartment: 'የድግጅት ቦታ ለማስያ ሆስፒታል ምረጥ',
      selectDepartment: 'ክፍል ምረጥ',
      chooseDepartmentToken: 'የድግጅት ቦታ ለማስያ ክፍል ምረጥ',
      searchHospitals: 'ሆስፒታሎችን ፈልግ...',
      allRegions: 'ሁሉም ክልሎች',
      mapView: 'ካርታ እይታ',
      waiting: 'በመጠባበቂያ',
      inQueue: 'በተደራረበ መስመር',
      estWait: 'የሚገመት ጠባበቂያ',
      currentQueueStatus: 'የአሁኑ የመስመር ሁኔታ',
      completeBooking: 'ቦታዎን ይጨርሱ',
      phoneNumber: 'ስልክ ቁጥር',
      yourName: 'ስምዎ',
      nameOptional: 'ስምዎ (አማራጭ)',
      notesOptional: 'ማስታወሻ (አማራጭ)',
      notesPlaceholder: 'ለህክምተኞች ማስታወሻ...',
      getMyToken: 'ቦታዬን አምጣ',
      // Token page
      yourTokenNumber: 'የእርስዎ ቁጥር',
      status: 'ሁኔታ',
      queuePosition: 'ቦታ',
      estimatedWait: 'የሚገመት ጠባበቂያ',
      currentlyServing: 'አሁን የሚያገለግል',
      smsNotificationsActive: 'የኤስኤስኤስ ማሳወቂያ ንቁ',
      smsDesc: 'ቀጣይ በመስመር ላይ ሲሆኑ እና ጊዜዎ ሲደርስ ኤስኤስኤስ ያገኛሉ።',
      // Hero Section Demo Card
      hospitalLabel: 'ሆስፒታል',
      departmentLabel: 'ክፍል',
      generalMedicine: 'አጠቃላይ ህክምና',
      minutesShort: 'ወደ 25 ደቂቃ',
      ahead: 'ቀድሞ',
      smsAlert: 'ኤስኤስኤስ ማሳወቂያ',
      confirmed: 'ተረጋግጧል!',
      realTimeLabel: 'የእውነታ ጊዜ',
      // FAQ Page
      faqTitle: 'ተዘውትረው የሚጠየቁ ጥያቄዎች',
      faqSubtitle: 'ስለ ሃኪም መደበኛ ጥያቄዎችን መልሶች ያግኙ',
      faqQ1: 'የመጠባበቂያ ቦታ እንዴት ማስያለም?',
      faqA1: 'በቀላሉ ሆስፒታል ይምረጡ፣ ክፍልዎን ይምረጡ፣ ስልክ ቁጥርዎን ያስገቡ፣ እና ቦታዎን ወዲያውኑ ያግኙ። ለመደበኛ ቦታ ማስያ መለያ አያስፈልግም።',
      faqQ2: 'ሃኪምን ለመጠቀም ስማርት ስልክ ያስፈልግኛል?',
      faqA2: 'አይ! መተግበሪያችን በስማርት ስልኮች ላይ በደንብ ቢሰራም፣ በማንኛውም መሰረታዊ ባህሪ ስልክ ላይ የኤስኤስኤስ ማሳወቂያዎችን መቀበል ይችላሉ።',
      faqQ3: 'የእኔ ጊዜ መቼ እንደሆነ እንዴት አውቃለሁ?',
      faqA3: 'ከ10 ታካሚዎች ርቀት ላይ ሲሆኑ፣ ከ5 ታካሚዎች ርቀት ላይ ሲሆኑ፣ እና ጊዜዎ ሲደርስ የኤስኤስኤስ ማሳወቂያዎችን ያገኛሉ። በመተግበሪያው ውስጥ ቦታዎን በእውነታ ጊዜ ማረጋገጥም ይችላሉ።',
      faqQ4: 'ሃኪምን ለመጠቀም ክፍያ አለ?',
      faqA4: 'ሃኪም ለታካሚዎች ሙሉ በሙሉ ነፃ ነው። ምንም የቦታ ማስያ ክፍያ፣ የክፍያ ደንብ፣ ወይም የተደበቀ ክፍያ የለም።',
      faqQ5: 'ቀጠሮዬን መሰረዝ ከፈለግኩ ምን ማድረግ አለብኝ?',
      faqA5: 'ቦታዎን በመተግበሪያው ወይም ሆስፒታሉን በቀጥታ በመደወል መሰረዝ ይችላሉ። ቦታዎ ለሚቀጥለው ታካሚ ይሰጣል።',
      faqQ6: 'ለሌላ ሰው መስያ እችላለሁ?',
      faqA6: 'አዎ! ለቤተሰብ አባላት ወይም ጓደኞች ቦታ ማስያ ይችላሉ። የኤስኤስኤስ ማሳወቂያዎችን ለማግኘት በቦታ ማስያ ጊዜ የእነሱን ስልክ ቁጥር ያስገቡ።',
      faqQ7: 'የትኞቹ ሆስፒታሎች ይደገፋሉ?',
      faqA7: 'ሃኪም በኢትዮጵያ 13 ክልሎች ከ290 በላይ ሆስፒታሎችን ይደግፋል፣ ተጨማሪዎችም በመደበኛነት በመጨመር ላይ።',
      faqQ8: 'የጠባበቂያ ጊዜ ግምቶች ምን ያህል ትክክል ናቸው?',
      faqA8: 'የጠባበቂያ ጊዜዎች በአማካይ አገልግሎት ጊዜ እና በአሁኑ የመስመር ርዝመት ላይ የተመሰረቱ ግምቶች ናቸው። ትክክለኛነትን ቢፈልግም፣ ትክክለኛ የጠባበቂያ ጊዜዎች በጉዳዩ ውስብስብነት ሊለያዩ ይችላሉ።',
      // Privacy Policy Page
      privacyTitle: 'የግላዊነት ፖሊሲ',
      privacySubtitle: 'ግላዊነትዎ ለእኛ አስፈላጊ ነው',
      privacyIntro: 'በሃኪም፣ የእርስዎን ግላዊነት ለመጠበቅ እና የግል የጤና መረጃዎ ደህንነት ለማረጋገጥ ቁርጠኞች ነን። ይህ ፖሊሲ መረጃዎን እንዴት እንደምንሰበስብ፣ እንደምንጠቀም፣ እና እንደምንጠብቅ ያብራራል።',
      privacyCollectTitle: 'የምንሰበስበው መረጃ',
      privacyCollect1: 'ስልክ ቁጥር: ለቦታ ማስያ ማረጋገጫ እና ለመስመር ሁኔታ ማሳወቂያዎች ጥቅም ላይ ይውላል',
      privacyCollect2: 'ስም (አማራጭ): ልምድዎን ለመካከለኛ ለማድረግ ጥቅም ላይ ይውላል',
      privacyCollect3: 'የጤና ክፍል ምርጫ: ወደ ተገቢው ሕክምና አገልግሎት ለማዞር ጥቅም ላይ ይውላል',
      privacyCollect4: 'የመስመር ሁኔታ እና የቀጠሮ ታሪክ: የእውነታ ጊዜ አዘምን ለመስጠት ጥቅም ላይ ይውላል',
      privacyUseTitle: 'መረጃዎን እንዴት እንጠቀማለን',
      privacyUse1: 'የሆስፒታል መጠባበቂያ ቀጠሮዎን ለማስያ እና ለማስተዳደር',
      privacyUse2: 'የመስመር ሁኔታዎን ለማሳወቅ የኤስኤስኤስ ማሳወቂያዎችን ለመላክ',
      privacyUse3: 'አገልግሎቶቻችንን እና የተጠቃሚ ልምድን ለማሻሻል',
      privacyUse4: 'ለጤና ንቅድት ማስተላለፊያ ማይታወቅ ስታቲስቲክስ ለማመንጨት',
      privacySecurityTitle: 'የመረጃ ደህንነት',
      privacySecurity: 'ኢንዱስትሪ-መደበኛ የደህንነት እርምጃዎችን እንጨምራለን ፣ ማመልከቻ፣ ደህንነቱ የተጠበቁ ሰርቨሮች እና መዳረሻ መቆጣጠሪያዎች። የጤና መረጃዎ በኢትዮጵያ የመረጃ ጥበቃ ህጎች እና በአለም አቀፍ ምርጥ ልምዶች መሰረት የተጠበቀ ነው።',
      privacyShareTitle: 'የመረጃ ንጠባበቅ',
      privacyShare: 'መረጃዎን የምናካፍለው ከቦታ ያስያቸው ሆስፒታል ብቻ ነው። መረጃዎን ለማስተላለፊያ ዓላማዎች ለሶስተኛ ወገኖች በጭራሽ አንሸጠውም።',
      privacyContact: 'ስለዚህ የግላዊነት ፖሊሲ ጥያቄዎች ካሉዎት፣ እባክዎ በ privacy@hakim.et ያግኙን',
      // Terms of Service Page
      termsTitle: 'የአገልግሎት ውሎች',
      termsSubtitle: 'እባክዎ ከሃኪም መጠቀምዎ በፊት እነዚህን ውሎች በደንብ ያንብቡ',
      termsIntro: 'ሃኪምን በመጠቀምዎ፣ እነዚህን የአገልግሎት ውሎች ተቀብለዋል ማለት ነው። ሃኪም ታካሚዎች የሆስፒታል ጉብኝቶቻቸውን በደንብ ለማስተዳደር የተነደፈ የመስመር አስተዳደር መድረክ ነው።',
      termsServiceTitle: 'የአገልግሎት መግለጫ',
      termsService: 'ሃኪም በኢትዮጵያ ለተሳትፈው ሆስፒታሎች ዲጂታል የመስመር አስተዳደር አገልግሎቶችን ያቀርባል። አገልግሎታችን የመጠባበቂያ ቦታ ማስያ፣ የሁኔታ አዘምን መቀበል፣ እና የመስመር መረጃ መዳረሻ ያካትታል።',
      termsUserTitle: 'የተጠቃሚ ኃላፊነቶች',
      termsUser1: 'ቀጠሮዎትን በሚያስያት ጊዜ ትክክለኛ መረጃ ያቅርቡ',
      termsUser2: 'ሲመለከቱ ጊዜያዊ በሆነ መልኩ ወደ ሆስፒታል ይድረሱ',
      termsUser3: 'ለሌሎች ቦታ ለመስጠት መጡ የማይችሏቸውን ቀጠሮዎች ይሰርዙ',
      termsUser4: 'የሆስፒታል ሰራተኞችን እና ሌሎች ታካሚዎችን በክብር ያስተናግዱ',
      termsDisclaimerTitle: 'የሕክምና ማስጠንቀቂያ',
      termsDisclaimer: 'ሃኪም የመስመር አስተዳደር መሳሪያ ነው እና የሕክምና ምክር፣ ምርመራ፣ ወይም ህክምና አያቀርብም። ለህይወት አስጊ አደጋዎች፣ ሁልጊዜ 911 ይደውሉ ወይም ወዲያውኑ ወደ ቅርብ አደጋ ጊዜ ክፍል ይሂዱ።',
      termsLimitationTitle: 'የኃላፊነት ገደብ',
      termsLimitation: 'ሃኪም ለህክምና እንክብካቤ ዘግይቶዎች፣ ለሆስፒታል የጊዜ ሰሌዳ ለውጦች፣ ወይም ለማንኛውም የህክምና ውጤቶች ተጠያቂ አይሆንም። የጠባበቂያ ጊዜዎች ግምቶች ናቸው እና በትክክለኛ የታካሚ ፍላጎቶች ሊለያዩ ይችላሉ።',
      termsChangesTitle: 'የውሎች ለውጦች',
      termsChanges: 'እነዚህን ውሎች ከጊዜ ወደ ጊዜ ሊያዘምናቸው እንችላለን። ከለውጦች በኋላ ሃኪምን መቀጠል አዲሱን ውሎች መቀበል ነው።',
      termsContact: 'ስለእነዚህ ውሎች ጥያቄዎች ካሉዎት፣ እባክዎ በ legal@hakim.et ያግኙን',
      // Footer
      footerDesc: 'የኢትዮጵያን ጤና አጠባበቅ በነፃ የመጠባበቂያ አስተዳደር ይቀይራል። መጠባበቂያን ዝለል።',
      quickLinks: 'ፈጣሪ አገናኞች',
      support: 'ድጋፍ',
      emergencyContact: 'የአደጋ ጊዜ ጥሪ',
      nationalEmergency: 'ብሔራዊ አደጋ ጊዜ',
      emergencyDesc: 'ለህይወት አስጊ አደጋዎች እባክዎ 911 ይደውሉ ወይም ወዲያውኑ ወደ ቅርብ አደጋ ጊዜ ክፍል ይሂዱ።',
      hipaaCompliant: 'የHIPAA ተኮር እና የውሂብ ደህንነት',
      madeWith: 'የተሰራ',
      forEthiopia: 'ለኢትዮጵያ',
      // Regional Ambulance
      localAmbulance: 'አካባቢያዊ አምቡላንስ',
      ambulanceForRegion: 'ለክልልዎ አምቡላንስ',
      primaryAmbulance: 'ዋና አደጋ ጊዜ',
      secondaryAmbulance: 'ሁለተኛ',
      redCrossAmbulance: 'የቀይ መስቀል አምቡላንስ',
      callAmbulance: 'አምቡላንስ ደውል',
      // Auth
      verifyOTP: 'OTP አረጋግጥ',
      weSentCode: 'ኮዱን ወደ ላኩት',
      signInPhone: 'በስልክ ቁጥርዎ ይግቡ',
      enterOTP: 'OTP ኮድ አስገባ',
      verifySignIn: 'አረጋግጥ እና ግባ',
      changePhone: 'ስልክ ቁጥር ቀይር',
      continue: 'ቀጥል',
      byContinuing: 'በመቀጠልዎ የእርስዎን ተቀበላለሁ',
      termsOfService: 'የአገልግሎት ውሎች',
      privacyPolicy: 'የግላዊነት ፖሊሲ',
      // Auth Page additional
      signIn: 'ግባ',
      phoneNumberLabel: 'ስልክ ቁጥር',
      nameOptionalLabel: 'ስም (አማራጭ)',
      yourNamePlaceholder: 'ስምዎ',
      enterOTPLabel: 'OTP ኮድ አስገባ',
      verifySignInBtn: 'አረጋግጥ እና ግባ',
      // Emergency
      emergencyAssist: 'የአደጋ ጊዜ እርዳታ',
      triageGuidance: 'ለምልክቶችዎ ትራይጅ መመሪያ አግኝ',
      importantDisclaimer: 'አስፈላጊ ማስጠንቀቂያ',
      disclaimerDesc: 'ይህ ስርዓት የአደጋ ጊዜ አገልግሎቶችን አይተካም። ይህ ለህይወት አስጊ አደጋ ከሆነ እባክዎ 911 ይደውሉ።',
      describeSymptoms: 'ምልክቶችዎን ይግለጹ',
      symptomPlaceholder: 'ምልክቶችዎን በዝርዝር ይግለጹ። ለምሳሌ: ከ30 ደቂቃ በላይ ቁርጠት ያለ የደረት ህመም እና የመተንፈስ ችግር አለብኝ',
      beSpecific: 'ለተሻለ ትራይጅ ግምገማ በተቻለ መጠን ዝርዝር ይሁኑ።',
      contactInfo: 'የእርስዎ መገለጫ መረጃ',
      nearestHospital: 'ቅርብ ሆስፒታል (አማራጭ)',
      selectHospitalOptional: 'ሆስፒታል ምረጥ (አማራጭ)',
      getTriageAssessment: 'ትራይጅ ግምገማ አግኝ',
      severityLevel: 'የከባድነት ደረጃ',
      confidence: 'እምነት',
      recommendation: 'ማሳሰቢያ',
      identifiedKeywords: 'የተለዩ ቁልፍ ቃላት:',
      callEmergency: 'የአደጋ ጊዜ አገልግሎት ደውል (911)',
      reportAnotherSymptom: 'ሌላ ምልክት ያሳውቁ',
      // Find nearest
      nearestHospitals: 'ቅርብ ሆስፒታሎች',
      hospitalsByDistance: 'ከቦታዎ በርቀት የተመደቡ ሆስፒታሎች',
      locationDetected: 'ቦታ ተገኝቷል',
      closestToYou: 'ቅርብ ወደ እርስዎ',
      allNearbyHospitals: 'ሁሉም ቅርብ ሆስፒታሎች',
      viewAllOnMap: 'ሁሉንም በካርታ ይመልከቱ',
      noHospitalsFound: 'ሆስፒታሎች አልተገኙም',
      noHospitalsDesc: 'በአካባቢዎ ሆስፒታሎችን ማግኘት አልተቻለም። እባክዎ በእጅ ይፈልጉ።',
      browseAllHospitals: 'ሁሉንም ሆስፒታሎች አሳይ',
      away: 'ርቀት',
      // Location modal
      findNearestHospital: 'ቅርብ ሆስፒታል ያግኙ',
      useMyLocation: 'የእኔን ቦታ ተጠቀም',
      gettingLocation: 'ቦታ በመፈለግ ላይ...',
      orSelectRegion: 'ወይም ክልልዎን ምረጥ',
      selectRegion: 'ክልል ምረጥ',
      showHospitalsIn: 'ሆስፒታሎችን አሳይ በ',
      cancel: 'ሰርዝ',
      // CTA
      readyToSkip: 'መጠባበቂያን ለመዝለል ዝግጁ?',
      ctaDesc: 'የጤና አጠባበቅ ልምዳቸውን አስቀይረው የተካፈሉ ሺህዎችን ኢትዮጵያውያንን ይቀላቀሉ።',
      startBooking: 'ቦታ ማስያ ጀምር',
      learnMore: 'ተጨማሪ ተምር',
      // Features Section
      featuresTitle: 'ለተሻለ የጤና አጠባበቅ የሚፈልጉት ሁሉም ነገር',
      featuresSubtitle: 'ለኢትዮጵያ ሆስፒታሎች በተለይ የተነደፈ፣ ሃኪም ዘመናዊ የመጠባበቂያ አስተዳደር ወደ እጆችዎ ያመጣል።',
      digitalToken: 'ዲጂታል ቶከን ስርዓት',
      digitalTokenDesc: 'በመስመር ላይ ሳይቆዩ የመጠባበቂያ ቦታዎን ወዲያውኑ ያግኙ። ከስልክዎ በቀላሉ ያምሩ።',
      realTimeUpdates: 'የእውነታ ጊዜ አዘምን',
      realTimeUpdatesDesc: 'ቦታዎን በመስመር ላይ ይከታተሉ። የእርስዎ ጊዜ መቼ እንደሆነ በእርግጥ ይወቁ።',
      smsNotifications: 'የኤስኤስኤስ ማሳወቂያ',
      smsNotificationsDesc: 'ቀጣይ በመስመር ላይ ሲሆኑ የኤስኤስኤስ ማሳወቂያ ያግኙ። በማንኛውም ስልክ ይሰራል።',
      emergencyAssistFeature: 'የአደጋ ጊዜ እርዳታ',
      emergencyAssistDesc: 'ለአደጋ ጊዜዎች ፈጣሪ ትራይጅ ግምገማ። በተቻሎት ጊዜ መመሪያ ያግኙ።',
      multipleHospitals: 'በርካታ ሆስፒታሎች',
      multipleHospitalsDesc: 'በኢትዮጵያ አጠቃላይ ሆስፒታሎችን ድረስ። ወደ እርስዎ ቅርቡን ያግኙ።',
      securePrivate: 'ደህንነት እና ግላዊነት',
      securePrivateDesc: 'የጤና መረጃዎ ደህን ነው። በOTP ደህንነት ማረጋገጫ።',
      // How It Works
      howItWorks: 'እንዴት እንደሚሰራ',
      howItWorksSubtitle: 'የሆስፒታል ጉብኝትዎን በአራት ቀላል ደረጃዎች ያምሩ',
      step1Title: 'ሆስፒታል ምረጥ',
      step1Desc: 'ከአካባቢዎ ሆስፒታሎች ምረጥ',
      step2Title: 'ክፍል ምረጥ',
      step2Desc: 'የሕክምና ክፍልዎን ምረጥ',
      step3Title: 'ቶከን አግኝ',
      step3Desc: 'የመጠባበቂያ ቁጥርዎን ወዲያውኑ ተቀበሉ',
      step4Title: 'በምቾት ቆይ',
      step4Desc: 'የእርስዎ ጊዜ ሲደርስ ማሳወቂያ ያግኙ',
      // Additional
      bookYourTokenNow: 'ቦታዎን አሁኑኑ ያምሩ',
      faq: 'ተዘውትረው የሚጠየቁ ጥያቄዎች',
      hospitalAdminPortal: 'የሆስፒታል አስተዳዳሪ ፖርታል',
      contactUs: 'አግኙን',
      // Features Page
      featuresPageTitle: 'ለኢትዮጵያ ጤና ጠቃሚ ባህሪያት',
      featuresPageTitleHighlight: 'ኢትዮጵያዊ ጤና',
      featuresPageDesc: 'የኢትዮጵያ ሆስፒታሎች ልዩ ፈተናዎችን በግምት ውስጥ በማስገባት የተነደፈ፣ ሃኪም በዝቅተኛ ኢንፍራስትራክቸር ቦታዎች እንኳን የሚሰራ ተግባራዊ መፍትሄዎችን ያቀርባል።',
      queueManagement: 'የመስመር አስተዳደር',
      digitalTokenTitle: 'ዲጂታል ቶከን ስርዓት',
      digitalTokenPageDesc: 'የአካል መጠባበቂያ መስመሮችን በዲጂታል ቶከኖች ይቀይሩ። ታካሚዎች ቦታቸውን ከየትኛውም ቦታ ሊያስይዙ ይችላሉ፣ የቶከን ቁጥራቸውን ወዲያውኑ ሊቀበሉ ይችላሉ፣ እና ጊዜያቸው ሲቃረብ ብቻ ወደ ሆስፒታል ይመጣሉ።',
      instantToken: 'ፈጣሪ ቶከን ማመንጫ',
      estimatedWaitCalc: 'የሚገመት የጠባበቂያ ጊዜ ስሌት',
      realTimePosition: 'የእውነታ ጊዜ ቦታ መከታተያ',
      multipleDepts: 'በርካታ ክፍሎች ድጋፍ',
      tokenNumber: 'የቶከን ቁጥር',
      position: 'ቦታ',
      estWaitShort: 'የሚገመት ጊዜ',
      fifthInLine: 'አምስተኛ ቦታ',
      tokenConfirmed: 'ቶከን ተረጋግጧል',
      tokenConfirmedMsg: 'ቶከን #042 በቲቁር አንበሳ ተረጋግጧል። የሚገመት ጠባበቂያ: 25 ደቂቃ።',
      tenPatientsAhead: '10 ታካሚዎች ቀድመዋል',
      tenPatientsAheadMsg: 'ቶከን #042 - 10 ታካሚዎች ቀድመዋል። እባክዎ ዝግጁ ይሁኑ።',
      itsYourTurn: 'የእርስዎ ጊዜ ነው!',
      itsYourTurnMsg: 'ቶከን #042 - የእርስዎ ጊዜ ነው! እባክዎ ወደ መቁጠሪያው ይሂዱ።',
      smsSystem: 'የኤስኤስኤስ ስርዓት',
      smsNotificationsTitle: 'የኤስኤስኤስ ማሳወቂያዎች',
      smsNotificationsPageDesc: 'በማንኛውም ሞባይል ስልክ ላይ ይሰራል - ስማርት ስልክ አያስፈልግም። ታካሚዎች በቁልፍ ጊዜያት ራስ-ሰር የኤስኤስኤስ ማሳወቂያዎችን ያገኛሉ፡ ሲያስይዙ፣ ከ10 ታካሚዎች ርቀት ላይ ሲሆኑ፣ ከ5 ታካሚዎች ርቀት ላይ ሲሆኑ፣ እና ጊዜያቸው ሲደርስ።',
      worksOnBasicPhones: 'በመሰረታዊ ስልኮች ላይ ይሰራል',
      noAppRequired: 'መተግበሪያ ጭነት አያስፈልግም',
      automatedReminders: 'ራስ-ሰር አስታዋሾች',
      emergencyAlerts: 'የአደጋ ጊዜ ማሳወቂያዎች',
      emergencySupport: 'የአደጋ ጊዜ ድጋፍ',
      emergencyTriageTitle: 'የአደጋ ጊዜ ትራይጅ እርዳታ',
      emergencyTriageDesc: 'ታካሚዎች ምልክቶቻቸውን ሊገልጹ እና ፈጣሪ ትራይጅ መመሪያ ሊቀበሉ ይችላሉ። ስርዓታችን የሊቅ ሁኔታዎችን ለይቶ ለማወቅ እና ታካሚዎችን ወደ ተገቢ እንክብካቤ ያመራል።',
      critical: 'አስጊ',
      criticalDesc: 'ፈጣሪ ትኩረት',
      high: 'ከፍተኛ',
      highDesc: 'አስቸኳይ እንክብካቤ',
      medium: 'መካከለኛ',
      mediumDesc: 'ፈጣሪ ትኩረት',
      low: 'ዝቅተኛ',
      lowDesc: 'መደበኛ መስመር',
      emergencyWarning: 'ይህ ስርዓት ሙያዊ የሕክምና ምክርን ወይም የአደጋ ጊዜ አገልግሎቶችን አይተካም። ለህይወት አስጊ አደጋዎች፣ ሁልጊዜ 911 ይደውሉ።',
      describeSymptoms: 'ምልክቶችዎን ይግለጹ',
      describeSymptomsExample: '"ከ30 ደቂቃ በላይ ቁርጠት ያለ የደረት ህመም እና የመተንፈስ ችግር አለብኝ"',
      highSeverity: 'ከፍተኛ ከባድነት',
      highSeverityMsg: 'ፈጣሪ ሕክምና ያግኙ። 911 ይደውሉ ወይም ወደ ቅርቡ የአደጋ ጊዜ ክፍል ይሂዱ።',
      // About Page
      aboutTitle: 'ስለ',
      aboutSubtitle: 'ለኢትዮጵያ የተሻለ የጤና አጠባበቅ ልምድ መገንባት፣ አንድ መጠባበቂያ በአንድ ጊዜ።',
      ourMission: 'የእኛ ተልዕኮ',
      missionPara1: 'የኢትዮጵያ የጤና አጠባበቅ ስርዓት ከ120 ሚሊዮን በላይ ህዝብን ያገለግላል፣ ሆኖም ብዙ ሆስፒታሎች በተጨናነቁ የመጠባበቂያ ክፍሎች እና በማያማርን የታካሚ ፍሰት ይቸገራሉ። ታካሚዎች ለአጭር ክሊኒክ ጉብኝት ሰዓታትን ይጠብቃሉ፣ ለስራ፣ ለቤተሰብ ወይም ለእረፍት የሚያውል ዋጋ ያለውን ጊዜ በመያዝ።',
      missionPara2: 'ሃኪም ይህን ፈተና በፊት ለመፍታት ተፈጥሯል። የመጠባበቂያ አስተዳደር ሂደትን በማዛመር፣ ሆስፒታሎች ታካሚዎችን በተሻለ መልኩ እንዲያገለግሉ እና ሰዎች ከየትኛውም ቦታ በምቾት ለመጠባበቅ ነፃነት እንዲኖራቸው እናደርጋለን።',
      missionBelief: 'እያንዳንዱ ኢትዮጵያዊ ውጤታማ፣ ክብራዊ የጤና አጠባበቅ መድረስ ይገባዋል የምናምን ነው።',
      populationServed: 'የሚያገለግል ህዝብ',
      avgWaitReduced: 'አማካይ የቀነዘነ ጠባበቂያ',
      builtForEthiopia: 'ለኢትዮጵያ የተሰራ',
      builtForEthiopiaDesc: 'የኢትዮጵያ የጤና አጠባበቅ ኢንፍራስትራክቸር ልዩ ፈተናዎችን በግምት ውስጥ በማስገባት የተነደፈ።',
      smsFirstDesign: 'የኤስኤስኤስ-የመጀመሪያ ዲዛይን',
      smsFirstDesignDesc: 'በመሰረታዊ ባህሪ ስልኮች ላይ ይሰራል። ታካሚዎች ማሳወቂያዎችን ለማግኘት ስማርት ስልክ ወይም በይነርኔት አያስፈልግም።',
      lowBandwidth: 'ዝቅተኛ ባንድዊድዝ',
      lowBandwidthDesc: 'ለአነስተኛ በይነርኔት ግንኙነት ቦታዎች ተመቻችቷል። በ2G ኔትወርክስ እንኳን ፈጣሪ መጫን።',
      regionalCoverage: 'ክልላዊ ሽፋን',
      regionalCoverageDesc: 'በብዙ የኢትዮጵያ ክልሎች ሆስፒታሎችን በመደገፍ፣ በሀገር አቀፍ ደረጃ ለማስፋፋት እቅድ ያለ።',
      offlineSupport: 'ከመስመር ውጭ ድጋፍ',
      offlineSupportDesc: 'ከመስመር ውጭ ለመድረስ PWA-ንቅርብክር። ያለ ንቁ ግንኙነት እንኳን ቶከንዎን ይመልከቱ።',
      availability247: '24/7 ዝግጅት',
      availability247Desc: 'ቦታ በማንኛውም ጊዜ፣ ቀን ወይም ሌሊት ያምሩ። ቦታዎን ለማረጋገጥ በስተች መድረስ አያስፈልግዎትም።',
      ethiopianMade: 'ኢትዮጵያዊ ስራ',
      ethiopianMadeDesc: 'በኢትዮጵያውያን፣ ለኢትዮጵያውያን የተሰራ። የአካባቢ አውድ እና ፍላጎቶችን መረዳት።',
      // Contact Page
      contactTitle: 'አግኙን',
      contactSubtitle: 'ጥያቄዎች አሉዎት ወይም እርዳታ ይፈልጋሉ? እኛ ለመርዳት እየጠበቅን ነው።',
      sendMessage: 'መልእክት ይላኩልን',
      nameLabel: 'ስም',
      namePlaceholder: 'ስምዎ',
      phoneLabel: 'ስልክ',
      emailLabel: 'ኢሜይል',
      emailPlaceholder: 'ኢሜይል@ምሳሌ.com',
      subjectLabel: 'ርዕሰ ጉዳይ',
      generalInquiry: 'አጠቃላይ ጥያቄ',
      technicalSupport: 'ቴክኒካል ድጋፍ',
      hospitalPartnership: 'የሆስፒታል አጋርነት',
      feedback: 'አስተያየት',
      messageLabel: 'መልእክት',
      messagePlaceholder: 'እንዴት ልርድዎ እንችላለን?',
      sendButton: 'መልእክት ላክ',
      getInTouch: 'አግኙን',
      location: 'አድራሻ',
      locationValue: 'አዲስ አበባ፣ ኢትዮጵያ',
      emailAddress: 'ኢሜይል',
      emailValue: 'support@hakim.et',
      medicalEmergency: 'የአደጋ ጊዜ እርዳታ?',
      emergencyDesc: 'የአደጋ ጊዜ ሁኔታ ውስጥ ከሆኑ፣ እባክዎ ወዲያውኑ የአደጋ ጊዜ አገልግሎት ይደውሉ።',
      call911: '911 ደውል',
      // Hospital Registration
      registerHospital: 'ሆስፒታልዎን ይመዝግቡ',
      registerHospitalDesc: 'ሆስፒታል ድግጅቶችዎን በብቃት ለማስተዳደር ሃኪምን ይቀላቀሉ',
      hospitalInfo: 'የሆስፒታል መረጃ',
      adminInfo: 'የአስተዳዳሪ መረጃ',
      hospitalName: 'የሆስፒታል ስም',
      hospitalType: 'የሆስፒታል ዓይነት',
      government: 'መንግስታዊ',
      privateHospital: 'የግል',
      ngoHospital: 'ኤንጂኦ/ሃይማኖታዊ',
      city: 'ከተማ/ከተማ',
      emailAddress: 'ኢሜይል አድራሻ',
      operatingHoursLabel: 'የስራ ሰዓታት',
      selectOperatingHours: 'የስራ ሰዓታት ይምረጡ',
      hours247: '24/7 (ሙሉ ቀን)',
      hoursBusiness: 'የንግድ ሰዓት (8ጠዋት - 6ምሽ)',
      hoursExtended: 'የተራዘመ ሰዓት (6ጠዋት - 10ምሽ)',
      hoursCustom: 'ብጁ ሰዓታት',
      servicesOffered: 'የሚቀርቡ አገልግሎቶች',
      emergencyServices: 'የአደጋ ጊዜ አገልግሎቶች',
      outpatientServices: 'የውጭ ታካሚ አገልግሎቶች',
      inpatientServices: 'የውስጥ ታካሚ አገልግሎች',
      laboratoryServices: 'የላቦራቶሪ አገልግሎቶች',
      radiologyServices: 'ራዲዮሎጂ/ምስል',
      pharmacyServices: 'ፋርማሲ',
      maternalHealth: 'የእናቶች ጤና',
      pediatricCare: 'የህፃናት እንክብካቤ',
      surgicalServices: 'የቀዶ ህክምና አገልግሎቶች',
      adminName: 'የአስተዳዳሪ ስም',
      adminPhone: 'የአስተዳዳሪ ስልክ',
      createPassword: 'የይለፍ ቃል ይፍጠሩ',
      confirmPassword: 'የይለፍ ቃል ያረጋግጡ',
      passwordRequirements: 'የይለፍ ቃል ቢያንስ 8 ቁምፊ መሆን አለበት',
      agreeToTerms: 'የአገልግሎት ውሎችን እና የግላዊነት ፖሊሲን ተቀብያለሁ',
      registerBtn: 'ሆስፒታል መዝግብ',
      alreadyHaveAccount: 'መለያ አሎት?',
      signInInstead: 'ይግቡ ሳይሆን',
      registerAsHospital: 'እንደ ሆስፒታል ተመዝገብ',
      step: 'ደረጃ',
      of: 'ከ',
      continueBtn: 'ቀጥል',
      backBtn: 'ተመለስ',
      registrationSuccess: 'ምዝገባ ተሰክቷል!',
      registrationSuccessDesc: 'ሆስፒታልዎ ተመዝግቧል። አሁን ሆስፒታልዎን ለማስተዳደር መግባት ይችላሉ።',
      // Hospital Dashboard
      dashboardTitle: 'የሆስፒታል ዳሽቦርድ',
      overview: 'አጠቃላይ እይታ',
      profile: 'የሆስፒታል መገለጫ',
      location: 'ቦታ እና ካርታ',
      queues: 'የመስመር አስተዳደር',
      departments: 'ክፍሎች',
      staff: 'ሰራተኞች',
      analytics: 'ትንተና',
      settings: 'ቅንብሮች',
      todayPatients: 'የዛሬ ታካሚዎች',
      currentlyWaiting: 'በአሁኑ ጊዜ በመጠባበቂያ',
      servedToday: 'ዛሬ የተገለጡ',
      averageWaitTime: 'አማካይ የጠባበቂያ ጊዜ',
      queueStatus: 'የመስመር ሁኔታ',
      departmentName: 'ክፍል',
      currentToken: 'አሁን ያለ ቶከን',
      waitingCount: 'በመጠባበቂያ',
      servedCount: 'የተገለጡ',
      status: 'ሁኔታ',
      normal: 'መደበኛ',
      busy: 'በስተት',
      callNext: 'ቀጣዩን ጥራ',
      markServed: 'የተገለገለ ምልክት አድርግ',
      noShow: 'አልተገኘም',
      transfer: 'አስተላልፍ',
      viewQueue: 'መስመር አሳይ',
      manageQueues: 'መስመሮችን አስተዳድር',
      quickActions: 'ፈጣሪ ድርጊቶች',
      addEmergency: 'አደጋ ጊዜ አክል',
      broadcastAlert: 'ማሳወቂያ ላክ',
      viewReports: 'ሪፖርቶች አሳይ',
      editProfile: 'መገለጫ አርትዕ',
      saveChanges: 'ለውጦችን አስቀምጥ',
      hospitalLocation: 'የሆስፒታል ቦታ',
      setLocationOnMap: 'የሆስፒታል ቦታዎን በካርታ ላይ ያስቀምጡ',
      useCurrentLocation: 'አሁን ያለውን ቦታ ተጠቀም',
      clickMapToSet: 'የሆስፒታል ቦታዎን ለማስቀመጥ በካርታ ላይ ጠቅ ያድርጉ',
      latitude: 'ኬክሮስ',
      longitude: 'ኬንትሮስ',
      serviceRadius: 'የአገልግሎት ራዲየስ (ኪሜ)',
      addDepartment: 'ክፍል አክል',
      departmentCreated: 'ክፍል ተፈጥሯል',
      departmentNameLabel: 'የክፍል ስም',
      departmentDesc: 'መግለጫ',
      dailyCapacity: 'ዕለታዊ አቅም',
      avgServiceTime: 'አማካይ አገልግሎት ጊዜ (ደቂቃ)',
      noDepartments: 'ክፍሎች አልተጨመሩም',
      addFirstDepartment: 'መስመሮችን ለማስተዳደር የመጀመሪያዎን ክፍል ያክሉ',
      editDepartment: 'አርትዕ',
      deleteDepartment: 'ሰርዝ',
      welcomeBack: 'እንኳን በደህና ተመለስ',
      manageYourHospital: 'የሆስፒታል ኦፕሬሽኖችዎን በብቃት ያስተዳድሩ',
      recentActivity: 'የቅርብ ጊዜ እንቅስቃሴ',
      noRecentActivity: 'የቅርብ ጊዜ እንቅስቃሴ የለም',
      patientsInQueue: 'ታካሚዎች በመስመር',
      estimatedWait: 'የሚገመት ጠባበቂያ',
      servingToken: 'ቶከን በማገልገል ላይ',
      calledPatients: 'የተጠሩ ታካሚዎች',
      pendingPatients: 'በመጠባበቂያ ላይ ያሉ ታካሚዎች',
      completedPatients: 'የተጠናቀቁ ታካሚዎች',
    }
  };
  
  // Get current translation
  const tr = t[language];
  
  // Data states
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState<Department | null>(null);
  const [currentAppointment, setCurrentAppointment] = useState<Appointment | null>(null);
  const [queueStatus, setQueueStatus] = useState<QueueStatusResponse | null>(null);
  
  // Form states
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [name, setName] = useState('');
  const [notes, setNotes] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [triageResult, setTriageResult] = useState<TriageResult | null>(null);
  
  // Admin states
  const [adminStats, setAdminStats] = useState<unknown>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Location states
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationLoading, setLocationLoading] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);

  // Hospital Registration states
  const [registrationStep, setRegistrationStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const [registrationData, setRegistrationData] = useState<HospitalRegistrationData>({
    hospitalName: '',
    hospitalType: '',
    region: 'Addis Ababa',
    city: '',
    address: '',
    phone: '',
    email: '',
    adminName: '',
    adminPhone: '',
    adminPassword: '',
    confirmPassword: '',
    operatingHours: '24/7',
    services: [],
    agreeToTerms: false,
  });

  // Hospital Dashboard states
  const [dashboardSection, setDashboardSection] = useState<DashboardSection>('overview');
  const [hospitalProfile, setHospitalProfile] = useState<{
    name: string;
    type: string;
    region: string;
    city: string;
    address: string;
    phone: string;
    email: string;
    latitude: number | null;
    longitude: number | null;
    operatingHours: string;
    services: string[];
  } | null>(null);
  const [dashboardStats, setDashboardStats] = useState<{
    todayPatients: number;
    waiting: number;
    served: number;
    avgWaitTime: number;
  }>({ todayPatients: 0, waiting: 0, served: 0, avgWaitTime: 0 });
  const [dashboardQueues, setDashboardQueues] = useState<Array<{
    departmentId: string;
    departmentName: string;
    currentToken: number;
    waiting: number;
    served: number;
    status: string;
  }>>([]);
  const [hospitalDepartments, setHospitalDepartments] = useState<Department[]>([]);
  const [showAddDepartment, setShowAddDepartment] = useState(false);
  const [newDepartment, setNewDepartment] = useState({ name: '', description: '', capacity: 50, avgTime: 15 });

  // Calculate distance between two coordinates using Haversine formula
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371; // Earth's radius in kilometers
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in kilometers
  };

  // Get sorted hospitals by distance
  const getHospitalsByDistance = useCallback(() => {
    if (!userLocation) return [];
    
    return hospitals
      .filter(h => h.latitude && h.longitude)
      .map(h => ({
        ...h,
        distance: calculateDistance(
          userLocation.lat,
          userLocation.lng,
          h.latitude!,
          h.longitude!
        ),
      }))
      .sort((a, b) => a.distance - b.distance);
  }, [hospitals, userLocation]);

  // Default location (Addis Ababa)
  const DEFAULT_LOCATION = { lat: 9.0320, lng: 38.7469 };
  
  // Ethiopian region coordinates (approximate centers)
  const REGION_COORDINATES: Record<string, { lat: number; lng: number }> = {
    'Addis Ababa': { lat: 9.0320, lng: 38.7469 },
    'Oromia': { lat: 8.5400, lng: 39.2700 },
    'Amhara': { lat: 11.6000, lng: 37.3800 },
    'Tigray': { lat: 14.0000, lng: 38.8000 },
    'SNNPR': { lat: 7.0000, lng: 38.0000 },
    'Somali': { lat: 8.0000, lng: 44.0000 },
    'Afar': { lat: 12.0000, lng: 41.0000 },
    'Djibouti': { lat: 11.5886, lng: 43.1456 },
    'Harari': { lat: 9.3100, lng: 42.1300 },
    'Dire Dawa': { lat: 9.6000, lng: 41.8500 },
    'Benishangul-Gumuz': { lat: 10.5000, lng: 34.5000 },
    'Gambela': { lat: 8.2500, lng: 34.5000 },
  };

  // Ethiopian regional ambulance and emergency numbers
  const REGION_AMBULANCE_DATA: Record<string, { 
    primaryNumber: string; 
    primaryName: string; 
    secondaryNumber?: string; 
    secondaryName?: string;
    redCrossNumber: string;
  }> = {
    'Addis Ababa': { 
      primaryNumber: '939', 
      primaryName: 'Addis Ababa Fire & Emergency',
      secondaryNumber: '907',
      secondaryName: 'Red Cross Ambulance',
      redCrossNumber: '907'
    },
    'Oromia': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'Amhara': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'Tigray': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'SNNPR': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'Somali': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'Afar': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'Harari': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'Dire Dawa': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'Benishangul-Gumuz': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'Gambela': { 
      primaryNumber: '907', 
      primaryName: 'Red Cross Ambulance',
      secondaryNumber: '911',
      secondaryName: 'General Emergency',
      redCrossNumber: '907'
    },
    'Djibouti': { 
      primaryNumber: '18', 
      primaryName: 'Emergency Services',
      redCrossNumber: '907'
    },
  };
  
  // State for location permission modal
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [locationNotice, setLocationNotice] = useState<string | null>(null);
  const [selectedRegion, setSelectedRegion] = useState<string>('Addis Ababa');

  // Get ambulance info based on selected region or user location
  const getAmbulanceInfo = useCallback(() => {
    // First try selected region
    if (selectedRegion && REGION_AMBULANCE_DATA[selectedRegion]) {
      return REGION_AMBULANCE_DATA[selectedRegion];
    }
    // Default to Addis Ababa
    return REGION_AMBULANCE_DATA['Addis Ababa'];
  }, [selectedRegion]);

  // Get user's current location with proper permission handling
  const getUserLocation = useCallback(async () => {
    // Clear any previous errors/notices
    setLocationError(null);
    setLocationNotice(null);

    if (!navigator.geolocation) {
      // No geolocation support, show region selector
      setShowLocationModal(true);
      return;
    }

    // Show permission request modal
    setShowLocationModal(true);
  }, []);

  // Actual location request function
  const requestLocation = useCallback(() => {
    setLocationLoading(true);
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setLocationLoading(false);
        setShowLocationModal(false);
        setLocationNotice(null);
        setView('nearest-hospitals');
      },
      (error) => {
        setLocationLoading(false);
        // Show error in modal instead of auto-fallback
        let errorMsg = 'Could not get your location. ';
        if (error.code === error.PERMISSION_DENIED) {
          errorMsg = 'Location permission was denied. Please enable it in your browser settings, or select your region below.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          errorMsg = 'Your device could not determine its location. Please select your region below.';
        } else {
          errorMsg = 'Location request timed out. Please try again or select your region below.';
        }
        setLocationError(errorMsg);
      },
      {
        enableHighAccuracy: false,
        timeout: 15000,
        maximumAge: 0,
      }
    );
  }, []);

  // Use selected region's location
  const useSelectedRegion = useCallback(() => {
    const coords = REGION_COORDINATES[selectedRegion] || DEFAULT_LOCATION;
    setUserLocation(coords);
    setLocationError(null);
    setShowLocationModal(false);
    setLocationNotice(`Showing hospitals near ${selectedRegion}`);
    setView('nearest-hospitals');
  }, [selectedRegion]);

  // Use default location (Addis Ababa)
  const useDefaultLocation = useCallback(() => {
    setUserLocation(DEFAULT_LOCATION);
    setLocationError(null);
    setShowLocationModal(false);
    setLocationNotice('Using Addis Ababa as your location');
    setView('nearest-hospitals');
  }, []);

  // Load hospitals
  const loadHospitals = useCallback(async () => {
    setLoading(true);
    try {
      // Use mock hospitals data (500 hospitals)
      const mockHospitals: Hospital[] = MOCK_HOSPITALS.map((h, index) => ({
        id: h.id,
        name: h.name,
        region: h.region,
        address: h.address,
        latitude: h.latitude,
        longitude: h.longitude,
        emergencyContactNumber: h.emergencyContactNumber,
        isActive: h.isActive,
        adminId: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        departments: h.departments.map((d, i) => ({
          id: `dept-${h.id}-${i}`,
          hospitalId: h.id,
          name: d.name,
          description: `${d.name} department`,
          averageServiceTimeMin: d.avgTime,
          dailyCapacity: d.capacity,
          currentQueueCount: Math.floor(Math.random() * 30),
          isActive: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        })),
      }));
      setHospitals(mockHospitals);
    } catch (error) {
      console.error('Failed to load hospitals:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Load departments
  const loadDepartments = useCallback(async (hospitalId: string) => {
    setLoading(true);
    try {
      // Get departments from the already loaded hospital data
      const hospital = hospitals.find(h => h.id === hospitalId);
      if (hospital && hospital.departments) {
        setDepartments(hospital.departments);
      } else {
        setDepartments([]);
      }
    } catch (error) {
      console.error('Failed to load departments:', error);
    } finally {
      setLoading(false);
    }
  }, [hospitals]);

  // Send OTP
  const sendOtp = async (purpose: 'LOGIN' | 'REGISTRATION' = 'LOGIN') => {
    setLoading(true);
    try {
      const res = await api.post('/api/auth/send-otp', { phone, purpose });
      if (res.success) {
        setOtpSent(true);
        if (res.otpCode) {
          alert(`Development mode: Your OTP is ${res.otpCode}`);
        }
      } else {
        alert(res.error || 'Failed to send OTP');
      }
    } catch (error) {
      console.error('Send OTP error:', error);
      alert('Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  // Verify OTP and login
  const verifyOtp = async () => {
    setLoading(true);
    try {
      const res = await api.post('/api/auth/verify-otp', { phone, otpCode: otp, name });
      if (res.success) {
        login(res.user, res.token);
        setView('home');
        setPhone('');
        setOtp('');
        setOtpSent(false);
      } else {
        alert(res.error || 'Invalid OTP');
      }
    } catch (error) {
      console.error('Verify OTP error:', error);
      alert('Failed to verify OTP');
    } finally {
      setLoading(false);
    }
  };

  // Book appointment
  const bookAppointment = async () => {
    if (!selectedHospital || !selectedDepartment) return;
    
    setLoading(true);
    try {
      const res = await api.post('/api/queue/book', {
        hospitalId: selectedHospital.id,
        departmentId: selectedDepartment.id,
        notes,
        guestPhone: !isAuthenticated ? phone : undefined,
        guestName: !isAuthenticated ? name : undefined,
      }, token || undefined);
      
      if (res.success) {
        setCurrentAppointment(res.appointment);
        setQueueStatus({
          departmentId: selectedDepartment.id,
          departmentName: selectedDepartment.name,
          currentToken: res.currentToken || 0,
          lastTokenIssued: res.tokenNumber,
          totalWaiting: res.queuePosition,
          estimatedWaitMinutes: res.estimatedWaitMinutes,
          nextAvailableSlot: '',
        });
        setView('token');
      } else {
        alert(res.error || 'Failed to book appointment');
      }
    } catch (error) {
      console.error('Book appointment error:', error);
      alert('Failed to book appointment');
    } finally {
      setLoading(false);
    }
  };

  // Report emergency
  const reportEmergency = async () => {
    setLoading(true);
    try {
      const res = await api.post('/api/emergency/report', {
        symptomsText: symptoms,
        hospitalId: selectedHospital?.id,
        contactPhone: phone || user?.phone,
        guestName: name,
      }, token || undefined);
      
      if (res.success) {
        setTriageResult(res.triage);
      } else {
        alert(res.error || 'Failed to report emergency');
      }
    } catch (error) {
      console.error('Emergency report error:', error);
      alert('Failed to report emergency. Please call 911 directly.');
    } finally {
      setLoading(false);
    }
  };

  // Admin: Call next patient
  const callNextPatient = async () => {
    if (!selectedDepartment) return;
    
    setLoading(true);
    try {
      const res = await api.post('/api/admin/call-next', {
        hospitalId: selectedHospital?.id,
        departmentId: selectedDepartment.id,
      }, token || undefined);
      
      if (res.success) {
        alert(`Called patient: Token #${res.data.appointment.tokenNumber}`);
        loadAdminQueue();
      } else {
        alert(res.error || 'Failed to call next patient');
      }
    } catch (error) {
      console.error('Call next error:', error);
      alert('Failed to call next patient');
    } finally {
      setLoading(false);
    }
  };

  // Load admin queue
  const loadAdminQueue = useCallback(async () => {
    if (!selectedHospital) return;
    
    try {
      const res = await api.get(`/api/admin/analytics?hospitalId=${selectedHospital.id}`, token || undefined);
      if (res.success) {
        setAdminStats(res.data);
      }
    } catch (error) {
      console.error('Load admin queue error:', error);
    }
  }, [selectedHospital, token]);

  // Load hospitals on mount
  useEffect(() => {
    loadHospitals();
  }, [loadHospitals]);

  // Refresh queue status periodically
  useEffect(() => {
    if (view === 'token' && currentAppointment) {
      const interval = setInterval(async () => {
        const res = await api.get(`/api/queue/status?appointmentId=${currentAppointment.id}`);
        if (res.success) {
          setQueueStatus(res.data);
        }
      }, 30000);
      return () => clearInterval(interval);
    }
  }, [view, currentAppointment]);

  // Admin: Load data on view change
  useEffect(() => {
    if (view === 'admin-dashboard' && selectedHospital) {
      loadAdminQueue();
    }
  }, [view, selectedHospital, loadAdminQueue]);

  // Loading Spinner Component
  const Spinner = ({ size = 32 }: { size?: number }) => (
    <div className="flex items-center justify-center p-8">
      <ArrowClockwise size={size} className="animate-spin text-emerald-600" />
    </div>
  );

  // Navigation Component
  const Navigation = ({ transparent = false }: { transparent?: boolean }) => (
    <nav className={`relative z-50 transition-all duration-300 ${transparent ? 'bg-transparent' : darkMode ? 'bg-gray-900/95 backdrop-blur-md border-b border-gray-700/50 shadow-sm' : 'bg-white/80 backdrop-blur-md border-b border-gray-200/50 shadow-sm'}`}>
      {/* Top accent bar */}
      {!transparent && (
        <div className="h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500" />
      )}
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button 
            onClick={() => setView('landing')}
            className="flex items-center gap-2.5 group"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/30 group-hover:shadow-emerald-500/50 group-hover:scale-105 transition-all">
              <Heart weight="fill" className="text-white" size={22} />
            </div>
            <span className={`text-xl font-bold bg-gradient-to-r from-emerald-500 to-teal-500 bg-clip-text text-transparent`}>
              Hakim
            </span>
          </button>

          {/* Desktop Navigation */}
          <div className={`hidden md:flex items-center rounded-full px-2 py-1 border ${darkMode ? 'bg-gray-800/80 border-gray-700/50' : 'bg-gray-100/80 border-gray-200/50'}`}>
            <button 
              onClick={() => setView('landing')} 
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${view === 'landing' ? darkMode ? 'bg-gray-700 text-emerald-400 shadow-sm' : 'bg-white text-emerald-600 shadow-sm' : darkMode ? 'text-gray-300 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
            >
              {tr.home}
            </button>
            <button 
              onClick={() => setView('features')} 
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${view === 'features' ? darkMode ? 'bg-gray-700 text-emerald-400 shadow-sm' : 'bg-white text-emerald-600 shadow-sm' : darkMode ? 'text-gray-300 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
            >
              {tr.features}
            </button>
            <button 
              onClick={() => setView('about')} 
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${view === 'about' ? darkMode ? 'bg-gray-700 text-emerald-400 shadow-sm' : 'bg-white text-emerald-600 shadow-sm' : darkMode ? 'text-gray-300 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
            >
              {tr.about}
            </button>
            <button 
              onClick={() => setView('contact')} 
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${view === 'contact' ? darkMode ? 'bg-gray-700 text-emerald-400 shadow-sm' : 'bg-white text-emerald-600 shadow-sm' : darkMode ? 'text-gray-300 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
            >
              {tr.contact}
            </button>
          </div>

          {/* Right side - Language toggle + Dark mode toggle + Auth */}
          <div className="hidden md:flex items-center gap-3">
            {/* Language Toggle */}
            <button
              onClick={toggleLanguage}
              className={`flex items-center gap-1.5 p-2.5 rounded-xl transition-all ${darkMode ? 'bg-gray-800 text-gray-300 hover:bg-gray-700 hover:text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-gray-900'}`}
              title={language === 'en' ? 'Switch to Amharic' : 'Switch to English'}
            >
              <Globe size={18} />
              <span className="text-xs font-medium">{language === 'en' ? 'አማ' : 'EN'}</span>
            </button>

            {/* Dark Mode Toggle */}
            <button
              onClick={toggleDarkMode}
              className={`p-2.5 rounded-xl transition-all ${darkMode ? 'bg-gray-800 text-yellow-400 hover:bg-gray-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-yellow-500'}`}
              title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {darkMode ? <Sun size={20} weight="fill" /> : <Moon size={20} />}
            </button>

            {isAuthenticated ? (
              <>
                <button
                  onClick={() => setView('profile')}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all ${darkMode ? 'text-gray-200 hover:bg-gray-800' : 'text-gray-700 hover:bg-gray-100/80'}`}
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full flex items-center justify-center shadow-sm">
                    <User size={16} className="text-white" />
                  </div>
                  <span className="font-medium">{user?.name?.split(' ')[0] || 'User'}</span>
                </button>
                {user?.role === 'HOSPITAL_ADMIN' && (
                  <button
                    onClick={() => setView('admin-dashboard')}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl transition font-medium border ${darkMode ? 'bg-emerald-900/30 text-emerald-400 hover:bg-emerald-900/50 border-emerald-700/50' : 'bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-600 hover:from-emerald-100 hover:to-teal-100 border-emerald-200/50'}`}
                  >
                    <Gear size={18} />
                    {tr.dashboard}
                  </button>
                )}
                <button
                  onClick={() => { logout(); setView('landing'); }}
                  className={`p-2.5 rounded-xl transition-all ${darkMode ? 'text-gray-500 hover:text-red-400 hover:bg-red-900/30' : 'text-gray-400 hover:text-red-500 hover:bg-red-50'}`}
                >
                  <SignOut size={20} />
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setView('auth')}
                  className={`px-4 py-2.5 rounded-xl transition font-medium ${darkMode ? 'text-gray-300 hover:text-emerald-400 hover:bg-gray-800' : 'text-gray-700 hover:text-emerald-600 hover:bg-gray-100/80'}`}
                >
                  {tr.signIn}
                </button>
                <button
                  onClick={() => { setView('hospitals'); }}
                  className="px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-medium hover:shadow-lg hover:shadow-emerald-500/30 hover:-translate-y-0.5 transition-all"
                >
                  {tr.bookQueue}
                </button>
              </>
            )}
          </div>

          {/* Mobile - Language toggle + Dark mode toggle + Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={toggleLanguage}
              className={`flex items-center gap-1 p-2 rounded-xl transition-all ${darkMode ? 'bg-gray-800 text-gray-300' : 'bg-gray-100 text-gray-600'}`}
            >
              <Globe size={18} />
              <span className="text-xs font-medium">{language === 'en' ? 'አማ' : 'EN'}</span>
            </button>
            <button
              onClick={toggleDarkMode}
              className={`p-2.5 rounded-xl transition-all ${darkMode ? 'bg-gray-800 text-yellow-400' : 'bg-gray-100 text-gray-600'}`}
            >
              {darkMode ? <Sun size={20} weight="fill" /> : <Moon size={20} />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`p-2.5 rounded-xl transition-all ${darkMode ? 'text-gray-300 hover:text-emerald-400 hover:bg-gray-800' : 'text-gray-600 hover:text-emerald-600 hover:bg-gray-100/80'}`}
            >
              {mobileMenuOpen ? <X size={24} /> : <List size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className={`md:hidden border-t shadow-lg ${darkMode ? 'bg-gray-900/95 backdrop-blur-md border-gray-700/50' : 'bg-white/95 backdrop-blur-md border-gray-200/50'}`}
          >
            <div className="px-4 py-4 space-y-1">
              <button 
                onClick={() => { setView('landing'); setMobileMenuOpen(false); }} 
                className={`block w-full text-left px-4 py-3 rounded-xl transition-all ${view === 'landing' ? darkMode ? 'bg-emerald-900/30 text-emerald-400 font-medium border border-emerald-700/50' : 'bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-600 font-medium border border-emerald-100' : darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100/80'}`}
              >
                Home
              </button>
              <button 
                onClick={() => { setView('features'); setMobileMenuOpen(false); }} 
                className={`block w-full text-left px-4 py-3 rounded-xl transition-all ${view === 'features' ? darkMode ? 'bg-emerald-900/30 text-emerald-400 font-medium border border-emerald-700/50' : 'bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-600 font-medium border border-emerald-100' : darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100/80'}`}
              >
                Features
              </button>
              <button 
                onClick={() => { setView('about'); setMobileMenuOpen(false); }} 
                className={`block w-full text-left px-4 py-3 rounded-xl transition-all ${view === 'about' ? darkMode ? 'bg-emerald-900/30 text-emerald-400 font-medium border border-emerald-700/50' : 'bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-600 font-medium border border-emerald-100' : darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100/80'}`}
              >
                About
              </button>
              <button 
                onClick={() => { setView('contact'); setMobileMenuOpen(false); }} 
                className={`block w-full text-left px-4 py-3 rounded-xl transition-all ${view === 'contact' ? darkMode ? 'bg-emerald-900/30 text-emerald-400 font-medium border border-emerald-700/50' : 'bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-600 font-medium border border-emerald-100' : darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100/80'}`}
              >
                Contact
              </button>
              <hr className={`my-3 ${darkMode ? 'border-gray-700/50' : 'border-gray-200/50'}`} />
              {isAuthenticated ? (
                <>
                  <button 
                    onClick={() => { setView('profile'); setMobileMenuOpen(false); }} 
                    className={`block w-full text-left px-4 py-3 rounded-xl transition-all ${darkMode ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100/80'}`}
                  >
                    Profile
                  </button>
                  <button 
                    onClick={() => { logout(); setView('landing'); setMobileMenuOpen(false); }} 
                    className={`block w-full text-left px-4 py-3 rounded-xl transition-all ${darkMode ? 'text-red-400 hover:bg-red-900/30' : 'text-red-500 hover:bg-red-50'}`}
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <div className="pt-2 space-y-2">
                  <button 
                    onClick={() => { setView('auth'); setMobileMenuOpen(false); }} 
                    className={`block w-full text-center px-4 py-3 border rounded-xl transition-all ${darkMode ? 'border-gray-700 hover:bg-gray-800 text-gray-300' : 'border-gray-200 hover:bg-gray-50'}`}
                  >
                    Sign In
                  </button>
                  <button 
                    onClick={() => { setView('hospitals'); setMobileMenuOpen(false); }} 
                    className="block w-full text-center px-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-medium shadow-lg shadow-emerald-500/20"
                  >
                    Book Queue
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );

  // Hero Section for Landing
  const HeroSection = () => (
    <section className={`relative min-h-screen flex items-center overflow-hidden transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
      {/* Background Pattern */}
      <div className="absolute inset-0 overflow-hidden">
        <div className={`absolute -top-40 -right-40 w-96 h-96 rounded-full blur-3xl ${darkMode ? 'bg-emerald-900/20' : 'bg-emerald-300/30'}`} />
        <div className={`absolute top-1/3 -left-40 w-[500px] h-[500px] rounded-full blur-3xl ${darkMode ? 'bg-teal-900/20' : 'bg-teal-200/30'}`} />
        <div className={`absolute bottom-0 right-1/4 w-72 h-72 rounded-full blur-3xl ${darkMode ? 'bg-cyan-900/20' : 'bg-cyan-200/20'}`} />
        {/* Grid pattern */}
        <div className={`absolute inset-0 bg-[linear-gradient(to_right,_1px,transparent_1px),linear-gradient(to_bottom,_1px,transparent_1px)] bg-[size:24px_24px] ${darkMode ? 'bg-gray-800/20' : 'bg-gray-400/10'}`} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-16">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Badge */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium mb-8 shadow-sm ${darkMode ? 'bg-emerald-900/50 border border-emerald-700/50 text-emerald-300' : 'bg-gradient-to-r from-emerald-100 to-teal-100 border border-emerald-200/50 text-emerald-700'}`}
            >
              <Sparkle size={16} weight="fill" className={darkMode ? 'text-emerald-400' : 'text-emerald-500'} />
              <span>{tr.madeForEthiopia}</span>
              <span className="text-lg">🇪🇹</span>
            </motion.div>

            {/* Headline */}
            <h1 className={`text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {tr.skipWait}
              <br />
              <span className="bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 bg-clip-text text-transparent">
                {tr.getCareFaster}
              </span>
            </h1>

            {/* Description */}
            <p className={`text-lg sm:text-xl mb-10 leading-relaxed max-w-xl ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              {tr.heroDesc} <span className={darkMode ? 'text-emerald-400 font-medium' : 'text-emerald-600 font-medium'}>{tr.noMoreWaiting}</span>
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <button
                onClick={() => setView('hospitals')}
                className="group relative px-8 py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-2xl font-semibold text-lg hover:shadow-xl hover:shadow-emerald-500/30 transition-all flex items-center justify-center gap-2 overflow-hidden"
              >
                <span className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-teal-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                <span className="relative flex items-center gap-2">
                  {tr.bookYourToken}
                  <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </span>
              </button>
              <button
                onClick={getUserLocation}
                disabled={locationLoading}
                className={`group px-8 py-4 rounded-2xl font-semibold text-lg transition-all flex items-center justify-center gap-2 disabled:opacity-70 border-2 ${darkMode ? 'bg-gray-800 border-gray-700 text-gray-200 hover:border-blue-500 hover:bg-gray-750' : 'bg-white border-gray-200 text-gray-700 hover:border-blue-300 hover:bg-blue-50 hover:shadow-lg'}`}
              >
                {locationLoading ? (
                  <>
                    <ArrowClockwise size={20} className="animate-spin" />
                    {tr.locating}
                  </>
                ) : (
                  <>
                    <Crosshair size={20} className="text-blue-500 group-hover:scale-110 transition-transform" />
                    {tr.findNearestHospital}
                  </>
                )}
              </button>
            </div>

            {/* Stats */}
            <div className={`grid grid-cols-3 gap-8 pt-8 border-t ${darkMode ? 'border-gray-800' : 'border-gray-200'}`}>
              <div className="text-center sm:text-left">
                <p className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">292+</p>
                <p className={darkMode ? 'text-gray-500 text-sm mt-1' : 'text-gray-500 text-sm mt-1'}>{tr.hospitals}</p>
              </div>
              <div className="text-center sm:text-left">
                <p className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">4,088+</p>
                <p className={darkMode ? 'text-gray-500 text-sm mt-1' : 'text-gray-500 text-sm mt-1'}>{tr.departments}</p>
              </div>
              <div className="text-center sm:text-left">
                <p className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">13</p>
                <p className={darkMode ? 'text-gray-500 text-sm mt-1' : 'text-gray-500 text-sm mt-1'}>{tr.regions}</p>
              </div>
            </div>
          </motion.div>

          {/* Right Content - Illustration */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="relative w-full aspect-square max-w-lg mx-auto">
              {/* Main Card */}
              <div className={`absolute inset-0 backdrop-blur-sm rounded-3xl shadow-2xl p-8 flex flex-col justify-center border ${darkMode ? 'bg-gray-900/90 border-gray-700 shadow-emerald-900/20' : 'bg-white/90 border-gray-100 shadow-emerald-500/10'}`}>
                <div className="text-center mb-6">
                  <div className={`inline-flex items-center justify-center w-20 h-20 rounded-2xl mb-4 shadow-inner ${darkMode ? 'bg-gradient-to-br from-emerald-900/50 to-teal-900/50' : 'bg-gradient-to-br from-emerald-100 to-teal-100'}`}>
                    <Ticket size={40} className="text-emerald-500" weight="duotone" />
                  </div>
                  <p className={darkMode ? 'text-gray-400 text-sm' : 'text-gray-500 text-sm'}>{tr.yourTokenNumber}</p>
                  <p className={`text-6xl font-bold mt-2 ${darkMode ? 'bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent' : 'bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent'}`}>#042</p>
                </div>

                <div className="space-y-3">
                  <div className={`flex items-center justify-between p-4 rounded-xl transition ${darkMode ? 'bg-gray-800/80 hover:bg-gray-750/80' : 'bg-gray-50/80 hover:bg-gray-100/80'}`}>
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                        <Hospital size={20} className="text-emerald-500" />
                      </div>
                      <div>
                        <p className={darkMode ? 'text-xs text-gray-500' : 'text-xs text-gray-500'}>{tr.hospitalLabel}</p>
                        <p className={darkMode ? 'font-medium text-gray-200' : 'font-medium text-gray-900'}>Tikur Anbessa</p>
                      </div>
                    </div>
                    <CaretRight size={18} className={darkMode ? 'text-gray-600' : 'text-gray-400'} />
                  </div>

                  <div className={`flex items-center justify-between p-4 rounded-xl transition ${darkMode ? 'bg-gray-800/80 hover:bg-gray-750/80' : 'bg-gray-50/80 hover:bg-gray-100/80'}`}>
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${darkMode ? 'bg-teal-900/50' : 'bg-teal-100'}`}>
                        <Stethoscope size={20} className="text-teal-500" />
                      </div>
                      <div>
                        <p className={darkMode ? 'text-xs text-gray-500' : 'text-xs text-gray-500'}>{tr.departmentLabel}</p>
                        <p className={darkMode ? 'font-medium text-gray-200' : 'font-medium text-gray-900'}>{tr.generalMedicine}</p>
                      </div>
                    </div>
                    <CaretRight size={18} className={darkMode ? 'text-gray-600' : 'text-gray-400'} />
                  </div>

                  <div className={`flex items-center justify-between p-4 rounded-xl border ${darkMode ? 'bg-gradient-to-r from-emerald-900/30 to-teal-900/30 border-emerald-800/50' : 'bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-100'}`}>
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${darkMode ? 'bg-emerald-800/50' : 'bg-emerald-200/50'}`}>
                        <Timer size={20} className="text-emerald-500" />
                      </div>
                      <div>
                        <p className={darkMode ? 'text-xs text-emerald-400' : 'text-xs text-emerald-600'}>{tr.estimatedWait}</p>
                        <p className={darkMode ? 'font-bold text-emerald-400' : 'font-bold text-emerald-700'}>{tr.minutesShort}</p>
                      </div>
                    </div>
                    <div className={`text-right rounded-lg px-3 py-1 ${darkMode ? 'bg-gray-800/50' : 'bg-white/50'}`}>
                      <p className="text-2xl font-bold text-emerald-500">5</p>
                      <p className={darkMode ? 'text-xs text-emerald-500' : 'text-xs text-emerald-500'}>{tr.ahead}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating Elements */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className={`absolute -top-4 -right-4 rounded-2xl shadow-xl p-4 border ${darkMode ? 'bg-gray-800 border-gray-700 shadow-gray-900/50' : 'bg-white border-gray-100 shadow-gray-200/50'}`}
              >
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${darkMode ? 'bg-amber-900/50' : 'bg-amber-100'}`}>
                    <Bell size={16} className="text-amber-500" weight="fill" />
                  </div>
                  <span className={darkMode ? 'text-sm font-medium text-gray-200' : 'text-sm font-medium text-gray-700'}>{tr.smsAlert}</span>
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1.5 }}
                className={`absolute -bottom-4 -left-4 rounded-2xl shadow-xl p-4 border ${darkMode ? 'bg-gray-800 border-gray-700 shadow-gray-900/50' : 'bg-white border-gray-100 shadow-gray-200/50'}`}
              >
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                    <CheckCircle size={16} className="text-emerald-500" weight="fill" />
                  </div>
                  <span className={darkMode ? 'text-sm font-medium text-gray-200' : 'text-sm font-medium text-gray-700'}>{tr.confirmed}</span>
                </div>
              </motion.div>

              {/* Additional floating element */}
              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
                className="absolute top-1/3 -left-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-xl shadow-blue-500/30 p-3"
              >
                <div className="flex items-center gap-2 text-white">
                  <Clock size={16} weight="fill" />
                  <span className="text-xs font-medium">{tr.realTimeLabel}</span>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );

  // Features Section
  const FeaturesSection = () => (
    <section className={`py-24 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className={`text-3xl sm:text-4xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
            {tr.featuresTitle}
          </h2>
          <p className={`text-xl max-w-2xl mx-auto ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            {tr.featuresSubtitle}
          </p>
        </motion.div>

        <motion.div
          variants={staggerContainer}
          initial="initial"
          whileInView="animate"
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {[
            {
              icon: Ticket,
              title: tr.digitalToken,
              description: tr.digitalTokenDesc,
              color: 'emerald',
            },
            {
              icon: Clock,
              title: tr.realTimeUpdates,
              description: tr.realTimeUpdatesDesc,
              color: 'blue',
            },
            {
              icon: CellTower,
              title: tr.smsNotifications,
              description: tr.smsNotificationsDesc,
              color: 'purple',
            },
            {
              icon: Ambulance,
              title: tr.emergencyAssistFeature,
              description: tr.emergencyAssistDesc,
              color: 'red',
            },
            {
              icon: Buildings,
              title: tr.multipleHospitals,
              description: tr.multipleHospitalsDesc,
              color: 'orange',
            },
            {
              icon: Shield,
              title: tr.securePrivate,
              description: tr.securePrivateDesc,
              color: 'teal',
            },
          ].map((feature, index) => (
            <motion.div
              key={index}
              variants={fadeIn}
              className={`group p-8 rounded-3xl transition-all duration-300 ${darkMode ? 'bg-gray-800/50 hover:bg-gray-800' : 'bg-gray-50 hover:bg-white hover:shadow-xl hover:shadow-gray-200/50'}`}
            >
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform ${darkMode ? `bg-${feature.color}-900/50` : `bg-${feature.color}-100`}`}>
                <feature.icon size={28} className={`text-${feature.color}-500`} />
              </div>
              <h3 className={`text-xl font-bold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{feature.title}</h3>
              <p className={`leading-relaxed ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );

  // How It Works Section
  const HowItWorksSection = () => (
    <section className={`py-24 transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gradient-to-b from-gray-50 to-white'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className={`text-3xl sm:text-4xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
            {tr.howItWorks}
          </h2>
          <p className={`text-xl max-w-2xl mx-auto ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            {tr.howItWorksSubtitle}
          </p>
        </motion.div>

        <div className="grid md:grid-cols-4 gap-8">
          {[
            { step: '01', icon: Hospital, title: tr.step1Title, description: tr.step1Desc },
            { step: '02', icon: Stethoscope, title: tr.step2Title, description: tr.step2Desc },
            { step: '03', icon: Ticket, title: tr.step3Title, description: tr.step3Desc },
            { step: '04', icon: Bell, title: tr.step4Title, description: tr.step4Desc },
          ].map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative text-center"
            >
              {/* Connector Line */}
              {index < 3 && (
                <div className={`hidden md:block absolute top-12 left-[60%] w-[80%] h-0.5 ${darkMode ? 'bg-gradient-to-r from-emerald-800 to-transparent' : 'bg-gradient-to-r from-emerald-300 to-transparent'}`} />
              )}
              
              <div className="relative inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl shadow-lg shadow-emerald-500/25 mb-6">
                <item.icon size={40} className="text-white" />
                <span className={`absolute -top-2 -right-2 w-8 h-8 rounded-full shadow-md flex items-center justify-center text-sm font-bold ${darkMode ? 'bg-gray-800 text-emerald-400' : 'bg-white text-emerald-600'}`}>
                  {item.step}
                </span>
              </div>
              <h3 className={`text-lg font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{item.title}</h3>
              <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );

  // CTA Section
  const CTASection = () => (
    <section className="py-24 bg-gradient-to-r from-emerald-600 to-teal-600 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-64 h-64 bg-white/10 rounded-full -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-white/5 rounded-full translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            {tr.readyToSkip}
          </h2>
          <p className="text-xl text-emerald-100 mb-8 max-w-2xl mx-auto">
            {tr.ctaDesc}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => setView('hospitals')}
              className="px-8 py-4 bg-white text-emerald-600 rounded-2xl font-semibold text-lg hover:shadow-xl transition-all"
            >
              {tr.bookYourTokenNow}
            </button>
            <button
              onClick={() => setView('emergency')}
              className="px-8 py-4 bg-white/10 text-white rounded-2xl font-semibold text-lg border-2 border-white/30 hover:bg-white/20 transition-all flex items-center justify-center gap-2"
            >
              <Ambulance size={20} />
              {tr.emergencyAssist}
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );

  // Footer
  const Footer = () => (
    <footer className="relative bg-gradient-to-b from-gray-900 via-gray-900 to-gray-950 text-white overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-teal-500/5 rounded-full blur-3xl" />
      </div>

      {/* Top gradient line */}
      <div className="h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-11 h-11 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <Heart weight="fill" className="text-white" size={24} />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">Hakim</span>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              {tr.footerDesc}
            </p>
            <div className="flex gap-3">
              <button onClick={() => setView('contact')} className="w-10 h-10 bg-gray-800/50 border border-gray-700/50 rounded-xl flex items-center justify-center hover:bg-emerald-600 hover:border-emerald-500 transition-all group">
                <ChatCircle size={18} className="text-gray-400 group-hover:text-white transition" />
              </button>
              <a href="tel:+251911000000" className="w-10 h-10 bg-gray-800/50 border border-gray-700/50 rounded-xl flex items-center justify-center hover:bg-emerald-600 hover:border-emerald-500 transition-all group">
                <Phone size={18} className="text-gray-400 group-hover:text-white transition" />
              </a>
              <a href="mailto:support@hakim.et" className="w-10 h-10 bg-gray-800/50 border border-gray-700/50 rounded-xl flex items-center justify-center hover:bg-emerald-600 hover:border-emerald-500 transition-all group">
                <EnvelopeSimple size={18} className="text-gray-400 group-hover:text-white transition" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white mb-5 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
              {tr.quickLinks}
            </h4>
            <ul className="space-y-3">
              <li><button onClick={() => setView('hospitals')} className="text-gray-400 hover:text-emerald-400 transition flex items-center gap-2 group"><CaretRight size={14} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />{tr.bookQueue}</button></li>
              <li><button onClick={() => setView('emergency')} className="text-gray-400 hover:text-emerald-400 transition flex items-center gap-2 group"><CaretRight size={14} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />{tr.emergencyAssist}</button></li>
              <li><button onClick={() => setView('features')} className="text-gray-400 hover:text-emerald-400 transition flex items-center gap-2 group"><CaretRight size={14} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />{tr.features}</button></li>
              <li><button onClick={() => setView('about')} className="text-gray-400 hover:text-emerald-400 transition flex items-center gap-2 group"><CaretRight size={14} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />{tr.about}</button></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold text-white mb-5 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-teal-500 rounded-full"></span>
              {tr.support}
            </h4>
            <ul className="space-y-3">
              <li><button onClick={() => setView('contact')} className="text-gray-400 hover:text-teal-400 transition flex items-center gap-2 group"><CaretRight size={14} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />{tr.contactUs}</button></li>
              <li><button onClick={() => setView('faq')} className="text-gray-400 hover:text-teal-400 transition flex items-center gap-2 group"><CaretRight size={14} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />{tr.faq}</button></li>
              <li><button onClick={() => setView('privacy')} className="text-gray-400 hover:text-teal-400 transition flex items-center gap-2 group"><CaretRight size={14} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />{tr.privacyPolicy}</button></li>
              <li><button onClick={() => setView('terms')} className="text-gray-400 hover:text-teal-400 transition flex items-center gap-2 group"><CaretRight size={14} className="opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all" />{tr.termsOfService}</button></li>
              <li><button onClick={() => setView('admin-login')} className="text-gray-500 hover:text-emerald-400 transition text-sm mt-2">{tr.hospitalAdminPortal} →</button></li>
            </ul>
          </div>

          {/* Emergency */}
          <div>
            <h4 className="font-semibold text-white mb-5 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span>
              {tr.emergencyContact}
            </h4>
            <div className="space-y-4">
              {/* Local Ambulance for Region */}
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                <p className="text-xs text-emerald-400 mb-2">{tr.localAmbulance} ({selectedRegion})</p>
                <a href={`tel:${getAmbulanceInfo().primaryNumber}`} className="group flex items-center gap-3 hover:bg-emerald-500/10 rounded-lg transition -mx-1 px-1 py-1">
                  <div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center group-hover:bg-emerald-500/30 transition">
                    <Ambulance size={20} className="text-emerald-400" />
                  </div>
                  <div>
                    <p className="font-semibold text-emerald-400">{getAmbulanceInfo().primaryNumber}</p>
                    <p className="text-xs text-gray-500">{getAmbulanceInfo().primaryName}</p>
                  </div>
                </a>
                {getAmbulanceInfo().secondaryNumber && (
                  <a href={`tel:${getAmbulanceInfo().secondaryNumber}`} className="group flex items-center gap-3 hover:bg-emerald-500/10 rounded-lg transition -mx-1 px-1 py-1 mt-2">
                    <div className="w-8 h-8 bg-emerald-500/10 rounded-lg flex items-center justify-center">
                      <Phone size={16} className="text-emerald-400/70" />
                    </div>
                    <div>
                      <p className="font-medium text-emerald-400/80 text-sm">{getAmbulanceInfo().secondaryNumber}</p>
                      <p className="text-xs text-gray-600">{getAmbulanceInfo().secondaryName}</p>
                    </div>
                  </a>
                )}
              </div>

              {/* National Emergency */}
              <a href="tel:911" className="group flex items-center gap-3 p-3 bg-red-500/10 border border-red-500/20 rounded-xl hover:bg-red-500/20 transition">
                <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center group-hover:bg-red-500/30 transition">
                  <Phone size={20} className="text-red-400" />
                </div>
                <div>
                  <p className="font-semibold text-red-400">911</p>
                  <p className="text-xs text-gray-500">{tr.nationalEmergency}</p>
                </div>
              </a>
              <p className="text-xs text-gray-500 leading-relaxed">
                {tr.emergencyDesc}
              </p>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="py-8 border-y border-gray-800/50 grid grid-cols-3 gap-8 mb-8">
          <div className="text-center">
            <p className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">292+</p>
            <p className="text-gray-500 text-sm">{tr.hospitals}</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">4,088+</p>
            <p className="text-gray-500 text-sm">{tr.departments}</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">13</p>
            <p className="text-gray-500 text-sm">{tr.regions}</p>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm flex items-center gap-2">
            © 2026 Hakim Health. {tr.madeWith} 
            <Heart size={14} weight="fill" className="text-red-500" /> 
            {tr.forEthiopia} 
            <span className="text-lg">🇪🇹</span>
          </p>
          <div className="flex items-center gap-2 px-4 py-2 bg-gray-800/30 rounded-full text-gray-400 text-sm border border-gray-800/50">
            <Shield size={14} className="text-emerald-500" />
            <span>{tr.hipaaCompliant}</span>
          </div>
        </div>
      </div>
    </footer>
  );

  // ===============================
  // PAGE VIEWS
  // ===============================

  // Landing Page
  const LandingPage = () => (
    <div className="min-h-screen">
      <Navigation transparent />
      <HeroSection />
      <FeaturesSection />
      <HowItWorksSection />
      <CTASection />
      <Footer />
    </div>
  );

  // Features Page
  const FeaturesPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-white'}`}>
      <Navigation />
      
      {/* Hero */}
      <section className={`pt-8 pb-16 transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className={`text-4xl sm:text-5xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {tr.featuresPageTitle}
              <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                {' '}{tr.featuresPageTitleHighlight}
              </span>
            </h1>
            <p className={`text-xl max-w-3xl mx-auto ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.featuresPageDesc}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Features */}
      <section className={`py-24 transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-32">
          {/* Token System */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="grid lg:grid-cols-2 gap-12 items-center"
          >
            <div>
              <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-6 ${darkMode ? 'bg-emerald-900/50 text-emerald-400' : 'bg-emerald-100 text-emerald-700'}`}>
                <Ticket size={16} weight="fill" />
                {tr.queueManagement}
              </div>
              <h2 className={`text-3xl sm:text-4xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {tr.digitalTokenTitle}
              </h2>
              <p className={`text-lg mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {tr.digitalTokenPageDesc}
              </p>
              <ul className="space-y-4">
                {[
                  tr.instantToken,
                  tr.estimatedWaitCalc,
                  tr.realTimePosition,
                  tr.multipleDepts,
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <CheckCircle size={20} className="text-emerald-500" weight="fill" />
                    <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className={`rounded-3xl p-8 ${darkMode ? 'bg-gradient-to-br from-emerald-900/30 to-teal-900/30' : 'bg-gradient-to-br from-emerald-100 to-teal-100'}`}>
              <div className={`rounded-2xl shadow-xl p-6 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <div className="text-center mb-6">
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.tokenNumber}</p>
                  <p className={`text-5xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>#042</p>
                </div>
                <div className="space-y-3">
                  <div className={`flex justify-between items-center p-3 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>{tr.position}</span>
                    <span className="font-bold text-emerald-600">{tr.fifthInLine}</span>
                  </div>
                  <div className={`flex justify-between items-center p-3 rounded-lg ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>{tr.estWaitShort}</span>
                    <span className={`font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>~25 min</span>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* SMS Notifications */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="grid lg:grid-cols-2 gap-12 items-center"
          >
            <div className={`order-2 lg:order-1 rounded-3xl p-8 ${darkMode ? 'bg-gradient-to-br from-blue-900/30 to-purple-900/30' : 'bg-gradient-to-br from-blue-100 to-purple-100'}`}>
              <div className="space-y-4">
                {[
                  { title: tr.tokenConfirmed, message: tr.tokenConfirmedMsg },
                  { title: tr.tenPatientsAhead, message: tr.tenPatientsAheadMsg },
                  { title: tr.itsYourTurn, message: tr.itsYourTurnMsg },
                ].map((sms, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className={`rounded-xl shadow-lg p-4 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${darkMode ? 'bg-blue-900/50' : 'bg-blue-100'}`}>
                        <CellTower size={20} className="text-blue-600" />
                      </div>
                      <div>
                        <p className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{sms.title}</p>
                        <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{sms.message}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-6 ${darkMode ? 'bg-blue-900/50 text-blue-400' : 'bg-blue-100 text-blue-700'}`}>
                <CellTower size={16} weight="fill" />
                {tr.smsSystem}
              </div>
              <h2 className={`text-3xl sm:text-4xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {tr.smsNotificationsTitle}
              </h2>
              <p className={`text-lg mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {tr.smsNotificationsPageDesc}
              </p>
              <ul className="space-y-4">
                {[
                  tr.worksOnBasicPhones,
                  tr.noAppRequired,
                  tr.automatedReminders,
                  tr.emergencyAlerts,
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <CheckCircle size={20} className="text-blue-500" weight="fill" />
                    <span className={darkMode ? 'text-gray-300' : 'text-gray-700'}>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          {/* Emergency Triage */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="grid lg:grid-cols-2 gap-12 items-center"
          >
            <div>
              <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-6 ${darkMode ? 'bg-red-900/50 text-red-400' : 'bg-red-100 text-red-700'}`}>
                <Ambulance size={16} weight="fill" />
                {tr.emergencySupport}
              </div>
              <h2 className={`text-3xl sm:text-4xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {tr.emergencyTriageTitle}
              </h2>
              <p className={`text-lg mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {tr.emergencyTriageDesc}
              </p>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { level: tr.critical, color: 'bg-red-500', desc: tr.criticalDesc },
                  { level: tr.high, color: 'bg-orange-500', desc: tr.highDesc },
                  { level: tr.medium, color: 'bg-yellow-500', desc: tr.mediumDesc },
                  { level: tr.low, color: 'bg-green-500', desc: tr.lowDesc },
                ].map((severity, i) => (
                  <div key={i} className={`flex items-center gap-3 p-3 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-gray-50'}`}>
                    <div className={`w-3 h-3 ${severity.color} rounded-full`} />
                    <div>
                      <p className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{severity.level}</p>
                      <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{severity.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className={`mt-6 p-4 rounded-xl ${darkMode ? 'bg-red-900/30 border border-red-700/50' : 'bg-red-50 border border-red-200'}`}>
                <div className="flex items-start gap-3">
                  <Warning size={20} className="text-red-600 flex-shrink-0" />
                  <p className={`text-sm ${darkMode ? 'text-red-400' : 'text-red-700'}`}>
                    {tr.emergencyWarning}
                  </p>
                </div>
              </div>
            </div>
            <div className={`rounded-3xl p-8 ${darkMode ? 'bg-gradient-to-br from-red-900/20 to-orange-900/20' : 'bg-gradient-to-br from-red-50 to-orange-50'}`}>
              <div className={`rounded-2xl shadow-xl p-6 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <h4 className={`font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.describeSymptoms}</h4>
                <div className={`rounded-lg p-4 mb-4 ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <p className={`text-sm italic ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    {tr.describeSymptomsExample}
                  </p>
                </div>
                <div className={`rounded-xl p-4 ${darkMode ? 'bg-red-900/30 border border-red-700/50' : 'bg-red-50 border border-red-200'}`}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                    <span className={`font-bold ${darkMode ? 'text-red-400' : 'text-red-700'}`}>{tr.highSeverity}</span>
                  </div>
                  <p className={`text-sm ${darkMode ? 'text-red-400' : 'text-red-700'}`}>
                    {tr.highSeverityMsg}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <CTASection />
      <Footer />
    </div>
  );

  // About Page
  const AboutPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-white'}`}>
      <Navigation />
      
      {/* Hero */}
      <section className={`pt-8 pb-16 transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <h1 className={`text-4xl sm:text-5xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {tr.aboutTitle}
              <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                {' '}Hakim
              </span>
            </h1>
            <p className={`text-xl max-w-3xl mx-auto ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.aboutSubtitle}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission */}
      <section className={`py-24 transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className={`text-3xl sm:text-4xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {tr.ourMission}
              </h2>
              <p className={`text-lg mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {tr.missionPara1}
              </p>
              <p className={`text-lg mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {tr.missionPara2}
              </p>
              <div className={`flex items-center gap-4 p-4 rounded-xl ${darkMode ? 'bg-emerald-900/30' : 'bg-emerald-50'}`}>
                <HandHeart size={32} className="text-emerald-600" />
                <p className={`font-medium ${darkMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
                  {tr.missionBelief}
                </p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className={`rounded-3xl p-8 ${darkMode ? 'bg-gradient-to-br from-emerald-900/30 to-teal-900/30' : 'bg-gradient-to-br from-emerald-100 to-teal-100'}`}>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: Users, value: '120M+', label: tr.populationServed },
                    { icon: Hospital, value: '292+', label: tr.hospitals },
                    { icon: Clock, value: '2-4 hrs', label: tr.avgWaitReduced },
                    { icon: MapPin, value: '13', label: tr.regions },
                  ].map((stat, i) => (
                    <div key={i} className={`rounded-2xl p-6 text-center shadow-lg ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                      <stat.icon size={28} className="text-emerald-600 mx-auto mb-3" />
                      <p className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{stat.value}</p>
                      <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{stat.label}</p>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Ethiopian Context */}
      <section className={`py-24 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className={`text-3xl sm:text-4xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {tr.builtForEthiopia}
            </h2>
            <p className={`text-xl max-w-2xl mx-auto ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.builtForEthiopiaDesc}
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: CellTower,
                title: tr.smsFirstDesign,
                description: tr.smsFirstDesignDesc,
              },
              {
                icon: Brain,
                title: tr.lowBandwidth,
                description: tr.lowBandwidthDesc,
              },
              {
                icon: MapPin,
                title: tr.regionalCoverage,
                description: tr.regionalCoverageDesc,
              },
              {
                icon: Shield,
                title: tr.offlineSupport,
                description: tr.offlineSupportDesc,
              },
              {
                icon: Clock,
                title: tr.availability247,
                description: tr.availability247Desc,
              },
              {
                icon: Heart,
                title: tr.ethiopianMade,
                description: tr.ethiopianMadeDesc,
              },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow ${darkMode ? 'bg-gray-800' : 'bg-white'}`}
              >
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                  <item.icon size={28} className="text-emerald-600" />
                </div>
                <h3 className={`text-xl font-bold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{item.title}</h3>
                <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
      <Footer />
    </div>
  );

  // Contact Page
  const ContactPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-white'}`}>
      <Navigation />
      
      <section className={`pt-8 pb-16 transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className={`text-4xl sm:text-5xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {tr.contactTitle}
            </h1>
            <p className={`text-xl max-w-2xl mx-auto ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.contactSubtitle}
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              className={`rounded-3xl shadow-xl p-8 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}
            >
              <h2 className={`text-2xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.sendMessage}</h2>
              <form className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.nameLabel}</label>
                    <input
                      type="text"
                      placeholder={tr.namePlaceholder}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.phoneLabel}</label>
                    <input
                      type="tel"
                      placeholder="09XXXXXXXXX"
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                    />
                  </div>
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.emailLabel}</label>
                  <input
                    type="email"
                    placeholder={tr.emailPlaceholder}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                  />
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.subjectLabel}</label>
                  <select className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'border-gray-200'}`}>
                    <option>{tr.generalInquiry}</option>
                    <option>{tr.technicalSupport}</option>
                    <option>{tr.hospitalPartnership}</option>
                    <option>{tr.feedback}</option>
                  </select>
                </div>
                <div>
                  <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.messageLabel}</label>
                  <textarea
                    rows={4}
                    placeholder={tr.messagePlaceholder}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold hover:shadow-lg hover:shadow-emerald-500/25 transition-all flex items-center justify-center gap-2"
                >
                  <PaperPlaneTilt size={20} />
                  {tr.sendButton}
                </button>
              </form>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <div className={`rounded-3xl shadow-xl p-8 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                <h2 className={`text-2xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.getInTouch}</h2>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                      <MapPin size={24} className="text-emerald-600" />
                    </div>
                    <div>
                      <h3 className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.location}</h3>
                      <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>{tr.locationValue}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                      <Phone size={24} className="text-emerald-600" />
                    </div>
                    <div>
                      <h3 className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.phoneLabel}</h3>
                      <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>+251 911 000 000</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                      <EnvelopeSimple size={24} className="text-emerald-600" />
                    </div>
                    <div>
                      <h3 className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.emailAddress}</h3>
                      <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>{tr.emailValue}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className={`rounded-3xl p-8 ${darkMode ? 'bg-red-900/30 border border-red-700/50' : 'bg-red-50 border border-red-200'}`}>
                <div className="flex items-center gap-3 mb-4">
                  <Ambulance size={24} className="text-red-600" />
                  <h3 className={`text-lg font-bold ${darkMode ? 'text-red-400' : 'text-red-800'}`}>{tr.medicalEmergency}</h3>
                </div>
                <p className={`mb-4 ${darkMode ? 'text-red-400' : 'text-red-700'}`}>
                  {tr.emergencyDesc}
                </p>
                
                {/* Local Ambulance */}
                <div className="mb-4 p-4 bg-white/50 rounded-xl">
                  <p className={`text-sm font-medium mb-2 ${darkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
                    {tr.localAmbulance} ({selectedRegion})
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <a
                      href={`tel:${getAmbulanceInfo().primaryNumber}`}
                      className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition"
                    >
                      <Ambulance size={18} />
                      {getAmbulanceInfo().primaryNumber}
                    </a>
                    {getAmbulanceInfo().secondaryNumber && (
                      <a
                        href={`tel:${getAmbulanceInfo().secondaryNumber}`}
                        className="inline-flex items-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-lg font-medium hover:bg-teal-700 transition"
                      >
                        <Phone size={18} />
                        {getAmbulanceInfo().secondaryNumber}
                      </a>
                    )}
                  </div>
                </div>

                <a
                  href="tel:911"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-700 transition"
                >
                  <Phone size={20} />
                  {tr.call911}
                </a>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );

  // FAQ Page
  const FAQPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-white'}`}>
      <Navigation />
      
      <section className={`pt-8 pb-16 transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className={`text-4xl sm:text-5xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {tr.faqTitle}
            </h1>
            <p className={`text-xl ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.faqSubtitle}
            </p>
          </motion.div>

          <div className="space-y-6">
            {[
              { q: tr.faqQ1, a: tr.faqA1 },
              { q: tr.faqQ2, a: tr.faqA2 },
              { q: tr.faqQ3, a: tr.faqA3 },
              { q: tr.faqQ4, a: tr.faqA4 },
              { q: tr.faqQ5, a: tr.faqA5 },
              { q: tr.faqQ6, a: tr.faqA6 },
              { q: tr.faqQ7, a: tr.faqA7 },
              { q: tr.faqQ8, a: tr.faqA8 },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}
              >
                <h3 className={`text-lg font-bold mb-3 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
                  {item.q}
                </h3>
                <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
                  {item.a}
                </p>
              </motion.div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
              {tr.contactUs}?{' '}
              <button onClick={() => setView('contact')} className="text-emerald-600 hover:underline font-medium">
                {tr.contactUs}
              </button>
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );

  // Privacy Policy Page
  const PrivacyPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-white'}`}>
      <Navigation />
      
      <section className={`pt-8 pb-16 transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className={`text-4xl sm:text-5xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {tr.privacyTitle}
            </h1>
            <p className={`text-xl ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.privacySubtitle}
            </p>
          </motion.div>

          <div className={`rounded-2xl shadow-lg p-8 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
            <p className={`text-lg mb-8 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              {tr.privacyIntro}
            </p>

            <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
              {tr.privacyCollectTitle}
            </h2>
            <ul className={`space-y-3 mb-8 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.privacyCollect1}</span></li>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.privacyCollect2}</span></li>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.privacyCollect3}</span></li>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.privacyCollect4}</span></li>
            </ul>

            <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
              {tr.privacyUseTitle}
            </h2>
            <ul className={`space-y-3 mb-8 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.privacyUse1}</span></li>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.privacyUse2}</span></li>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.privacyUse3}</span></li>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.privacyUse4}</span></li>
            </ul>

            <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
              {tr.privacySecurityTitle}
            </h2>
            <p className={`mb-8 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.privacySecurity}
            </p>

            <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
              {tr.privacyShareTitle}
            </h2>
            <p className={`mb-8 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.privacyShare}
            </p>

            <div className={`p-4 rounded-xl ${darkMode ? 'bg-emerald-900/30' : 'bg-emerald-50'}`}>
              <p className={darkMode ? 'text-emerald-400' : 'text-emerald-700'}>
                {tr.privacyContact}
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );

  // Terms of Service Page
  const TermsPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-white'}`}>
      <Navigation />
      
      <section className={`pt-8 pb-16 transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className={`text-4xl sm:text-5xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {tr.termsTitle}
            </h1>
            <p className={`text-xl ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.termsSubtitle}
            </p>
          </motion.div>

          <div className={`rounded-2xl shadow-lg p-8 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
            <p className={`text-lg mb-8 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
              {tr.termsIntro}
            </p>

            <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
              {tr.termsServiceTitle}
            </h2>
            <p className={`mb-8 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.termsService}
            </p>

            <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
              {tr.termsUserTitle}
            </h2>
            <ul className={`space-y-3 mb-8 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.termsUser1}</span></li>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.termsUser2}</span></li>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.termsUser3}</span></li>
              <li className="flex items-start gap-3"><CheckCircle size={20} className="text-emerald-500 flex-shrink-0 mt-1" /><span>{tr.termsUser4}</span></li>
            </ul>

            <div className={`p-4 rounded-xl mb-8 ${darkMode ? 'bg-red-900/30 border border-red-700/50' : 'bg-red-50 border border-red-200'}`}>
              <h3 className={`font-bold mb-2 ${darkMode ? 'text-red-400' : 'text-red-800'}`}>
                {tr.termsDisclaimerTitle}
              </h3>
              <p className={darkMode ? 'text-red-400' : 'text-red-700'}>
                {tr.termsDisclaimer}
              </p>
            </div>

            <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
              {tr.termsLimitationTitle}
            </h2>
            <p className={`mb-8 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.termsLimitation}
            </p>

            <h2 className={`text-xl font-bold mb-4 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`}>
              {tr.termsChangesTitle}
            </h2>
            <p className={`mb-8 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.termsChanges}
            </p>

            <div className={`p-4 rounded-xl ${darkMode ? 'bg-emerald-900/30' : 'bg-emerald-50'}`}>
              <p className={darkMode ? 'text-emerald-400' : 'text-emerald-700'}>
                {tr.termsContact}
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );

  // Auth Page
  const AuthPage = () => (
    <div className={`min-h-screen flex items-center justify-center p-4 transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <button onClick={() => setView('landing')} className="inline-flex items-center gap-2 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
              <Heart weight="fill" className="text-white" size={28} />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              Hakim
            </span>
          </button>
          <h2 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
            {otpSent ? tr.verifyOTP : tr.signIn}
          </h2>
          <p className={`mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            {otpSent 
              ? `${tr.weSentCode} ${phone}` 
              : tr.signInPhone
            }
          </p>
        </div>

        {/* Form */}
        <div className={`rounded-3xl shadow-xl p-8 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
          {!otpSent ? (
            <div className="space-y-6">
              <div>
                <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.phoneNumberLabel}</label>
                <div className="relative">
                  <Phone size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                  <input
                    type="tel"
                    placeholder="09XXXXXXXXX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className={`w-full pl-12 pr-4 py-4 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition text-lg ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                  />
                </div>
              </div>
              <div>
                <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.nameOptionalLabel}</label>
                <div className="relative">
                  <User size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                  <input
                    type="text"
                    placeholder={tr.yourNamePlaceholder}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={`w-full pl-12 pr-4 py-4 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition text-lg ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                  />
                </div>
              </div>
              <button
                onClick={() => sendOtp(name ? 'REGISTRATION' : 'LOGIN')}
                disabled={loading || !phone}
                className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-emerald-500/25 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <ArrowClockwise className="animate-spin" size={20} />
                ) : (
                  <>
                    {tr.continue}
                    <ArrowRight size={20} />
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.enterOTPLabel}</label>
                <input
                  type="text"
                  placeholder="000000"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className={`w-full text-center text-3xl tracking-widest py-4 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition font-mono ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                  maxLength={6}
                />
              </div>
              <button
                onClick={verifyOtp}
                disabled={loading || otp.length !== 6}
                className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-emerald-500/25 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <ArrowClockwise className="animate-spin" size={20} />
                ) : (
                  <>
                    {tr.verifySignInBtn}
                    <Check size={20} />
                  </>
                )}
              </button>
              <button
                onClick={() => setOtpSent(false)}
                className={`w-full py-3 transition flex items-center justify-center gap-2 ${darkMode ? 'text-gray-400 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
              >
                <ArrowCounterClockwise size={16} />
                {tr.changePhone}
              </button>
            </div>
          )}

          <div className={`mt-6 pt-6 border-t text-center ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
              {tr.byContinuing}{' '}
              <a href="#" className="text-emerald-600 hover:underline">{tr.termsOfService}</a>
              {' '}and{' '}
              <a href="#" className="text-emerald-600 hover:underline">{tr.privacyPolicy}</a>
            </p>
          </div>
        </div>

        {/* Register as Hospital Link */}
        <div className={`mt-4 p-4 rounded-2xl border ${darkMode ? 'bg-gray-900/50 border-gray-800' : 'bg-emerald-50/50 border-emerald-100'}`}>
          <p className={`text-sm text-center ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            Want to register your hospital?{' '}
            <button onClick={() => setView('hospital-register')} className="text-emerald-600 hover:underline font-medium">
              {tr.registerAsHospital}
            </button>
          </p>
        </div>

        {/* Back to home */}
        <button
          onClick={() => setView('landing')}
          className={`w-full mt-4 py-3 transition flex items-center justify-center gap-2 ${darkMode ? 'text-gray-400 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
        >
          <ArrowLeft size={16} />
          {tr.backToHome}
        </button>
      </motion.div>
    </div>
  );

  // Hospitals Page
  const HospitalsPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      <Navigation />
      
      <section className={`pt-8 pb-8 transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <button
              onClick={() => setView('landing')}
              className={`flex items-center gap-2 transition mb-6 ${darkMode ? 'text-gray-400 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
            >
              <ArrowLeft size={20} />
              Back to Home
            </button>
            <h1 className={`text-3xl sm:text-4xl font-bold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              Select Hospital
            </h1>
            <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
              Choose a hospital to book your queue token
            </p>
          </motion.div>

          {/* Search & Filter */}
          <div className="mt-8 flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <MagnifyingGlass size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
              <input
                type="text"
                placeholder="Search hospitals..."
                className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'bg-white border-gray-200'}`}
              />
            </div>
            <select className={`px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200'}`}>
              <option>All Regions</option>
              <option>Addis Ababa</option>
              <option>Amhara</option>
              <option>Oromia</option>
              <option>Sidama</option>
              <option>Tigray</option>
            </select>
            <div className={`flex border rounded-xl overflow-hidden ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-3 ${viewMode === 'grid' ? (darkMode ? 'bg-emerald-900/50 text-emerald-400' : 'bg-emerald-50 text-emerald-600') : (darkMode ? 'bg-gray-800 text-gray-400' : 'bg-white text-gray-400')}`}
              >
                <GridFour size={20} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-3 ${viewMode === 'list' ? (darkMode ? 'bg-emerald-900/50 text-emerald-400' : 'bg-emerald-50 text-emerald-600') : (darkMode ? 'bg-gray-800 text-gray-400' : 'bg-white text-gray-400')}`}
              >
                <List size={20} />
              </button>
            </div>
            <button
              onClick={() => setView('map')}
              className="flex items-center gap-2 px-4 py-3 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition"
            >
              <MapPin size={20} />
              <span className="hidden sm:inline">Map View</span>
            </button>
          </div>
        </div>
      </section>

      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <Spinner />
          ) : (
            <div className={viewMode === 'grid' ? 'grid md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
              {hospitals.map((hospital, index) => (
                <motion.button
                  key={hospital.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => {
                    setSelectedHospital(hospital);
                    loadDepartments(hospital.id);
                    setView('departments');
                  }}
                  className={`rounded-2xl shadow-lg hover:shadow-xl transition-all text-left group overflow-hidden ${
                    darkMode ? 'bg-gray-900' : 'bg-white'
                  } ${viewMode === 'grid' ? 'p-6' : 'p-4 flex items-center gap-4'}`}
                >
                  {viewMode === 'grid' ? (
                    <>
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform ${darkMode ? 'bg-gradient-to-br from-emerald-900/50 to-teal-900/50' : 'bg-gradient-to-br from-emerald-100 to-teal-100'}`}>
                        <Hospital size={28} className="text-emerald-600" />
                      </div>
                      <h3 className={`text-lg font-bold mb-2 group-hover:text-emerald-600 transition ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                        {hospital.name}
                      </h3>
                      <div className={`flex items-center gap-2 text-sm mb-2 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                        <MapPin size={16} />
                        <span>{hospital.region}</span>
                      </div>
                      <p className={`text-sm line-clamp-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{hospital.address}</p>
                      <div className={`flex items-center justify-between mt-4 pt-4 border-t ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
                        <div className={`flex items-center gap-2 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          <Stethoscope size={16} />
                          <span>13 departments</span>
                        </div>
                        <CaretRight size={20} className={`group-hover:text-emerald-600 group-hover:translate-x-1 transition-all ${darkMode ? 'text-gray-600' : 'text-gray-300'}`} />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${darkMode ? 'bg-gradient-to-br from-emerald-900/50 to-teal-900/50' : 'bg-gradient-to-br from-emerald-100 to-teal-100'}`}>
                        <Hospital size={24} className="text-emerald-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className={`font-bold group-hover:text-emerald-600 transition truncate ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                          {hospital.name}
                        </h3>
                        <div className={`flex items-center gap-2 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                          <MapPin size={14} />
                          <span>{hospital.region}</span>
                          <span className={darkMode ? 'text-gray-600' : 'text-gray-300'}>•</span>
                          <span>13 departments</span>
                        </div>
                      </div>
                      <CaretRight size={20} className={`group-hover:text-emerald-600 transition ${darkMode ? 'text-gray-600' : 'text-gray-300'}`} />
                    </>
                  )}
                </motion.button>
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );

  // Map Page - Interactive Hospital Map
  const MapPage = () => {
    const [mapSearchTerm, setMapSearchTerm] = useState('');
    const [mapSelectedRegion, setMapSelectedRegion] = useState<string>('');
    const [regions, setRegions] = useState<{name: string; count: number}[]>([]);
    const [userLocation, setUserLocation] = useState<{lat: number; lng: number} | null>(null);
    const [mapMounted, setMapMounted] = useState(false);
    const [MapComponent, setMapComponent] = useState<React.ComponentType<{
      hospitals: Hospital[];
      selectedHospital: Hospital | null;
      onHospitalSelect: (hospital: Hospital) => void;
      userLocation?: {lat: number; lng: number} | null;
    }> | null>(null);

    // Load regions
    useEffect(() => {
      const loadRegions = async () => {
        try {
          const res = await api.get('/api/hospitals/regions');
          if (res.success) {
            setRegions(res.data);
          }
        } catch (error) {
          console.error('Failed to load regions:', error);
        }
      };
      loadRegions();
    }, []);

    // Get user location
    useEffect(() => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setUserLocation({
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            });
          },
          (error) => {
            console.log('Geolocation error:', error);
          }
        );
      }
    }, []);

    // Dynamically load map component
    useEffect(() => {
      setMapMounted(true);
      import('@/components/map/HospitalMap').then((mod) => {
        setMapComponent(() => mod.default);
      });
    }, []);

    // Filter hospitals
    const filteredHospitals = hospitals.filter(h => {
      const matchesSearch = h.name.toLowerCase().includes(mapSearchTerm.toLowerCase()) ||
                            h.address?.toLowerCase().includes(mapSearchTerm.toLowerCase());
      const matchesRegion = !mapSelectedRegion || h.region === mapSelectedRegion;
      return matchesSearch && matchesRegion;
    });

    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        
        <section className="pt-8 pb-4 bg-gradient-to-br from-emerald-50 via-white to-teal-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <button
                onClick={() => setView('hospitals')}
                className="flex items-center gap-2 text-gray-600 hover:text-emerald-600 transition mb-6"
              >
                <ArrowLeft size={20} />
                Back to Hospitals
              </button>
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">
                    Find Hospitals Near You
                  </h1>
                  <p className="text-gray-600">
                    Interactive map of {hospitals.length} hospitals across Ethiopia
                  </p>
                </div>
                {userLocation && (
                  <div className="flex items-center gap-2 text-sm text-emerald-600 bg-emerald-50 px-4 py-2 rounded-lg">
                    <MapPin size={16} />
                    <span>Location detected</span>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Search Controls */}
        <section className="py-4 bg-white border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <MagnifyingGlass size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search hospitals by name or address..."
                  value={mapSearchTerm}
                  onChange={(e) => setMapSearchTerm(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
                />
              </div>
              <select
                value={mapSelectedRegion}
                onChange={(e) => setMapSelectedRegion(e.target.value)}
                className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition min-w-[200px]"
              >
                <option value="">All Regions ({hospitals.length})</option>
                {regions.map(r => (
                  <option key={r.name} value={r.name}>{r.name} ({r.count})</option>
                ))}
              </select>
            </div>
          </div>
        </section>

        {/* Map Container */}
        <section className="h-[calc(100vh-300px)] min-h-[500px] relative">
          {!mapMounted || !MapComponent ? (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-emerald-50 to-teal-50">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Loading interactive map...</p>
              </div>
            </div>
          ) : (
            <MapComponent
              hospitals={filteredHospitals}
              selectedHospital={selectedHospital}
              onHospitalSelect={(hospital) => {
                setSelectedHospital(hospital);
                loadDepartments(hospital.id);
                setView('departments');
              }}
              userLocation={userLocation}
            />
          )}
        </section>

        {/* Hospital Quick List */}
        <section className="py-6 bg-white border-t">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h3 className="font-semibold text-gray-900 mb-4">
              {filteredHospitals.length} Hospital{filteredHospitals.length !== 1 ? 's' : ''} Found
            </h3>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredHospitals.slice(0, 8).map(hospital => (
                <button
                  key={hospital.id}
                  onClick={() => {
                    setSelectedHospital(hospital);
                    loadDepartments(hospital.id);
                    setView('departments');
                  }}
                  className="p-3 bg-gray-50 rounded-lg text-left hover:bg-emerald-50 hover:ring-2 hover:ring-emerald-500 transition group"
                >
                  <p className="font-medium text-gray-900 group-hover:text-emerald-600 truncate">
                    {hospital.name}
                  </p>
                  <p className="text-sm text-gray-500">{hospital.region}</p>
                </button>
              ))}
            </div>
            {filteredHospitals.length > 8 && (
              <p className="text-center text-gray-500 text-sm mt-4">
                +{filteredHospitals.length - 8} more hospitals on the map
              </p>
            )}
          </div>
        </section>

        <Footer />
      </div>
    );
  };

  // Departments Page
  const DepartmentsPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      <Navigation />
      
      <section className={`pt-8 pb-8 transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <button
              onClick={() => setView('hospitals')}
              className={`flex items-center gap-2 transition mb-6 ${darkMode ? 'text-gray-400 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
            >
              <ArrowLeft size={20} />
              Back to Hospitals
            </button>
            
            <div className="flex items-start gap-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/25">
                <Hospital size={32} className="text-white" />
              </div>
              <div>
                <h1 className={`text-2xl sm:text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {selectedHospital?.name}
                </h1>
                <div className={`flex items-center gap-2 mt-1 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  <MapPin size={16} />
                  <span>{selectedHospital?.address}</span>
                </div>
              </div>
            </div>

            <h2 className={`text-xl font-semibold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Select Department</h2>
            <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>Choose a department to book your queue token</p>
          </motion.div>
        </div>
      </section>

      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <Spinner />
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {departments.map((dept: Record<string, unknown>, index) => (
                <motion.button
                  key={dept.id as string}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => {
                    setSelectedDepartment(dept as unknown as Department);
                    setView('booking');
                  }}
                  className={`rounded-2xl shadow-lg hover:shadow-xl p-6 text-left group transition-all ${darkMode ? 'bg-gray-900' : 'bg-white'}`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                      <Stethoscope size={24} className="text-emerald-600" />
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${darkMode ? 'bg-blue-900/50 text-blue-400' : 'bg-blue-50 text-blue-600'}`}>
                      {(dept.waitingCount as number) || 0} waiting
                    </span>
                  </div>
                  
                  <h3 className={`text-lg font-bold mb-1 group-hover:text-emerald-600 transition ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    {dept.name as string}
                  </h3>
                  <p className={`text-sm mb-4 line-clamp-2 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    {dept.description as string || 'Medical consultations and treatment'}
                  </p>
                  
                  <div className={`flex items-center justify-between pt-4 border-t ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
                    <div className={`flex items-center gap-4 text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      <div className="flex items-center gap-1">
                        <Timer size={14} />
                        <span>~{dept.averageServiceTimeMin as number}min</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users size={14} />
                        <span>{dept.dailyCapacity as number}/day</span>
                      </div>
                    </div>
                    <CaretRight size={20} className={`group-hover:text-emerald-600 transition ${darkMode ? 'text-gray-600' : 'text-gray-300'}`} />
                  </div>
                </motion.button>
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );

  // Booking Page
  const BookingPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      <Navigation />
      
      <section className="pt-8 pb-8">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <button
              onClick={() => setView('departments')}
              className={`flex items-center gap-2 transition mb-6 ${darkMode ? 'text-gray-400 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
            >
              <ArrowLeft size={20} />
              Back to Departments
            </button>

            {/* Hospital & Department Info */}
            <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl p-6 text-white mb-6 shadow-xl shadow-emerald-500/25">
              <div className="flex items-center gap-3 mb-4">
                <Hospital size={24} />
                <span className="font-medium">{selectedHospital?.name}</span>
              </div>
              <div className="flex items-center gap-3">
                <Stethoscope size={24} />
                <span className="text-xl font-bold">{selectedDepartment?.name}</span>
              </div>
            </div>

            {/* Queue Info */}
            <div className={`rounded-2xl shadow-lg p-6 mb-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
              <h3 className={`font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Current Queue Status</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className={`rounded-xl p-4 text-center ${darkMode ? 'bg-gray-800' : 'bg-gray-50'}`}>
                  <Users size={24} className="text-blue-500 mx-auto mb-2" />
                  <p className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    {departments.find(d => d.id === selectedDepartment?.id)?.currentQueueCount || 0}
                  </p>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>In Queue</p>
                </div>
                <div className={`rounded-xl p-4 text-center ${darkMode ? 'bg-gray-800' : 'bg-gray-50'}`}>
                  <Timer size={24} className="text-amber-500 mx-auto mb-2" />
                  <p className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    {formatWaitTime((departments.find(d => d.id === selectedDepartment?.id)?.currentQueueCount || 0) * 15)}
                  </p>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Est. Wait</p>
                </div>
              </div>
            </div>

            {/* Booking Form */}
            <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
              <h3 className={`font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Complete Your Booking</h3>
              
              {!isAuthenticated && (
                <div className="space-y-4 mb-6">
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Phone Number *</label>
                    <div className="relative">
                      <Phone size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                      <input
                        type="tel"
                        placeholder="09XXXXXXXXX"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                      />
                    </div>
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Your Name</label>
                    <div className="relative">
                      <User size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                      <input
                        type="text"
                        placeholder="Your name (optional)"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="mb-6">
                <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Notes (optional)</label>
                <textarea
                  placeholder="Any notes for the medical staff..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                />
              </div>

              <button
                onClick={bookAppointment}
                disabled={loading || (!isAuthenticated && !phone)}
                className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-emerald-500/25 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <ArrowClockwise className="animate-spin" size={20} />
                ) : (
                  <>
                    <Ticket size={20} weight="fill" />
                    Get My Token
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );

  // Token Page
  const TokenPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      <Navigation />
      
      <section className="pt-8 pb-8">
        <div className="max-w-md mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6"
          >
            {/* Token Card */}
            <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl p-8 text-white text-center shadow-2xl shadow-emerald-500/30">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-2xl mb-4">
                <Ticket size={32} weight="fill" />
              </div>
              <p className="text-emerald-100 text-sm mb-1">Your Token Number</p>
              <p className="text-6xl font-bold mb-4">
                #{currentAppointment?.tokenNumber || queueStatus?.lastTokenIssued}
              </p>
              <p className="text-emerald-100">{selectedDepartment?.name || queueStatus?.departmentName}</p>
            </div>

            {/* Status Card */}
            <div className={`rounded-2xl shadow-lg overflow-hidden transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
              <div className={`p-4 border-b flex items-center justify-between ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
                <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Status</span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(currentAppointment?.status || 'WAITING')}`}>
                  {getStatusLabel(currentAppointment?.status || 'WAITING')}
                </span>
              </div>
              <div className={`p-4 border-b flex items-center justify-between ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
                <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Queue Position</span>
                <span className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{queueStatus?.queuePosition || 0}</span>
              </div>
              <div className={`p-4 border-b flex items-center justify-between ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
                <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Estimated Wait</span>
                <span className="text-xl font-bold text-emerald-600">
                  {formatWaitTime(queueStatus?.estimatedWaitMinutes || 0)}
                </span>
              </div>
              <div className="p-4 flex items-center justify-between">
                <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Currently Serving</span>
                <span className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>#{queueStatus?.currentToken || 0}</span>
              </div>
            </div>

            {/* Hospital Info */}
            <div className={`rounded-2xl shadow-lg p-4 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                  <Hospital size={20} className="text-emerald-600" />
                </div>
                <div>
                  <h4 className={`font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{selectedHospital?.name}</h4>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{selectedHospital?.address}</p>
                  {selectedHospital?.emergencyContactNumber && (
                    <a
                      href={`tel:${selectedHospital.emergencyContactNumber}`}
                      className="inline-flex items-center gap-1 mt-2 text-sm text-emerald-600"
                    >
                      <Phone size={14} />
                      {selectedHospital.emergencyContactNumber}
                    </a>
                  )}
                </div>
              </div>
            </div>

            {/* Notification Info */}
            <div className={`rounded-2xl p-4 ${darkMode ? 'bg-blue-900/30 border border-blue-700/50' : 'bg-blue-50 border border-blue-200'}`}>
              <div className="flex items-start gap-3">
                <Bell size={20} className={`flex-shrink-0 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`} />
                <div>
                  <p className={`font-medium ${darkMode ? 'text-blue-300' : 'text-blue-800'}`}>SMS Notifications Active</p>
                  <p className={`text-sm mt-1 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>
                    You'll receive an SMS when you're next in line and when it's your turn.
                  </p>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setCurrentAppointment(null);
                setQueueStatus(null);
                setView('landing');
              }}
              className={`w-full py-3 border rounded-xl transition flex items-center justify-center gap-2 ${darkMode ? 'border-gray-700 text-gray-300 hover:bg-gray-800' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
            >
              <ArrowLeft size={16} />
              Back to Home
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );

  // Emergency Page
  const EmergencyPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      <Navigation />
      
      <section className="pt-8 pb-8">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <button
              onClick={() => setView('landing')}
              className={`flex items-center gap-2 transition mb-6 ${darkMode ? 'text-gray-400 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
            >
              <ArrowLeft size={20} />
              Back to Home
            </button>

            <div className="flex items-center gap-3 mb-6">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${darkMode ? 'bg-red-900/50' : 'bg-red-100'}`}>
                <Ambulance size={24} className="text-red-600" />
              </div>
              <div>
                <h1 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Emergency Assist</h1>
                <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>Get triage guidance for your symptoms</p>
              </div>
            </div>

            {/* Disclaimer */}
            <div className={`rounded-2xl p-4 mb-6 ${darkMode ? 'bg-red-900/30 border border-red-700/50' : 'bg-red-50 border border-red-200'}`}>
              <div className="flex items-start gap-3">
                <Warning size={24} className="text-red-600 flex-shrink-0" />
                <div>
                  <p className={`font-bold ${darkMode ? 'text-red-300' : 'text-red-800'}`}>IMPORTANT DISCLAIMER</p>
                  <p className={`text-sm mt-1 ${darkMode ? 'text-red-400' : 'text-red-700'}`}>
                    This system does NOT replace emergency services. If this is a life-threatening 
                    emergency, call <strong>911</strong> immediately or proceed to the nearest emergency room.
                  </p>
                </div>
              </div>
            </div>

            {!triageResult ? (
              <>
                {/* Symptom Input */}
                <div className={`rounded-2xl shadow-lg p-6 mb-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                  <label className={`block font-semibold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Describe Your Symptoms</label>
                  <textarea
                    placeholder="Please describe your symptoms in detail. For example: 'I have severe chest pain and difficulty breathing for the past 30 minutes'"
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    rows={5}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                  />
                  <p className={`text-sm mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    Be as specific as possible for better triage assessment.
                  </p>
                </div>

                {/* Contact Info for Guests */}
                {!isAuthenticated && (
                  <div className={`rounded-2xl shadow-lg p-6 mb-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                    <h3 className={`font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Your Contact Information</h3>
                    <div className="space-y-4">
                      <div>
                        <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Phone Number *</label>
                        <input
                          type="tel"
                          placeholder="09XXXXXXXXX"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                        />
                      </div>
                      <div>
                        <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>Your Name</label>
                        <input
                          type="text"
                          placeholder="Your name"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Hospital Selection */}
                <div className={`rounded-2xl shadow-lg p-6 mb-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                  <label className={`block font-semibold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Nearest Hospital (Optional)</label>
                  <select
                    value={selectedHospital?.id || ''}
                    onChange={(e) => {
                      const hospital = hospitals.find(h => h.id === e.target.value);
                      setSelectedHospital(hospital || null);
                    }}
                    className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'border-gray-200'}`}
                  >
                    <option value="">Select hospital (optional)</option>
                    {hospitals.map(h => (
                      <option key={h.id} value={h.id}>{h.name}</option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={reportEmergency}
                  disabled={loading || symptoms.length < 10}
                  className="w-full py-4 bg-red-600 text-white rounded-xl font-semibold text-lg hover:bg-red-700 transition disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <ArrowClockwise className="animate-spin" size={20} />
                  ) : (
                    <>
                      <FirstAid size={20} />
                      Get Triage Assessment
                    </>
                  )}
                </button>
              </>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                {/* Severity Result */}
                <div className={`rounded-2xl p-6 ${getSeverityColor(triageResult.severityLevel)}`}>
                  <div className="text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-2xl mb-4">
                      {triageResult.isEmergency ? (
                        <Warning size={32} weight="fill" />
                      ) : (
                        <FirstAid size={32} weight="fill" />
                      )}
                    </div>
                    <p className="text-sm opacity-80">Severity Level</p>
                    <p className="text-3xl font-bold">{getSeverityLabel(triageResult.severityLevel)}</p>
                    <p className="text-sm opacity-80 mt-1">
                      Confidence: {Math.round(triageResult.confidence * 100)}%
                    </p>
                  </div>
                </div>

                {/* Recommendation */}
                <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                  <h3 className={`font-semibold mb-3 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Recommendation</h3>
                  <p className={`leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{triageResult.recommendation}</p>
                  {triageResult.keywords.length > 0 && (
                    <div className={`mt-4 pt-4 border-t ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>
                      <p className={`text-sm mb-2 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Identified keywords:</p>
                      <div className="flex flex-wrap gap-2">
                        {triageResult.keywords.map((keyword, i) => (
                          <span key={i} className={`px-2 py-1 rounded-full text-sm ${darkMode ? 'bg-gray-800 text-gray-300' : 'bg-gray-100 text-gray-600'}`}>
                            {keyword}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Emergency Actions */}
                {triageResult.isEmergency && (
                  <a
                    href="tel:911"
                    className="block w-full py-4 bg-red-600 text-white rounded-xl font-semibold text-lg text-center hover:bg-red-700 transition"
                  >
                    <Phone size={20} className="inline mr-2" />
                    Call Emergency Services (911)
                  </a>
                )}

                <button
                  onClick={() => {
                    setTriageResult(null);
                    setSymptoms('');
                  }}
                  className={`w-full py-3 border rounded-xl transition flex items-center justify-center gap-2 ${darkMode ? 'border-gray-700 text-gray-300 hover:bg-gray-800' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                >
                  <ArrowCounterClockwise size={16} />
                  Report Another Symptom
                </button>
              </motion.div>
            )}
          </motion.div>
        </div>
      </section>
    </div>
  );

  // Admin Dashboard
  const AdminDashboardPage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      <Navigation />
      
      <section className="pt-8 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>Admin Dashboard</h1>
                <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>Manage hospital queues and view analytics</p>
              </div>
              <button
                onClick={loadAdminQueue}
                disabled={loading}
                className={`px-4 py-2 border rounded-xl transition flex items-center gap-2 ${darkMode ? 'border-gray-700 text-gray-300 hover:bg-gray-800' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
              >
                <ArrowClockwise size={16} className={loading ? 'animate-spin' : ''} />
                Refresh
              </button>
            </div>

            {/* Hospital Selector */}
            <div className={`rounded-2xl shadow-lg p-4 mb-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
              <select
                value={selectedHospital?.id || ''}
                onChange={(e) => {
                  const hospital = hospitals.find(h => h.id === e.target.value);
                  setSelectedHospital(hospital || null);
                  if (hospital) loadAdminQueue();
                }}
                className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'border-gray-200'}`}
              >
                <option value="">Select a hospital</option>
                {hospitals.map(h => (
                  <option key={h.id} value={h.id}>{h.name}</option>
                ))}
              </select>
            </div>

            {adminStats && (
              <>
                {/* Stats Grid */}
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                    <div className="flex items-center justify-between mb-3">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Total Today</span>
                      <Users size={20} className={darkMode ? 'text-gray-500' : 'text-gray-400'} />
                    </div>
                    <p className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                      {(adminStats as Record<string, unknown>).summary?.totalPatientsToday as number || 0}
                    </p>
                  </div>
                  <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                    <div className="flex items-center justify-between mb-3">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Waiting</span>
                      <Timer size={20} className="text-blue-500" />
                    </div>
                    <p className="text-3xl font-bold text-blue-600">
                      {(adminStats as Record<string, unknown>).summary?.totalWaiting as number || 0}
                    </p>
                  </div>
                  <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                    <div className="flex items-center justify-between mb-3">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Served</span>
                      <CheckCircle size={20} className="text-emerald-500" />
                    </div>
                    <p className="text-3xl font-bold text-emerald-600">
                      {(adminStats as Record<string, unknown>).summary?.totalServed as number || 0}
                    </p>
                  </div>
                  <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                    <div className="flex items-center justify-between mb-3">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Avg Wait</span>
                      <Clock size={20} className="text-amber-500" />
                    </div>
                    <p className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                      {(adminStats as Record<string, unknown>).summary?.averageWaitTime as number || 0} min
                    </p>
                  </div>
                </div>

                {/* Department Stats */}
                <div className={`rounded-2xl shadow-lg p-6 mb-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                  <h3 className={`font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Department Queue Status</h3>
                  <div className="space-y-3">
                    {((adminStats as Record<string, unknown>).departmentStats as unknown[])?.map((dept: unknown) => (
                      <div
                        key={(dept as Record<string, unknown>).departmentId as string}
                        className={`flex items-center justify-between p-4 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-gray-50'}`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                            <Stethoscope size={20} className="text-emerald-600" />
                          </div>
                          <div>
                            <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                              {(dept as Record<string, unknown>).departmentName as string}
                            </p>
                            <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                              Token #{(dept as Record<string, unknown>).currentToken as number} serving
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-6 text-sm">
                          <div className="text-center">
                            <p className="font-bold text-blue-600">{(dept as Record<string, unknown>).totalWaiting as number}</p>
                            <p className={darkMode ? 'text-gray-400' : 'text-gray-500'}>waiting</p>
                          </div>
                          <div className="text-center">
                            <p className="font-bold text-emerald-600">{(dept as Record<string, unknown>).totalServed as number}</p>
                            <p className={darkMode ? 'text-gray-400' : 'text-gray-500'}>served</p>
                          </div>
                          <button
                            onClick={() => {
                              setSelectedDepartment(departments.find(d => d.id === (dept as Record<string, unknown>).departmentId) || null);
                              setView('admin-queue');
                            }}
                            className={`px-4 py-2 rounded-lg transition font-medium ${darkMode ? 'bg-emerald-900/50 text-emerald-400 hover:bg-emerald-900/70' : 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100'}`}
                          >
                            Manage
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </motion.div>
        </div>
      </section>
    </div>
  );

  // Admin Queue Management
  const AdminQueuePage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      <Navigation />
      
      <section className="pt-8 pb-8">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <button
              onClick={() => setView('admin-dashboard')}
              className={`flex items-center gap-2 transition mb-6 ${darkMode ? 'text-gray-400 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
            >
              <ArrowLeft size={20} />
              Back to Dashboard
            </button>

            <h1 className={`text-2xl font-bold mb-6 ${darkMode ? 'text-white' : 'text-gray-900'}`}>Queue Management</h1>

            {/* Department Selector */}
            <div className={`rounded-2xl shadow-lg p-4 mb-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
              <select
                value={selectedDepartment?.id || ''}
                onChange={(e) => {
                  const dept = departments.find(d => d.id === e.target.value);
                  setSelectedDepartment(dept as unknown as Department || null);
                }}
                className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'border-gray-200'}`}
              >
                <option value="">Select department</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>

            {selectedDepartment && (
              <div className={`rounded-2xl shadow-lg p-6 mb-6 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                <div className="text-center mb-6">
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Currently Serving</p>
                  <p className={`text-5xl font-bold my-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    #{departments.find(d => d.id === selectedDepartment.id)?.currentQueueCount || 0}
                  </p>
                </div>
                <button
                  onClick={callNextPatient}
                  disabled={loading}
                  className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-emerald-500/25 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <ArrowClockwise className="animate-spin" size={20} />
                  ) : (
                    <>
                      <ArrowRight size={20} />
                      Call Next Patient
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-4">
              <button className={`p-4 rounded-2xl shadow-lg hover:shadow-xl transition text-center ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                <ArrowClockwise size={24} className="text-orange-500 mx-auto mb-2" />
                <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>Skip Patient</p>
              </button>
              <button className={`p-4 rounded-2xl shadow-lg hover:shadow-xl transition text-center ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                <FirstAid size={24} className="text-red-500 mx-auto mb-2" />
                <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>Emergency Insert</p>
              </button>
              <button className={`p-4 rounded-2xl shadow-lg hover:shadow-xl transition text-center ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                <Check size={24} className="text-emerald-500 mx-auto mb-2" />
                <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>Mark Complete</p>
              </button>
              <button className={`p-4 rounded-2xl shadow-lg hover:shadow-xl transition text-center ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
                <Clock size={24} className="text-blue-500 mx-auto mb-2" />
                <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>View History</p>
              </button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );

  // Profile Page
  const ProfilePage = () => (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
      <Navigation />
      
      <section className="pt-8 pb-8">
        <div className="max-w-md mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Profile Card */}
            <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-3xl p-8 text-white text-center shadow-xl shadow-emerald-500/25">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <User size={40} />
              </div>
              <h2 className="text-2xl font-bold">{user?.name || 'User'}</h2>
              <p className="text-emerald-100">{formatPhoneDisplay(user?.phone || '')}</p>
              <span className="inline-block mt-4 px-4 py-1 bg-white/20 rounded-full text-sm">
                {user?.role === 'HOSPITAL_ADMIN' ? 'Hospital Admin' : 'Patient'}
              </span>
            </div>

            {/* Quick Actions */}
            <div className={`rounded-2xl shadow-lg overflow-hidden transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
              <button
                onClick={async () => {
                  const res = await api.get('/api/queue/my-tokens?status=WAITING', token || undefined);
                  if (res.success && res.data.length > 0) {
                    setCurrentAppointment(res.data[0]);
                    setView('token');
                  } else {
                    alert('No active appointments found');
                  }
                }}
                className={`w-full p-4 flex items-center gap-4 transition border-b ${darkMode ? 'hover:bg-gray-800 border-gray-800' : 'hover:bg-gray-50 border-gray-100'}`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                  <Ticket size={20} className="text-emerald-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>My Active Token</p>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>View your current queue position</p>
                </div>
                <CaretRight size={20} className={darkMode ? 'text-gray-600' : 'text-gray-400'} />
              </button>

              <button className={`w-full p-4 flex items-center gap-4 transition border-b ${darkMode ? 'hover:bg-gray-800 border-gray-800' : 'hover:bg-gray-50 border-gray-100'}`}>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${darkMode ? 'bg-blue-900/50' : 'bg-blue-100'}`}>
                  <Clock size={20} className="text-blue-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>Appointment History</p>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>View past appointments</p>
                </div>
                <CaretRight size={20} className={darkMode ? 'text-gray-600' : 'text-gray-400'} />
              </button>

              <button className={`w-full p-4 flex items-center gap-4 transition ${darkMode ? 'hover:bg-gray-800' : 'hover:bg-gray-50'}`}>
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${darkMode ? 'bg-purple-900/50' : 'bg-purple-100'}`}>
                  <Bell size={20} className="text-purple-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>Notifications</p>
                  <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Manage notification settings</p>
                </div>
                <CaretRight size={20} className={darkMode ? 'text-gray-600' : 'text-gray-400'} />
              </button>
            </div>

            {/* Sign Out */}
            <button
              onClick={() => { logout(); setView('landing'); }}
              className={`w-full py-4 border rounded-xl font-medium transition flex items-center justify-center gap-2 ${darkMode ? 'border-red-800 text-red-400 hover:bg-red-900/30' : 'border-red-200 text-red-600 hover:bg-red-50'}`}
            >
              <SignOut size={20} />
              Sign Out
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );

  // Hospital Registration Page - using stable render to prevent input focus issues
  const renderHospitalRegistrationPage = useCallback(() => {
    const services = [
      { id: 'emergency', label: tr.emergencyServices },
      { id: 'outpatient', label: tr.outpatientServices },
      { id: 'inpatient', label: tr.inpatientServices },
      { id: 'laboratory', label: tr.laboratoryServices },
      { id: 'radiology', label: tr.radiologyServices },
      { id: 'pharmacy', label: tr.pharmacyServices },
      { id: 'maternal', label: tr.maternalHealth },
      { id: 'pediatric', label: tr.pediatricCare },
      { id: 'surgical', label: tr.surgicalServices },
    ];

    const handleServiceToggle = (serviceId: string) => {
      setRegistrationData(prev => ({
        ...prev,
        services: prev.services.includes(serviceId)
          ? prev.services.filter(s => s !== serviceId)
          : [...prev.services, serviceId]
      }));
    };

    const handleRegister = async () => {
      if (registrationData.adminPassword !== registrationData.confirmPassword) {
        alert('Passwords do not match');
        return;
      }
      if (registrationData.adminPassword.length < 8) {
        alert('Password must be at least 8 characters');
        return;
      }
      if (!registrationData.agreeToTerms) {
        alert('Please agree to the terms and conditions');
        return;
      }
      
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        alert(tr.registrationSuccess);
        setView('auth');
        setRegistrationStep(1);
      }, 1500);
    };

    return (
      <div className={`min-h-screen flex items-center justify-center p-4 transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <div className="w-full max-w-2xl">
          {/* Header */}
          <div className="text-center mb-8">
            <button onClick={() => setView('landing')} className="inline-flex items-center gap-2 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
                <Heart weight="fill" className="text-white" size={28} />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                Hakim
              </span>
            </button>
            <h2 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              {tr.registerHospital}
            </h2>
            <p className={`mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {tr.registerHospitalDesc}
            </p>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-center gap-2 mb-8">
            {[1, 2, 3].map((step) => (
              <div key={step} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                  registrationStep >= step 
                    ? 'bg-emerald-500 text-white' 
                    : darkMode ? 'bg-gray-800 text-gray-400' : 'bg-gray-200 text-gray-500'
                }`}>
                  {step}
                </div>
                {step < 3 && (
                  <div className={`w-12 h-1 mx-1 rounded transition-all ${
                    registrationStep > step ? 'bg-emerald-500' : darkMode ? 'bg-gray-800' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>

          {/* Form Card */}
          <div className={`rounded-3xl shadow-xl p-8 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
            {/* Step 1: Hospital Information */}
            {registrationStep === 1 && (
              <div className="space-y-6">
                <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {tr.hospitalInfo}
                </h3>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.hospitalName} *
                    </label>
                    <div className="relative">
                      <Hospital size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                      <input
                        type="text"
                        placeholder="e.g., Tikur Anbessa General Hospital"
                        value={registrationData.hospitalName}
                        onChange={(e) => setRegistrationData(prev => ({ ...prev, hospitalName: e.target.value }))}
                        className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                      />
                    </div>
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.hospitalType} *
                    </label>
                    <select
                      value={registrationData.hospitalType}
                      onChange={(e) => setRegistrationData(prev => ({ ...prev, hospitalType: e.target.value as 'GOVERNMENT' | 'PRIVATE' | 'NGO' }))}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'border-gray-200'}`}
                    >
                      <option value="">Select type</option>
                      <option value="GOVERNMENT">{tr.government}</option>
                      <option value="PRIVATE">{tr.privateHospital}</option>
                      <option value="NGO">{tr.ngoHospital}</option>
                    </select>
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.region} *
                    </label>
                    <select
                      value={registrationData.region}
                      onChange={(e) => setRegistrationData(prev => ({ ...prev, region: e.target.value }))}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'border-gray-200'}`}
                    >
                      {Object.keys(REGION_COORDINATES).map(region => (
                        <option key={region} value={region}>{region}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.city} *
                    </label>
                    <input
                      type="text"
                      placeholder="e.g., Addis Ababa"
                      value={registrationData.city}
                      onChange={(e) => setRegistrationData(prev => ({ ...prev, city: e.target.value }))}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                    />
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.operatingHoursLabel}
                    </label>
                    <select
                      value={registrationData.operatingHours}
                      onChange={(e) => setRegistrationData(prev => ({ ...prev, operatingHours: e.target.value }))}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'border-gray-200'}`}
                    >
                      <option value="24/7">{tr.hours247}</option>
                      <option value="business">{tr.hoursBusiness}</option>
                      <option value="extended">{tr.hoursExtended}</option>
                      <option value="custom">{tr.hoursCustom}</option>
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.address}
                    </label>
                    <input
                      type="text"
                      placeholder="Full address"
                      value={registrationData.address}
                      onChange={(e) => setRegistrationData(prev => ({ ...prev, address: e.target.value }))}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                    />
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.phoneLabel} *
                    </label>
                    <div className="relative">
                      <Phone size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                      <input
                        type="tel"
                        placeholder="011XXXXXXXX"
                        value={registrationData.phone}
                        onChange={(e) => setRegistrationData(prev => ({ ...prev, phone: e.target.value }))}
                        className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                      />
                    </div>
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.emailAddress}
                    </label>
                    <div className="relative">
                      <EnvelopeSimple size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                      <input
                        type="email"
                        placeholder="hospital@example.com"
                        value={registrationData.email}
                        onChange={(e) => setRegistrationData(prev => ({ ...prev, email: e.target.value }))}
                        className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                      />
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setRegistrationStep(2)}
                  disabled={!registrationData.hospitalName || !registrationData.hospitalType || !registrationData.region || !registrationData.city || !registrationData.phone}
                  className="w-full py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-emerald-500/25 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {tr.continueBtn}
                  <ArrowRight size={20} />
                </button>
              </div>
            )}

            {/* Step 2: Services */}
            {registrationStep === 2 && (
              <div className="space-y-6">
                <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {tr.servicesOffered}
                </h3>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {services.map(service => (
                    <button
                      key={service.id}
                      type="button"
                      onClick={() => handleServiceToggle(service.id)}
                      className={`p-4 rounded-xl border-2 transition-all text-left ${
                        registrationData.services.includes(service.id)
                          ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/30'
                          : darkMode ? 'border-gray-700 hover:border-gray-600' : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-5 h-5 rounded flex items-center justify-center ${
                          registrationData.services.includes(service.id)
                            ? 'bg-emerald-500 text-white'
                            : darkMode ? 'bg-gray-700' : 'bg-gray-200'
                        }`}>
                          {registrationData.services.includes(service.id) && <Check size={14} />}
                        </div>
                        <span className={`text-sm font-medium ${darkMode ? 'text-gray-200' : 'text-gray-700'}`}>
                          {service.label}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setRegistrationStep(1)}
                    className={`flex-1 py-4 border rounded-xl font-semibold transition flex items-center justify-center gap-2 ${darkMode ? 'border-gray-700 text-gray-300 hover:bg-gray-800' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                  >
                    <ArrowLeft size={20} />
                    {tr.backBtn}
                  </button>
                  <button
                    type="button"
                    onClick={() => setRegistrationStep(3)}
                    className="flex-1 py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-emerald-500/25 transition-all flex items-center justify-center gap-2"
                  >
                    {tr.continueBtn}
                    <ArrowRight size={20} />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Admin Account */}
            {registrationStep === 3 && (
              <div className="space-y-6">
                <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {tr.adminInfo}
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.adminName} *
                    </label>
                    <div className="relative">
                      <User size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                      <input
                        type="text"
                        placeholder="Your full name"
                        value={registrationData.adminName}
                        onChange={(e) => setRegistrationData(prev => ({ ...prev, adminName: e.target.value }))}
                        className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                      />
                    </div>
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.adminPhone} *
                    </label>
                    <div className="relative">
                      <Phone size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                      <input
                        type="tel"
                        placeholder="09XXXXXXXXX"
                        value={registrationData.adminPhone}
                        onChange={(e) => setRegistrationData(prev => ({ ...prev, adminPhone: e.target.value }))}
                        className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                      />
                    </div>
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.createPassword} *
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Min. 8 characters"
                        value={registrationData.adminPassword}
                        onChange={(e) => setRegistrationData(prev => ({ ...prev, adminPassword: e.target.value }))}
                        className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition pr-12 ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className={`absolute right-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}
                      >
                        {showPassword ? <EyeSlash size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                    <p className={`text-xs mt-1 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>{tr.passwordRequirements}</p>
                  </div>

                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                      {tr.confirmPassword} *
                    </label>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Confirm password"
                      value={registrationData.confirmPassword}
                      onChange={(e) => setRegistrationData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                    />
                  </div>

                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={registrationData.agreeToTerms}
                      onChange={(e) => setRegistrationData(prev => ({ ...prev, agreeToTerms: e.target.checked }))}
                      className="w-5 h-5 mt-0.5 rounded border-gray-300 text-emerald-500 focus:ring-emerald-500"
                    />
                    <span className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                      {tr.agreeToTerms}
                    </span>
                  </label>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setRegistrationStep(2)}
                    className={`flex-1 py-4 border rounded-xl font-semibold transition flex items-center justify-center gap-2 ${darkMode ? 'border-gray-700 text-gray-300 hover:bg-gray-800' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                  >
                    <ArrowLeft size={20} />
                    {tr.backBtn}
                  </button>
                  <button
                    type="button"
                    onClick={handleRegister}
                    disabled={loading || !registrationData.adminName || !registrationData.adminPhone || !registrationData.adminPassword}
                    className="flex-1 py-4 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-emerald-500/25 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {loading ? (
                      <ArrowClockwise className="animate-spin" size={20} />
                    ) : (
                      <>
                        {tr.registerBtn}
                        <Check size={20} />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            <div className={`mt-6 pt-6 border-t text-center ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                {tr.alreadyHaveAccount}{' '}
                <button type="button" onClick={() => setView('auth')} className="text-emerald-600 hover:underline font-medium">
                  {tr.signInInstead}
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }, [darkMode, language, registrationData, registrationStep, showPassword, loading, tr, REGION_COORDINATES]);

  // Hospital Dashboard Page
  const HospitalDashboardPage = () => {
    // Mock data for demo
    useEffect(() => {
      // Initialize mock data
      setHospitalProfile({
        name: 'Tikur Anbessa General Hospital',
        type: 'GOVERNMENT',
        region: 'Addis Ababa',
        city: 'Addis Ababa',
        address: 'Churchill Road, P.O. Box 1176',
        phone: '0115-515125',
        email: 'info@tikuranbessa.gov.et',
        latitude: 9.0320,
        longitude: 38.7469,
        operatingHours: '24/7',
        services: ['emergency', 'outpatient', 'inpatient', 'laboratory', 'radiology'],
      });
      setDashboardStats({
        todayPatients: 156,
        waiting: 23,
        served: 133,
        avgWaitTime: 32,
      });
      setDashboardQueues([
        { departmentId: '1', departmentName: 'General Medicine', currentToken: 45, waiting: 8, served: 37, status: 'normal' },
        { departmentId: '2', departmentName: 'Pediatrics', currentToken: 23, waiting: 5, served: 18, status: 'normal' },
        { departmentId: '3', departmentName: 'Emergency', currentToken: 67, waiting: 12, served: 55, status: 'busy' },
        { departmentId: '4', departmentName: 'Obstetrics', currentToken: 12, waiting: 3, served: 9, status: 'normal' },
      ]);
    }, []);

    const sidebarItems = [
      { id: 'overview', icon: House, label: tr.overview },
      { id: 'profile', icon: Hospital, label: tr.profile },
      { id: 'location', icon: MapPin, label: tr.location },
      { id: 'queues', icon: Users, label: tr.queues },
      { id: 'departments', icon: Stethoscope, label: tr.departments },
      { id: 'staff', icon: IdentificationCard, label: tr.staff },
      { id: 'analytics', icon: ChartBar, label: tr.analytics },
      { id: 'settings', icon: Gear, label: tr.settings },
    ];

    const renderContent = () => {
      switch (dashboardSection) {
        case 'overview':
          return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Welcome Banner */}
              <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-6 text-white shadow-xl">
                <h2 className="text-2xl font-bold mb-2">{tr.welcomeBack}, {user?.name?.split(' ')[0] || 'Admin'}!</h2>
                <p className="text-emerald-100">{tr.manageYourHospital}</p>
              </div>

              {/* Stats Grid */}
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                  <div className="flex items-center justify-between mb-3">
                    <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.todayPatients}</span>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${darkMode ? 'bg-blue-900/50' : 'bg-blue-100'}`}>
                      <Users size={20} className="text-blue-600" />
                    </div>
                  </div>
                  <p className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{dashboardStats.todayPatients}</p>
                </div>
                <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                  <div className="flex items-center justify-between mb-3">
                    <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.currentlyWaiting}</span>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${darkMode ? 'bg-amber-900/50' : 'bg-amber-100'}`}>
                      <Timer size={20} className="text-amber-600" />
                    </div>
                  </div>
                  <p className="text-3xl font-bold text-amber-600">{dashboardStats.waiting}</p>
                </div>
                <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                  <div className="flex items-center justify-between mb-3">
                    <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.servedToday}</span>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                      <CheckCircle size={20} className="text-emerald-600" />
                    </div>
                  </div>
                  <p className="text-3xl font-bold text-emerald-600">{dashboardStats.served}</p>
                </div>
                <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                  <div className="flex items-center justify-between mb-3">
                    <span className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.averageWaitTime}</span>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${darkMode ? 'bg-purple-900/50' : 'bg-purple-100'}`}>
                      <Clock size={20} className="text-purple-600" />
                    </div>
                  </div>
                  <p className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{dashboardStats.avgWaitTime}<span className="text-lg font-normal">min</span></p>
                </div>
              </div>

              {/* Queue Status Table */}
              <div className={`rounded-2xl shadow-lg overflow-hidden transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <div className={`p-6 border-b ${darkMode ? 'border-gray-700' : 'border-gray-100'}`}>
                  <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.queueStatus}</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className={darkMode ? 'bg-gray-700/50' : 'bg-gray-50'}>
                      <tr>
                        <th className={`text-left py-4 px-6 text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.departmentName}</th>
                        <th className={`text-center py-4 px-6 text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.currentToken}</th>
                        <th className={`text-center py-4 px-6 text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.waitingCount}</th>
                        <th className={`text-center py-4 px-6 text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.servedCount}</th>
                        <th className={`text-center py-4 px-6 text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{tr.status}</th>
                        <th className={`text-right py-4 px-6 text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {dashboardQueues.map((queue, index) => (
                        <tr key={queue.departmentId} className={index % 2 === 0 ? '' : darkMode ? 'bg-gray-750/30' : 'bg-gray-50/50'}>
                          <td className="py-4 px-6">
                            <div className="flex items-center gap-3">
                              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${darkMode ? 'bg-emerald-900/50' : 'bg-emerald-100'}`}>
                                <Stethoscope size={16} className="text-emerald-600" />
                              </div>
                              <span className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{queue.departmentName}</span>
                            </div>
                          </td>
                          <td className={`py-4 px-6 text-center font-mono font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>#{queue.currentToken}</td>
                          <td className="py-4 px-6 text-center">
                            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                              queue.waiting > 10 ? (darkMode ? 'bg-red-900/50 text-red-400' : 'bg-red-100 text-red-700') :
                              queue.waiting > 5 ? (darkMode ? 'bg-amber-900/50 text-amber-400' : 'bg-amber-100 text-amber-700') :
                              (darkMode ? 'bg-green-900/50 text-green-400' : 'bg-green-100 text-green-700')
                            }`}>
                              {queue.waiting}
                            </span>
                          </td>
                          <td className={`py-4 px-6 text-center ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{queue.served}</td>
                          <td className="py-4 px-6 text-center">
                            <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${
                              queue.status === 'busy' ? (darkMode ? 'bg-red-900/50 text-red-400' : 'bg-red-100 text-red-700') : (darkMode ? 'bg-green-900/50 text-green-400' : 'bg-green-100 text-green-700')
                            }`}>
                              <div className={`w-1.5 h-1.5 rounded-full ${queue.status === 'busy' ? 'bg-red-500' : 'bg-green-500'}`}></div>
                              {queue.status === 'busy' ? tr.busy : tr.normal}
                            </span>
                          </td>
                          <td className="py-4 px-6 text-right">
                            <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition">
                              {tr.callNext}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Quick Actions */}
              <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.quickActions}</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <button onClick={() => setDashboardSection('queues')} className={`p-4 rounded-xl transition text-center ${darkMode ? 'bg-emerald-900/50 text-emerald-400 hover:bg-emerald-900/70' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'}`}>
                    <Users size={24} className="mx-auto mb-2" />
                    <span className="text-sm font-medium">{tr.manageQueues}</span>
                  </button>
                  <button className={`p-4 rounded-xl transition text-center ${darkMode ? 'bg-red-900/50 text-red-400 hover:bg-red-900/70' : 'bg-red-50 text-red-700 hover:bg-red-100'}`}>
                    <FirstAid size={24} className="mx-auto mb-2" />
                    <span className="text-sm font-medium">{tr.addEmergency}</span>
                  </button>
                  <button className={`p-4 rounded-xl transition text-center ${darkMode ? 'bg-blue-900/50 text-blue-400 hover:bg-blue-900/70' : 'bg-blue-50 text-blue-700 hover:bg-blue-100'}`}>
                    <Bell size={24} className="mx-auto mb-2" />
                    <span className="text-sm font-medium">{tr.broadcastAlert}</span>
                  </button>
                  <button onClick={() => setDashboardSection('analytics')} className={`p-4 rounded-xl transition text-center ${darkMode ? 'bg-purple-900/50 text-purple-400 hover:bg-purple-900/70' : 'bg-purple-50 text-purple-700 hover:bg-purple-100'}`}>
                    <ChartBar size={24} className="mx-auto mb-2" />
                    <span className="text-sm font-medium">{tr.viewReports}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          );

        case 'profile':
          return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <div className="flex items-center justify-between mb-6">
                  <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.editProfile}</h3>
                  <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition">
                    {tr.saveChanges}
                  </button>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.hospitalName}</label>
                    <input
                      type="text"
                      value={hospitalProfile?.name || ''}
                      onChange={(e) => setHospitalProfile(prev => prev ? { ...prev, name: e.target.value } : null)}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.hospitalType}</label>
                    <select
                      value={hospitalProfile?.type || ''}
                      onChange={(e) => setHospitalProfile(prev => prev ? { ...prev, type: e.target.value } : null)}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                    >
                      <option value="GOVERNMENT">{tr.government}</option>
                      <option value="PRIVATE">{tr.privateHospital}</option>
                      <option value="NGO">{tr.ngoHospital}</option>
                    </select>
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.region}</label>
                    <input
                      type="text"
                      value={hospitalProfile?.region || ''}
                      onChange={(e) => setHospitalProfile(prev => prev ? { ...prev, region: e.target.value } : null)}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.city}</label>
                    <input
                      type="text"
                      value={hospitalProfile?.city || ''}
                      onChange={(e) => setHospitalProfile(prev => prev ? { ...prev, city: e.target.value } : null)}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.address}</label>
                    <input
                      type="text"
                      value={hospitalProfile?.address || ''}
                      onChange={(e) => setHospitalProfile(prev => prev ? { ...prev, address: e.target.value } : null)}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.phoneLabel}</label>
                    <input
                      type="tel"
                      value={hospitalProfile?.phone || ''}
                      onChange={(e) => setHospitalProfile(prev => prev ? { ...prev, phone: e.target.value } : null)}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.emailAddress}</label>
                    <input
                      type="email"
                      value={hospitalProfile?.email || ''}
                      onChange={(e) => setHospitalProfile(prev => prev ? { ...prev, email: e.target.value } : null)}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          );

        case 'location':
          return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.hospitalLocation}</h3>
                <p className={`mb-4 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>{tr.clickMapToSet}</p>
                
                {/* Map Placeholder */}
                <div className={`w-full h-80 rounded-xl flex items-center justify-center ${darkMode ? 'bg-gray-700' : 'bg-gray-100'}`}>
                  <div className="text-center">
                    <MapPin size={48} className={`mx-auto mb-2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                    <p className={darkMode ? 'text-gray-400' : 'text-gray-500'}>Interactive Map</p>
                    <p className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>Click to set hospital location</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.latitude}</label>
                    <input
                      type="number"
                      step="0.0001"
                      value={hospitalProfile?.latitude || ''}
                      onChange={(e) => setHospitalProfile(prev => prev ? { ...prev, latitude: parseFloat(e.target.value) } : null)}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                    />
                  </div>
                  <div>
                    <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.longitude}</label>
                    <input
                      type="number"
                      step="0.0001"
                      value={hospitalProfile?.longitude || ''}
                      onChange={(e) => setHospitalProfile(prev => prev ? { ...prev, longitude: parseFloat(e.target.value) } : null)}
                      className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                    />
                  </div>
                </div>

                <button className="mt-4 w-full py-3 bg-emerald-600 text-white rounded-xl font-medium hover:bg-emerald-700 transition flex items-center justify-center gap-2">
                  <Crosshair size={20} />
                  {tr.useCurrentLocation}
                </button>
              </div>
            </motion.div>
          );

        case 'queues':
          return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.manageQueues}</h3>
                
                {dashboardQueues.map((queue) => (
                  <div key={queue.departmentId} className={`mb-4 p-4 rounded-xl ${darkMode ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{queue.departmentName}</h4>
                      <span className="text-2xl font-bold text-emerald-600">#{queue.currentToken}</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm mb-3">
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-600'}>{queue.waiting} {tr.waitingCount}</span>
                      <span className={darkMode ? 'text-gray-400' : 'text-gray-600'}>{queue.served} {tr.servedCount}</span>
                    </div>
                    <div className="flex gap-2">
                      <button className="flex-1 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 transition">
                        {tr.callNext}
                      </button>
                      <button className={`py-2 px-4 rounded-lg text-sm font-medium transition ${darkMode ? 'bg-gray-600 text-gray-300 hover:bg-gray-500' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
                        {tr.viewQueue}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          );

        case 'departments':
          return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between">
                <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.departments}</h3>
                <button
                  onClick={() => setShowAddDepartment(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition"
                >
                  <Plus size={20} />
                  {tr.addDepartment}
                </button>
              </div>

              {showAddDepartment && (
                <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                  <h4 className={`font-medium mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.addDepartment}</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.departmentNameLabel}</label>
                      <input
                        type="text"
                        value={newDepartment.name}
                        onChange={(e) => setNewDepartment({ ...newDepartment, name: e.target.value })}
                        placeholder="e.g., Cardiology"
                        className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                      />
                    </div>
                    <div>
                      <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.departmentDesc}</label>
                      <input
                        type="text"
                        value={newDepartment.description}
                        onChange={(e) => setNewDepartment({ ...newDepartment, description: e.target.value })}
                        placeholder="Brief description"
                        className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                      />
                    </div>
                    <div>
                      <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.dailyCapacity}</label>
                      <input
                        type="number"
                        value={newDepartment.capacity}
                        onChange={(e) => setNewDepartment({ ...newDepartment, capacity: parseInt(e.target.value) })}
                        className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                      />
                    </div>
                    <div>
                      <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{tr.avgServiceTime}</label>
                      <input
                        type="number"
                        value={newDepartment.avgTime}
                        onChange={(e) => setNewDepartment({ ...newDepartment, avgTime: parseInt(e.target.value) })}
                        className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'border-gray-200'}`}
                      />
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <button
                      onClick={() => setShowAddDepartment(false)}
                      className={`px-4 py-2 rounded-lg font-medium transition ${darkMode ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
                    >
                      {tr.cancel}
                    </button>
                    <button
                      onClick={() => {
                        setShowAddDepartment(false);
                        setNewDepartment({ name: '', description: '', capacity: 50, avgTime: 15 });
                      }}
                      className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700 transition"
                    >
                      {tr.saveChanges}
                    </button>
                  </div>
                </div>
              )}

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {dashboardQueues.map((dept) => (
                  <div key={dept.departmentId} className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className={`font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{dept.departmentName}</h4>
                      <div className="flex gap-1">
                        <button className={`p-2 rounded-lg transition ${darkMode ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-500'}`}>
                          <PencilSimple size={16} />
                        </button>
                      </div>
                    </div>
                    <div className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      <p>Current Token: <span className="font-bold text-emerald-600">#{dept.currentToken}</span></p>
                      <p>{tr.waitingCount}: {dept.waiting}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          );

        case 'analytics':
          return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.analytics}</h3>
                <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>Analytics dashboard coming soon...</p>
              </div>
            </motion.div>
          );

        case 'staff':
          return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.staff}</h3>
                <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>Staff management coming soon...</p>
              </div>
            </motion.div>
          );

        case 'settings':
          return (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className={`rounded-2xl shadow-lg p-6 transition-colors duration-300 ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                <h3 className={`text-lg font-semibold mb-4 ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.settings}</h3>
                <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>Settings panel coming soon...</p>
              </div>
            </motion.div>
          );

        default:
          return null;
      }
    };

    return (
      <div className={`min-h-screen flex transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
        {/* Sidebar */}
        <aside className={`w-64 fixed left-0 top-0 h-full z-40 flex flex-col transition-colors duration-300 ${darkMode ? 'bg-gray-900 border-r border-gray-800' : 'bg-white border-r border-gray-200'}`}>
          {/* Logo */}
          <div className="p-6">
            <button onClick={() => setView('landing')} className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
                <Heart weight="fill" className="text-white" size={22} />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-emerald-500 to-teal-500 bg-clip-text text-transparent">
                Hakim
              </span>
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-4 py-2">
            {sidebarItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setDashboardSection(item.id as DashboardSection)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl mb-1 transition-all ${
                  dashboardSection === item.id
                    ? darkMode ? 'bg-emerald-900/50 text-emerald-400 font-medium' : 'bg-emerald-50 text-emerald-600 font-medium'
                    : darkMode ? 'text-gray-400 hover:text-white hover:bg-gray-800' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <item.icon size={20} />
                <span>{item.label}</span>
              </button>
            ))}
          </nav>

          {/* User Section */}
          <div className={`p-4 border-t ${darkMode ? 'border-gray-800' : 'border-gray-200'}`}>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full flex items-center justify-center shadow-sm">
                <User size={16} className="text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className={`font-medium truncate ${darkMode ? 'text-white' : 'text-gray-900'}`}>{user?.name || 'Admin'}</p>
                <p className={`text-xs truncate ${darkMode ? 'text-gray-500' : 'text-gray-500'}`}>{hospitalProfile?.name}</p>
              </div>
            </div>
            <button
              onClick={() => { logout(); setView('landing'); }}
              className={`w-full flex items-center gap-2 px-4 py-2 rounded-lg transition ${darkMode ? 'text-red-400 hover:bg-red-900/30' : 'text-red-600 hover:bg-red-50'}`}
            >
              <SignOut size={18} />
              {tr.signOut}
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 ml-64 min-h-screen">
          {/* Header */}
          <header className={`sticky top-0 z-30 px-6 py-4 border-b backdrop-blur-sm ${darkMode ? 'bg-gray-950/80 border-gray-800' : 'bg-white/80 border-gray-200'}`}>
            <div className="flex items-center justify-between">
              <div>
                <h1 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{tr.dashboardTitle}</h1>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{hospitalProfile?.name}</p>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={toggleDarkMode}
                  className={`p-2.5 rounded-xl transition-all ${darkMode ? 'bg-gray-800 text-yellow-400 hover:bg-gray-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                  {darkMode ? <Sun size={20} weight="fill" /> : <Moon size={20} />}
                </button>
                <button
                  onClick={toggleLanguage}
                  className={`flex items-center gap-1.5 p-2.5 rounded-xl transition-all ${darkMode ? 'bg-gray-800 text-gray-300 hover:bg-gray-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                  <Globe size={18} />
                  <span className="text-xs font-medium">{language === 'en' ? 'አማ' : 'EN'}</span>
                </button>
              </div>
            </div>
          </header>

          {/* Content */}
          <div className="p-6">
            {renderContent()}
          </div>
        </main>
      </div>
    );
  };

  // Nearest Hospitals Page
  const NearestHospitalsPage = () => {
    const nearestHospitals = getHospitalsByDistance();
    
    return (
      <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
        <Navigation />
        
        <section className={`pt-8 pb-8 transition-colors duration-300 ${darkMode ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950' : 'bg-gradient-to-br from-blue-50 via-white to-emerald-50'}`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <button
                onClick={() => setView('landing')}
                className={`flex items-center gap-2 transition mb-6 ${darkMode ? 'text-gray-400 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
              >
                <ArrowLeft size={20} />
                Back to Home
              </button>
              
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${darkMode ? 'bg-blue-900/50' : 'bg-blue-100'}`}>
                  <Crosshair size={24} className="text-blue-600" />
                </div>
                <div>
                  <h1 className={`text-2xl sm:text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    Nearest Hospitals
                  </h1>
                  <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
                    Hospitals sorted by distance from your location
                  </p>
                </div>
              </div>

              {/* Location Info */}
              {locationNotice ? (
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${darkMode ? 'bg-blue-900/50 text-blue-300' : 'bg-blue-50 text-blue-700'}`}>
                  <Info size={16} />
                  <span>{locationNotice}</span>
                </div>
              ) : userLocation && (
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${darkMode ? 'bg-emerald-900/50 text-emerald-300' : 'bg-emerald-50 text-emerald-700'}`}>
                  <MapPin size={16} />
                  <span>Location detected</span>
                  <span className="text-emerald-600">
                    ({userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)})
                  </span>
                </div>
              )}
            </motion.div>
          </div>
        </section>

        <section className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {loading ? (
              <Spinner />
            ) : nearestHospitals.length === 0 ? (
              <div className="text-center py-16">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${darkMode ? 'bg-gray-800' : 'bg-gray-100'}`}>
                  <Hospital size={40} className={darkMode ? 'text-gray-500' : 'text-gray-400'} />
                </div>
                <h3 className={`text-xl font-semibold mb-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>No Hospitals Found</h3>
                <p className={`mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  Unable to find hospitals near your location. Please try searching manually.
                </p>
                <button
                  onClick={() => setView('hospitals')}
                  className="px-6 py-3 bg-emerald-600 text-white rounded-xl font-medium hover:bg-emerald-700 transition"
                >
                  Browse All Hospitals
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Top 3 Nearest - Featured Cards */}
                <div className="mb-8">
                  <h2 className={`text-lg font-semibold mb-4 flex items-center gap-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    <NavigationArrow size={20} className="text-blue-600" />
                    Closest to You
                  </h2>
                  <div className="grid md:grid-cols-3 gap-4">
                    {nearestHospitals.slice(0, 3).map((hospital, index) => (
                      <motion.button
                        key={hospital.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        onClick={() => {
                          setSelectedHospital(hospital);
                          loadDepartments(hospital.id);
                          setView('departments');
                        }}
                        className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-6 text-left text-white shadow-xl shadow-emerald-500/20 hover:shadow-2xl hover:shadow-emerald-500/30 transition-all group relative overflow-hidden"
                      >
                        <div className="absolute top-4 right-4 w-8 h-8 bg-white/20 rounded-full flex items-center justify-center text-lg font-bold">
                          {index + 1}
                        </div>
                        <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                          <Hospital size={24} />
                        </div>
                        <h3 className="text-lg font-bold mb-1">{hospital.name}</h3>
                        <div className="flex items-center gap-2 text-emerald-100 text-sm mb-3">
                          <MapPin size={14} />
                          <span>{hospital.region}</span>
                        </div>
                        <div className="flex items-center justify-between pt-3 border-t border-white/20">
                          <div className="flex items-center gap-2">
                            <NavigationArrow size={16} />
                            <span className="font-bold">
                              {hospital.distance < 1 
                                ? `${Math.round(hospital.distance * 1000)} m` 
                                : `${hospital.distance.toFixed(1)} km`}
                            </span>
                          </div>
                          <CaretRight size={20} className="group-hover:translate-x-1 transition-transform" />
                        </div>
                      </motion.button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        <Footer />
      </div>
    );
  };

  // Admin Login Page
  const AdminLoginPage = () => {
    const [adminPhone, setAdminPhone] = useState('');
    const [adminPassword, setAdminPassword] = useState('');
    const [adminLoading, setAdminLoading] = useState(false);

    const handleAdminLogin = async () => {
      setAdminLoading(true);
      try {
        // Simulate admin login
        await new Promise(resolve => setTimeout(resolve, 1000));
        login({ id: 'admin', name: 'Hospital Admin', phone: adminPhone, role: 'admin' });
        setView('hospital-dashboard');
      } catch (error) {
        alert('Login failed. Please try again.');
      } finally {
        setAdminLoading(false);
      }
    };

    return (
      <div className={`min-h-screen flex items-center justify-center p-4 transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gradient-to-br from-emerald-50 via-white to-teal-50'}`}>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <div className="text-center mb-8">
            <button onClick={() => setView('landing')} className="inline-flex items-center gap-2 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
                <Heart weight="fill" className="text-white" size={28} />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                Hakim
              </span>
            </button>
            <h2 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
              Hospital Admin Login
            </h2>
            <p className={`mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Sign in to manage your hospital
            </p>
          </div>

          <div className={`rounded-3xl shadow-xl p-8 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}>
            <div className="space-y-4">
              <div>
                <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Phone Number
                </label>
                <div className="relative">
                  <Phone size={20} className={`absolute left-4 top-1/2 -translate-y-1/2 ${darkMode ? 'text-gray-500' : 'text-gray-400'}`} />
                  <input
                    type="tel"
                    placeholder="09XXXXXXXXX"
                    value={adminPhone}
                    onChange={(e) => setAdminPhone(e.target.value)}
                    className={`w-full pl-12 pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                  />
                </div>
              </div>
              <div>
                <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Password
                </label>
                <input
                  type="password"
                  placeholder="Enter your password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition ${darkMode ? 'bg-gray-800 border-gray-700 text-white placeholder-gray-500' : 'border-gray-200'}`}
                />
              </div>
              <button
                onClick={handleAdminLogin}
                disabled={adminLoading || !adminPhone || !adminPassword}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-semibold hover:shadow-lg hover:shadow-emerald-500/25 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {adminLoading ? (
                  <ArrowClockwise className="animate-spin" size={20} />
                ) : (
                  <>
                    Sign In
                    <ArrowRight size={20} />
                  </>
                )}
              </button>
            </div>

            <div className={`mt-6 pt-6 border-t text-center ${darkMode ? 'border-gray-800' : 'border-gray-100'}`}>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Don't have an account?{' '}
                <button onClick={() => setView('hospital-register')} className="text-emerald-600 hover:underline font-medium">
                  Register your hospital
                </button>
              </p>
            </div>
          </div>

          <button
            onClick={() => setView('landing')}
            className={`w-full mt-6 py-3 transition flex items-center justify-center gap-2 ${darkMode ? 'text-gray-400 hover:text-emerald-400' : 'text-gray-600 hover:text-emerald-600'}`}
          >
            <ArrowLeft size={16} />
            Back to Home
          </button>
        </motion.div>
      </div>
    );
  };

  // Admin Analytics Page
  const AdminAnalyticsPage = () => {
    return (
      <div className={`min-h-screen flex transition-colors duration-300 ${darkMode ? 'bg-gray-950' : 'bg-gray-50'}`}>
        <p>Admin Analytics Page</p>
      </div>
    );
  };
  // Main Render
  return (
    <div className={`${darkMode ? 'dark bg-gray-950' : ''} min-h-screen transition-colors duration-300`}>
      <AnimatePresence mode="wait">
        <motion.div
          key={view}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          {view === 'landing' && <LandingPage />}
          {view === 'features' && <FeaturesPage />}
          {view === 'about' && <AboutPage />}
          {view === 'contact' && <ContactPage />}
          {view === 'faq' && <FAQPage />}
          {view === 'privacy' && <PrivacyPage />}
          {view === 'terms' && <TermsPage />}
          {view === 'auth' && <AuthPage />}
          {view === 'hospitals' && <HospitalsPage />}
          {view === 'map' && <MapPage />}
          {view === 'nearest-hospitals' && <NearestHospitalsPage />}
          {view === 'departments' && <DepartmentsPage />}
          {view === 'booking' && <BookingPage />}
          {view === 'token' && <TokenPage />}
          {view === 'emergency' && <EmergencyPage />}
          {view === 'admin-login' && <AdminLoginPage />}
          {view === 'admin-dashboard' && <AdminDashboardPage />}
          {view === 'admin-queue' && <AdminQueuePage />}
          {view === 'admin-analytics' && <AdminAnalyticsPage />}
          {view === 'profile' && <ProfilePage />}
          {view === 'hospital-register' && <HospitalRegistrationPage key="hospital-register-form" />}
          {view === 'hospital-dashboard' && <HospitalDashboardPage />}
        </motion.div>
      </AnimatePresence>

      {/* Location Permission Modal */}
      <AnimatePresence>
        {showLocationModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className={`rounded-3xl shadow-2xl max-w-md w-full p-8 transition-colors duration-300 ${darkMode ? 'bg-gray-900' : 'bg-white'}`}
            >
              {/* Icon */}
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${darkMode ? 'bg-blue-900/50' : 'bg-blue-100'}`}>
                <Crosshair size={32} className="text-blue-600" />
              </div>

              {/* Title */}
              <h3 className={`text-xl font-bold mb-2 text-center ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                Find Nearest Hospital
              </h3>

              {/* Error message if any */}
              {locationError && (
                <div className={`mb-4 p-3 border rounded-xl text-sm flex items-start gap-2 ${darkMode ? 'bg-amber-900/30 border-amber-700/50 text-amber-400' : 'bg-amber-50 border border-amber-200 text-amber-700'}`}>
                  <Warning size={18} className="flex-shrink-0 mt-0.5" />
                  <span>{locationError}</span>
                </div>
              )}

              {/* Use My Location Button */}
              <button
                onClick={requestLocation}
                disabled={locationLoading}
                className="w-full px-4 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60 mb-4"
              >
                {locationLoading ? (
                  <>
                    <ArrowClockwise size={20} className="animate-spin" />
                    Getting Location...
                  </>
                ) : (
                  <>
                    <NavigationArrow size={20} />
                    Use My Current Location
                  </>
                )}
              </button>

              {/* Divider */}
              <div className="flex items-center gap-3 my-4">
                <div className={`flex-1 h-px ${darkMode ? 'bg-gray-700' : 'bg-gray-200'}`}></div>
                <span className={`text-sm ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>or select your region</span>
                <div className={`flex-1 h-px ${darkMode ? 'bg-gray-700' : 'bg-gray-200'}`}></div>
              </div>

              {/* Region Selector */}
              <div className="mb-4">
                <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                  Select Region
                </label>
                <select
                  value={selectedRegion}
                  onChange={(e) => setSelectedRegion(e.target.value)}
                  className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition cursor-pointer ${darkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-gray-50 border-gray-200'}`}
                >
                  {Object.keys(REGION_COORDINATES).map(region => (
                    <option key={region} value={region}>{region}</option>
                  ))}
                </select>
              </div>

              {/* Use Selected Region Button */}
              <button
                onClick={useSelectedRegion}
                className="w-full px-4 py-3 bg-emerald-600 text-white rounded-xl font-semibold hover:bg-emerald-700 transition flex items-center justify-center gap-2 cursor-pointer mb-3"
              >
                <MapPin size={20} />
                Show Hospitals in {selectedRegion}
              </button>

              {/* Cancel */}
              <button
                onClick={() => {
                  setShowLocationModal(false);
                  setLocationError(null);
                }}
                className={`w-full px-4 py-2 transition text-sm cursor-pointer ${darkMode ? 'text-gray-400 hover:text-gray-200' : 'text-gray-500 hover:text-gray-700'}`}
              >
                Cancel
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// PlayCircle icon (missing from Phosphor)
function PlayCircle({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polygon points="10 8 16 12 10 16 10 8" fill="currentColor" />
    </svg>
  );
}
