// Mock Hospital Data for Hakim - 500 Ethiopian Hospitals

export interface MockHospital {
  id: string;
  name: string;
  region: string;
  address: string;
  latitude: number;
  longitude: number;
  emergencyContactNumber: string;
  isActive: boolean;
  type: 'GOVERNMENT' | 'PRIVATE' | 'NGO';
  departments: { name: string; avgTime: number; capacity: number }[];
}

// Region coordinates for generating hospital locations
const regionCenters: Record<string, { lat: number; lng: number }> = {
  'Addis Ababa': { lat: 9.0320, lng: 38.7469 },
  'Oromia': { lat: 8.5435, lng: 39.2695 },
  'Amhara': { lat: 11.5985, lng: 37.3907 },
  'Tigray': { lat: 14.0363, lng: 38.3085 },
  'SNNPR': { lat: 7.0557, lng: 38.4834 },
  'Afar': { lat: 11.7908, lng: 41.0091 },
  'Somali': { lat: 6.8570, lng: 44.2542 },
  'Benishangul-Gumuz': { lat: 10.4657, lng: 34.5408 },
  'Gambela': { lat: 8.2479, lng: 34.5931 },
  'Harari': { lat: 9.3107, lng: 42.1272 },
  'Dire Dawa': { lat: 9.6008, lng: 41.8555 },
  'Sidama': { lat: 6.7450, lng: 38.4867 },
  'South West Ethiopia': { lat: 7.0089, lng: 36.5667 },
};

// Common hospital name patterns
const govPrefixes = ['', 'Regional', 'Zonal', 'District', 'Primary', 'General', 'Referral', 'Specialized'];
const privatePrefixes = ['Private', 'Specialized', 'Medical Center', 'Clinic', 'Hospital'];
const ngoPrefixes = ['Catholic', 'Orthodox', 'Protestant', 'Mission', 'Charity', 'Community'];

const departmentTypes = [
  { name: 'General Medicine', avgTime: 15, capacity: 150 },
  { name: 'Pediatrics', avgTime: 20, capacity: 100 },
  { name: 'Emergency', avgTime: 30, capacity: 50 },
  { name: 'Obstetrics & Gynecology', avgTime: 25, capacity: 80 },
  { name: 'Surgery', avgTime: 30, capacity: 60 },
  { name: 'Orthopedics', avgTime: 25, capacity: 70 },
  { name: 'Ophthalmology', avgTime: 15, capacity: 100 },
  { name: 'ENT', avgTime: 15, capacity: 80 },
  { name: 'Dermatology', avgTime: 10, capacity: 120 },
  { name: 'Cardiology', avgTime: 25, capacity: 50 },
  { name: 'Neurology', avgTime: 25, capacity: 40 },
  { name: 'Psychiatry', avgTime: 30, capacity: 60 },
  { name: 'Dental', avgTime: 20, capacity: 80 },
  { name: 'Laboratory', avgTime: 10, capacity: 200 },
  { name: 'Radiology', avgTime: 15, capacity: 100 },
  { name: 'Pharmacy', avgTime: 5, capacity: 300 },
];

// Ethiopian city/town names by region
const citiesByRegion: Record<string, string[]> = {
  'Addis Ababa': [
    'Addis Ababa', 'Bole', 'Kazanchis', 'Merkato', 'Piazza', 'Kolfe', 'Nifas Silk', 
    'Gulele', 'Arada', 'Addis Ketema', 'Lideta', 'Kirkos', 'Yeka', 'Bole Bulbula',
    'Summit', 'CMC', 'Hayat', 'Ayat', 'Kotebe', 'Akaki Kality', 'Saris', 'Sar Bet'
  ],
  'Oromia': [
    'Adama', 'Jimma', 'Bishoftu', 'Nekemte', 'Ambo', 'Waliso', 'Shashamane', 'Bale Robe',
    'Asella', 'Adama', 'Gimbi', 'Nejo', 'Dembi Dollo', 'Gore', 'Metu', 'Bedele', 'Ghimbi',
    'Shambu', 'Fiche', 'Debre Libanos', 'Fitche', 'Burayu', 'Sululta', 'Holeta', 'Sebeta',
    'Sendafa', 'Debre Zeit', 'Ziway', 'Batu', 'Butajira', 'Walanchiti', 'Mieso', 'Gewane',
    'Awash', 'Wonji', 'Melka Jebdu', 'Deder', 'Babile', 'Fedis', 'Gursum', 'Moyale',
    'Mega', 'Yabelo', 'Agere Maryam', 'Mega', 'Dodola', 'Kibre Mengist', 'Negele Boran',
    'Adola', 'Wadera', 'Ginir', 'Goba', 'Dinsho', 'Bekoji', 'Asasa', 'Tijo', 'Tiya',
    'Chefe Donsa', 'Bolo', 'Aleltu', 'Derba', 'Chancho', 'Sheno', 'Barak', 'Gohatsion',
    'Fitche', 'Ginchi', 'Bako', 'Ijaji', 'Agaro', 'Limu Genet', 'Seka', 'Serbo', 'Asendabo'
  ],
  'Amhara': [
    'Bahir Dar', 'Gondar', 'Dessie', 'Bahir Dar', 'Debre Markos', 'Debre Tabor', 'Kombolcha',
    'Woldia', 'Finote Selam', 'Debre Birhan', 'Kemise', 'Wegdi', 'Lalibela', 'Sekota',
    'Mekane Selam', 'Azezo', 'Metema', 'Humera', 'Shire', 'Adwa', 'Aksum', 'Adigrat',
    'Wukro', 'Mekelle', 'Korem', 'Alamata', 'Maichew', 'Mekelle', 'Kobo', 'Woldia',
    'Hara Gebeya', 'Wegel Tena', 'Debre Sina', 'Shewa Robit', 'Ataye', 'Senebet',
    'Motta', 'Bichena', 'Dejen', 'Finote Selam', 'Mankush', 'Chagni', 'Dangila',
    'Injibara', 'Dangila', 'Addis Zemen', 'Guba', 'Mota', 'Bure', 'Finote Selam',
    'Guh', 'Wembera', 'Bulen', 'Mandura', 'Dangila', 'Gelago', 'Dabat', 'Debarq',
    'Embaba', 'Tikil Dingay', 'Gorgora', 'Mitra', 'Koladiba', 'Merawi', 'Durbete'
  ],
  'Tigray': [
    'Mekelle', 'Adigrat', 'Aksum', 'Adwa', 'Shire', 'Humera', 'Alamata', 'Wukro',
    'Korem', 'Maichew', 'Abiy Addi', 'Adi Remets', 'Maychew', 'Edaga Arbi', 'Zalambessa',
    'Adi Quala', 'Senkata', 'Freweyni', 'Hawzen', 'Kwiha', 'Maykinetal', 'Maychew',
    'Rama', 'Sheraro', 'Rawyan', 'Hagere Selam', 'May Tsebri', 'Seleklika', 'Edaga Hamus'
  ],
  'SNNPR': [
    'Hawassa', 'Sodo', 'Arba Minch', 'Dila', 'Hosaena', 'Bonga', 'Mizan Teferi', 'Butajira',
    'Wolkite', 'Areka', 'Boditi', 'Yirga Alem', 'Aleta Wendo', 'Sawla', 'Chencha',
    'Gidole', 'Dilla', 'Yirgalem', 'Agere Selam', 'Hagere Selam', 'Durame', 'Hadero',
    'Ginchi', 'Alaba Kulito', 'Humbo', 'Sodo', 'Arba Minch', 'Jinka', 'Key Afer',
    'Omorate', 'Konso', 'Karakore', 'Malka Amana', 'Wolaita Sodo', 'Awasa', 'Tepi',
    'Wush Wush', 'Gimbo', 'Gore', 'Agaro', 'Bonga', 'Mizan Aman', 'Bebeji', 'Bachuma'
  ],
  'Afar': [
    'Semera', 'Asaita', 'Afdera', 'Djibouti', 'Logiya', 'Mille', 'Gewane', 'Eli Dar',
    'Abala', 'Dupti', 'Kalifou', 'Aysaita', 'Chifra', 'Dubti', 'Haramaya', 'Ewa',
    'Awash', 'Boli', 'Kone', 'Sifra', 'Adale', 'Amibara', 'Gelalo', 'Dalifage',
    'Erebti', 'Magale', 'Abala', 'Yalo', 'Teru', 'Aura'
  ],
  'Somali': [
    'Jijiga', 'Diredawa', 'Gode', 'Kebri Dehar', 'Warder', 'Dollo', 'Fiiq', 'Degehabur',
    'Shilavo', 'Korahe', 'Gashamo', 'Hartisheik', 'Teferi Ber', 'Denan', 'Imi',
    'Mieso', 'Awbere', 'Shinile', 'Erer', 'Isa', 'Dembel', 'Gursum', 'Kebri Beyah',
    'Mustahil', 'Ferfer', 'Gunagado', 'Aware', 'Boh', 'Danot', 'Birkot', 'Shekosh'
  ],
  'Benishangul-Gumuz': [
    'Assosa', 'Gambela', 'Metekel', 'Kamashi', 'Mao-Komo', 'Pawi', 'Bambasi', 'Menge',
    'Shirkole', 'Yaso', 'Belo Jiganfoy', 'Guba', 'Wenbera', 'Bulan', 'Dangur',
    'Guba', 'Kurmuk', 'Homosha', 'Oda Buldigilu', 'Agelo Meti', 'Mandi', 'Bambasi'
  ],
  'Gambela': [
    'Gambela', 'Nekemte', 'Itang', 'Dimma', 'Pinyudo', 'Lare', 'Jor', 'Jikawo',
    'Abobo', 'Gog', 'Dima', 'Jikawo', 'Akobo', 'Matar', 'Tirgol', 'Pinyudo'
  ],
  'Harari': [
    'Harar', 'Harar', 'Harar', 'Jijiga', 'Dire Dawa', 'Babile', 'Harar Jugol',
    'Hamaressa', 'Kersa', 'Alemaya', 'Haramaya University'
  ],
  'Dire Dawa': [
    'Dire Dawa', 'Dire Dawa', 'Melka Jebdu', 'Hargele', 'Adada', 'Kula',
    'Bishan Bahe', 'Hurso', 'Legehida', 'Mieso', 'Borde'
  ],
  'Sidama': [
    'Hawassa', 'Yirgalem', 'Aleta Wendo', 'Wendo Genet', 'Bensa', 'Bura',
    'Chire', 'Dale', 'Dara', 'Gorche', 'Hula', 'Loko', 'Malga', 'Shebedino'
  ],
  'South West Ethiopia': [
    'Bonga', 'Tepi', 'Mizan Teferi', 'Wush Wush', 'Gimbo', 'Guraferda',
    'Decha', 'Chena', 'Gewata', 'Sayilem', 'Ginbo', 'Masha'
  ],
};

// Generate random phone number
const generatePhone = (): string => {
  const prefixes = ['0911', '0912', '0913', '0914', '0915', '0916', '0917', '0918', '0919', '0921', '0922', '0923'];
  const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const suffix = Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
  return `${prefix}${suffix}`;
};

// Generate random departments
const generateDepartments = (size: 'small' | 'medium' | 'large'): MockHospital['departments'] => {
  const count = size === 'small' ? 3 : size === 'medium' ? 6 : 10;
  const shuffled = [...departmentTypes].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
};

// Generate hospitals for a region
const generateRegionHospitals = (region: string, count: number, startIndex: number): MockHospital[] => {
  const hospitals: MockHospital[] = [];
  const center = regionCenters[region];
  const cities = citiesByRegion[region] || [region];
  
  for (let i = 0; i < count; i++) {
    const city = cities[i % cities.length];
    const type = Math.random() < 0.7 ? 'GOVERNMENT' : Math.random() < 0.7 ? 'PRIVATE' : 'NGO';
    const size = Math.random() < 0.4 ? 'small' : Math.random() < 0.7 ? 'medium' : 'large';
    
    // Generate random offset from region center
    const latOffset = (Math.random() - 0.5) * 1.5;
    const lngOffset = (Math.random() - 0.5) * 1.5;
    
    let prefix: string;
    let baseName: string;
    
    if (type === 'GOVERNMENT') {
      prefix = govPrefixes[Math.floor(Math.random() * govPrefixes.length)];
      baseName = city.includes('Hospital') ? city : `${city} ${prefix} Hospital`.trim();
    } else if (type === 'PRIVATE') {
      prefix = privatePrefixes[Math.floor(Math.random() * privatePrefixes.length)];
      baseName = city.includes('Hospital') ? city : `${city} ${prefix}`.trim();
    } else {
      prefix = ngoPrefixes[Math.floor(Math.random() * ngoPrefixes.length)];
      baseName = city.includes('Hospital') ? city : `${prefix} Hospital, ${city}`.trim();
    }
    
    // Make names unique
    const name = count > cities.length ? `${baseName} ${Math.floor(i / cities.length) + 1}` : baseName;
    
    hospitals.push({
      id: `hospital-${startIndex + i + 1}`,
      name: name.replace(/  +/g, ' ').trim(),
      region,
      address: `${city}, ${region}, Ethiopia`,
      latitude: center.lat + latOffset,
      longitude: center.lng + lngOffset,
      emergencyContactNumber: generatePhone(),
      isActive: Math.random() > 0.05, // 95% active
      type,
      departments: generateDepartments(size),
    });
  }
  
  return hospitals;
};

// Generate all 500 hospitals
export const generateMockHospitals = (): MockHospital[] => {
  const hospitals: MockHospital[] = [];
  let index = 0;
  
  // Distribution of hospitals by region (total 500)
  const distribution: Record<string, number> = {
    'Addis Ababa': 65,      // Capital has most hospitals
    'Oromia': 100,          // Largest region
    'Amhara': 85,           // Second largest
    'SNNPR': 65,            // High population
    'Tigray': 40,           // Northern region
    'Somali': 35,           // Eastern region
    'Afar': 20,             // Low population density
    'Benishangul-Gumuz': 25,
    'Gambela': 15,
    'Harari': 15,
    'Dire Dawa': 20,
    'Sidama': 15,
    'South West Ethiopia': 20, // New region
  };
  
  Object.entries(distribution).forEach(([region, count]) => {
    const regionHospitals = generateRegionHospitals(region, count, index);
    hospitals.push(...regionHospitals);
    index += count;
  });
  
  return hospitals;
};

// Pre-generated hospitals list
export const MOCK_HOSPITALS: MockHospital[] = generateMockHospitals();
